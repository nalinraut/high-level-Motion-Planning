/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/


3D Mouse Settings Applet
------------------------


1. DESCRIPTION
--------------
The applet displays the 3dmouse settings of the foreground application thread.
The settings are read from %LOCALAPPDATA%\3dmouse\settings\threadid.xml where threadid 
is the hexadecimal representation of the thread id of the foreground thread.

The applet only reacts to file changes when the thread writing to the settings file is the
foreground thread. The applet does not keep track of foreground application or thread changes.


2. REQUIREMENTS
---------------
To launch and operate the applet, the Logitech LCD Manager software must be running. We
recommend the installation of Logitech LCD Manager version 3.05 or later.

Refer to the "Programming for the 3D Mouse.pdf" document for further information.


