#ifndef buttonassignments_H_INCLUDED_
#define buttonassignments_H_INCLUDED_
// s3dm_buttonassgnments.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: s3dm_buttonassignments.h 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 19.10.10 MSB Initial design
//

#include "virtualkeys.hpp"
#include "s3dm_resource.h"

namespace s3dm {
   struct tag_ButtonAssignments
   {
     e3dmouse_virtual_key vkey;
     UINT resourceId;
   };

   static const struct tag_ButtonAssignments _3dmouseButtonAssignments[] =
   {
     {V3DK_MENU, S3DM_IDS_Menu_Function} , {V3DK_FIT, S3DM_IDS_Fit_Function}
     , {V3DK_TOP, S3DM_IDS_Top_Function}, {V3DK_LEFT, S3DM_IDS_Left_Function}
     , {V3DK_RIGHT,S3DM_IDS_Right_Function}, {V3DK_FRONT, S3DM_IDS_Front_Function}
     , {V3DK_BOTTOM, S3DM_IDS_Bottom_Function}, {V3DK_BACK, S3DM_IDS_Back_Function}
     , {V3DK_ROLL_CW, S3DM_IDS_RollCW_Function}, {V3DK_ROLL_CCW, S3DM_IDS_RollCCW_Function}
     , {V3DK_ISO1, S3DM_IDS_Iso1_Function}, {V3DK_ISO2,S3DM_IDS_Iso2_Function}
     , {V3DK_ESC, S3DM_IDS_Esc_Function}, {V3DK_ALT, S3DM_IDS_Alt_Function}
     , {V3DK_SHIFT, S3DM_IDS_Shift_Function}, {V3DK_CTRL, S3DM_IDS_Ctrl_Function}
     , {V3DK_ROTATE, S3DM_IDS_Rotate_Function}, {V3DK_PANZOOM, S3DM_IDS_PanZoom_Function}
     , {V3DK_DOMINANT, S3DM_IDS_Dominant_Function}
     , {V3DK_PLUS, S3DM_IDS_IncreaseSpeed_Function}, {V3DK_MINUS, S3DM_IDS_DecreaseSpeed_Function}
     , {V3DK_SPIN_CW, S3DM_IDS_SpinCW_Function}, {V3DK_SPIN_CCW, S3DM_IDS_SpinCCW_Function}
     , {V3DK_TILT_CW, S3DM_IDS_TiltCW_Function}, {V3DK_TILT_CCW, S3DM_IDS_TiltCCW_Function}
   };


}; //namespace s3dm
#endif // buttonassignments_H_INCLUDED_