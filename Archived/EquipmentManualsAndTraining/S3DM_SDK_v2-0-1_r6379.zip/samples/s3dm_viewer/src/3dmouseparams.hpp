#ifndef c3dmouseParams_HPP_INCLUDED_
#define c3dmouseParams_HPP_INCLUDED_
// 3dmouseparams.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#ifndef __cplusplus
#error 3dmouseparams requires C++ compilation (use a .cpp suffix)
#endif
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: 3dmouseparams.hpp 6272 2010-11-22 15:24:01Z markus_bonk $
//
// 22.06.10 MSB Changed the save location to appdata path and added rudimentary
//              exception handling
// 18.06.10 MSB Don't save pan zoom and rotate settings as this can
//              lead to an inconsistency with 3dxware when using a
//              professional device.
// 12.02.09 MSB Set auto pivot as default
// 26.11.09 MSB Added pivot modes
// 19.11.09 MSB Renamed and converted to header only file
// 21.10.09 MSB Initial Design 
//

//tdx
#include "i3dmouseparam.hpp"

//stl
#include <memory>

// windows
#include <shlobj.h>
#include <shlwapi.h>

namespace tdx {
   ///////////////////////////////////////////////////////////////////////////////////
   // Forward declaration

   ///////////////////////////////////////////////////////////////////////////////////
   // C3dmouseParams
   class C3dmouseParams : public I3dmouseParam
   {
   public:
      C3dmouseParams(): m_eNavigation(objectMode)
            , m_ePivot(autoPivot)
            , m_ePivotVisibility(showPivot)
            , m_bIsLockHorizon(true)
            , m_bIsPanZoom(true)
            , m_bIsRotate(true)
            , m_eSpeed(lowSpeed)
            , m_bIsSingleAxisFilter(false)
            , m_bSelectionFollower(false)
      {
      }

      virtual ~C3dmouseParams()
      {
      }

      // I3dmouseParam interface
   private:
      void Save()
      {
#if _AFX
        TCHAR szPath[MAX_PATH];

        if(SUCCEEDED(::SHGetFolderPathAndSubDir(NULL, 
                               CSIDL_APPDATA|CSIDL_FLAG_CREATE, 
                               NULL, 
                               0,
                               TEXT("3Dconnexion\\s3dm_viewer"),
                               szPath))) 
        {
           ::PathAppend(szPath, TEXT("3dmouseparams.txt"));
           try {
             CFile theFile;
             theFile.Open(szPath, CFile::modeCreate | CFile::modeWrite);
             CArchive archive(&theFile, CArchive::store);
             Serialize(archive);
             archive.Close();
             theFile.Close();
           }
           catch (...)
           {
           }
        }
#endif
      }

      void Load()
      {
#if _AFX
        TCHAR szPath[MAX_PATH];

        if(SUCCEEDED(::SHGetFolderPathAndSubDir(NULL, 
                               CSIDL_APPDATA, 
                               NULL, 
                               0,
                               TEXT("3Dconnexion\\s3dm_viewer"),
                               szPath))) 
        {
           ::PathAppend(szPath, TEXT("3dmouseparams.txt"));
           try 
           {
             CFile theFile;
             if (theFile.Open(szPath, CFile::modeRead))
             {
                CArchive archive(&theFile, CArchive::load);
                Serialize(archive);
                archive.Close();
                theFile.Close();
             }
           }
           catch (...)
           {
           }
        }
#endif
      }


      // No copying
   private:
      C3dmouseParams (const C3dmouseParams&);
      const C3dmouseParams& operator =(const C3dmouseParams&);

      // Implementation

      // I3dmouseSensor interface
      bool IsSingleAxisFilter() {return m_bIsSingleAxisFilter;}
      bool IsPanZoom() {return m_bIsPanZoom;}
      bool IsRotate() {return m_bIsRotate;}
      eSpeed GetSpeed() {return m_eSpeed;}
      void SetPanZoom(bool isPanZoom) {m_bIsPanZoom=isPanZoom;}
      void SetRotate(bool isRotate) {m_bIsRotate=isRotate;}
      void SetSpeed(eSpeed speed) {m_eSpeed=speed;}
      void SetSingleAxisFilter(bool on) {m_bIsSingleAxisFilter=on;}

      // I3dmouseNavigation interface
      eNavigation GetNavigationMode() {return m_eNavigation;}
      ePivot GetPivotMode() {return m_ePivot;}
      ePivotVisibility GetPivotVisibility() {return m_ePivotVisibility;}
      bool IsLockHorizon() {return m_bIsLockHorizon;}
      bool IsSelectionFollower() const {return m_bSelectionFollower;}
      void SetLockHorizon(bool bOn) {m_bIsLockHorizon=bOn;}
      void SetNavigationMode(eNavigation navigation) {m_eNavigation=navigation;}
      void SetSelectionFollower(bool bOn) {m_bSelectionFollower=bOn;}
      void SetPivotMode(ePivot pivot) {m_ePivot = pivot;}
      void SetPivotVisibility(ePivotVisibility visibility) {m_ePivotVisibility = visibility;}

#if _AFX
      void Serialize (CArchive& archive )
      {
         if (archive.IsStoring())
         {
            archive << m_bIsPanZoom
               << m_bIsRotate
               << static_cast<int>(m_eSpeed)
               << static_cast<int>(m_eNavigation)
               << static_cast<int>(m_ePivot == manualPivot ? manualPivot : autoPivot)
               << static_cast<int>(m_ePivotVisibility)
               << m_bIsLockHorizon
               << m_bSelectionFollower;
         }
         else
         {
            bool bIsPanZoom, bIsRotate;
            int Navigation, Pivot, PivotVisibility, Speed;
            archive >> bIsPanZoom
               >> bIsRotate
               >> Speed
               >> Navigation
               >> Pivot
               >> PivotVisibility
               >> m_bIsLockHorizon
               >> m_bSelectionFollower;

            m_bIsPanZoom = true;
            m_bIsRotate = true;
            m_eSpeed=static_cast<eSpeed>(Speed);
            m_eNavigation=static_cast<eNavigation>(Navigation);
            m_ePivot=static_cast<ePivot>(Pivot);
            m_ePivotVisibility=static_cast<ePivotVisibility>(PivotVisibility);
         }
#endif
      }


   private:
      eNavigation       m_eNavigation;
      ePivot            m_ePivot;
      ePivotVisibility  m_ePivotVisibility;
      bool              m_bIsLockHorizon;

      bool m_bIsSingleAxisFilter;
      bool m_bIsPanZoom;
      bool m_bIsRotate;
      eSpeed m_eSpeed;

      bool m_bSelectionFollower;
   }; // C3dmouseParams

}; // namespace tdx
#endif // c3dmouseParams_HPP_INCLUDED_