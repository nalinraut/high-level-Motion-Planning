// mainfrm.cpp : implementation of the CMainFrame class
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: mainfrm.cpp 6278 2010-11-23 15:33:16Z markus_bonk $
//
// 23.11.10 MSB Fix: User pivot is not reset when auto or the selection follower is 
//              switched on or off
//              Added Select none to button 6
//              Fix: crash if a view button is pressed and the app exited at the same 
//              time
// 29.10.10 MSB Added Handler for WM_ACTIVATEAPP to write 3dmsoue settings
//              when app goes to foreground
// 20.09.10 MSB Added Handlers for the view buttons
//              Animated transitions resulting from view and fit buttons
// 11.05.10 MSB Added Handler for WM_INPUT_DEVICE_CHANGE
// 10.05.10 MSB Added method to query if a 3dmouse is attached
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//

#include "stdafx.h"
#include "s3dm_viewer.h"
#include "3dmousexml.h"

#include "MCADdoc.h"
#include "MCADview.h"
#include "mainfrm.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif


// tdx
#include "coordinate_conversion.hpp"
#include "array_auto_ptr.hpp"
// s3dm
#include "virtualkeys.hpp"
#include "s3dm_buttonassignments.h"

// stl
#include <map>
#include <memory>
#include <cmath>
#include <string>

#define _TRACE_ONIDLE 0
#define _TRACE_PIVOT 0
#define _TRACE_SYNC_TIME 0


// Hardcoded button assignments
static const struct s3dm::tag_ButtonAssignments ViewerButtonAssignments[] =
{
 {s3dm::V3DK_1, IDS_OpenFile} 
 , {s3dm::V3DK_2, IDS_Perspective}
 , {s3dm::V3DK_3, IDS_Parallel}
 , {s3dm::V3DK_4, IDS_2D}
 , {s3dm::V3DK_5, IDS_ToggleGrid}
 , {s3dm::V3DK_6, IDS_SelectNone}
 , {s3dm::V3DK_10, IDS_About}
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame
IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
  //{{AFX_MSG_MAP(CMainFrame)
  ON_WM_CREATE()
  ON_WM_PALETTECHANGED()
  ON_WM_QUERYNEWPALETTE()
  ON_WM_TIMER()
  ON_WM_INPUT()                 // For rawinput
  ON_WM_INPUT_DEVICE_CHANGE()   // For rawinput device changes
  ON_WM_ACTIVATEAPP()
  ON_REGISTERED_MESSAGE(WM_S3DM_KEYDOWN, On3dmouseKeyDown)
  ON_REGISTERED_MESSAGE(WM_S3DM_KEYUP, On3dmouseKeyUp)
  //}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame() : m_bRecalculatePivot(true)
, m_bPivotDirty(true)
, m_b3dmouseAttached(false)
, m_bIs3dmousePaused(false)
, m_bSyncDirty(true)
{
#if(_WIN32_WINNT >= 0x0600)
   LANGID langId = ::GetThreadUILanguage();
#else
   LANGID langId = ::GetUserDefaultUILanguage();
#endif

   CString strText;
   if (!strText.LoadString(AfxGetResourceHandle(), AFX_IDS_APP_TITLE, langId))
      strText.LoadString(AfxGetResourceHandle(), AFX_IDS_APP_TITLE);

  // TODO: add member initialization code here
  m_sAppInfo.threadId = GetCurrentThreadId();
  wchar_t *p = new wchar_t[strText.GetLength()+1];
  wcscpy_s(p, strText.GetLength()+1, CT2W(strText.GetString()));
  m_sAppInfo.name = p;
  m_sAppInfo.button_editor = false;
}

CMainFrame::~CMainFrame()
{
  delete_3dmouse_xml(&m_sAppInfo);
  delete [] m_sAppInfo.name;
}


void CMainFrame::OnActivateApp(BOOL bActive, DWORD dwThreadID)
{
  __super::OnActivateApp(bActive, dwThreadID);
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
  if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
    return -1;

  Standard3dmouse()->Load();

  // Initialize 3D mouse input
  InitializeRawInput();

  m_b3dmouseAttached = __super::Is3dmouseAttached();

  return 0;
}

BOOL CMainFrame::OnIdle(LONG lCount)
{
#define NoMoreProcessingTimeNeeded  FALSE
#if _TRACE_ONIDLE
  static long s_count=0;
  TRACE("CMainFrame::OnIdle(%d)\t%d\n",lCount,++s_count);
#endif
  if (lCount != 0)
    return NoMoreProcessingTimeNeeded;

  if (!Is3dmouseAttached())
    return NoMoreProcessingTimeNeeded;

  if (m_bSyncDirty)
    m_bSyncDirty = !Sync3dmouseSettings();

  tdx::I3dmouseNavigation* pNavigation = dynamic_cast<tdx::I3dmouseNavigation*>(Standard3dmouse());
  if (!pNavigation)
    return NoMoreProcessingTimeNeeded;

  CMCADView   *pView = (CMCADView *)GetActiveView();
  if (!pView)
    return NoMoreProcessingTimeNeeded;

  if (pNavigation->GetNavigationMode() == tdx::objectMode || 
    pNavigation->GetNavigationMode() == tdx::targetCameraMode)
  {
    if (pView->Get3dcontroller().IsMoving() && !m_bRecalculatePivot)
      return FALSE;

    if (pNavigation->GetPivotMode() == tdx::autoPivot)
    {
      if (!m_bRecalculatePivot)
      {
        // Only work out a new pivot if the view has moved
        Matrix3d worldToCameraTM=pView->GetDocument()->Camera->m_positionInParent.Inverse();
        Matrix3d currentTransform = worldToCameraTM * pView->GetDocument()->Model->m_positionInParent;

        if (m_autoPivotTransform==currentTransform)
          return NoMoreProcessingTimeNeeded;

        m_autoPivotTransform = currentTransform;
      }
      else
        m_bRecalculatePivot = false;

      pView->AutoPivot();
      m_bPivotDirty = false;
    }
    else if (pNavigation->GetPivotMode() == tdx::manualPivot)
    {
      if (!m_bRecalculatePivot)
      {
        if (!m_bPivotDirty)
          return FALSE;
      }
      else
        m_bRecalculatePivot = false;

      pView->ManualPivot();
      m_bPivotDirty = false;
    }
  }
  else
  {
    Matrix3d worldToCameraTM=pView->GetDocument()->Camera->m_positionInParent.Inverse();
    Matrix3d currentTransform = worldToCameraTM * pView->GetDocument()->Model->m_positionInParent;

    if (m_autoFocusTransform==currentTransform)
      return NoMoreProcessingTimeNeeded;

    m_autoFocusTransform = currentTransform;

    pView->AutoFocus();
  }

  return NoMoreProcessingTimeNeeded;
}

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// Flags the pivot for recalculation next time nothing is moving
// force = true recalculates even if the scene is moving
void CMainFrame::RecalculateAutoPivot(bool force)
{
  // If the scene is moving no need to do anything as the pivot is automatically recalculated
  CMCADView   *pView = (CMCADView *)GetActiveView();
  if (force || !pView || !pView->Get3dcontroller().IsMoving())
    m_bRecalculatePivot = true;
  m_bPivotDirty = true;
  return;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
  CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
  CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers
#if (_MFC_VER >= 0x0a00)
void CMainFrame::OnInputDeviceChange(unsigned short nFlags, HANDLE hDevice)
#else
void CMainFrame::OnInputDeviceChange(unsigned short nFlags)
#endif
{
  TRACE(L"CMainFrame::OnInputDeviceChange(%d)\n", nFlags);
  m_b3dmouseAttached = __super::Is3dmouseAttached();
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
  if (pView)
    pView->RedrawWindow();
}

void CMainFrame::OnPaletteChanged(CWnd* pFocusWnd)
{
  CFrameWnd::OnPaletteChanged(pFocusWnd);

  if(pFocusWnd != this)
    OnQueryNewPalette();
}

BOOL CMainFrame::OnQueryNewPalette()
{
  WORD        i;
  CPalette    *pOldPal;
  CMCADView   *pView = (CMCADView *)GetActiveView();
  CClientDC   dc(pView);


  pOldPal = dc.SelectPalette(&pView->m_cPalette, FALSE);
  i = dc.RealizePalette();
  dc.SelectPalette(pOldPal, FALSE);

  if(i > 0)
    InvalidateRect(NULL);


  return CFrameWnd::OnQueryNewPalette();
}

void CMainFrame::OnTimer(UINT_PTR nIDEvent)
{
  _MyRawInputImpl::OnTimer(nIDEvent);
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
  // remove this flag to remove " - Untitled" from the frame's caption

  cs.style &= ~ FWS_ADDTOTITLE;

  return CFrameWnd::PreCreateWindow(cs);
}

///////////////////////////////////////////////////////////////////////////////////////////////////
// rawinputimpl overrides
void CMainFrame::On3dmouseParameters(int icmd)
{
  Standard3dmouse()->Save();

  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
  // Make sure the pivot / focus gets recalculated if it has changed
  if (icmd == S3DM_IDS_AutoPivot || icmd == S3DM_IDS_SelectionPivot)
  {
    if (pView)
      pView->ResetUserPivot();
  }
  else if (icmd == S3DM_IDS_LockHorizon)
  {
    // Aweful side effect programming
    // If the lock horizon has been set this realigns the horizon
    if (pView)
      pView->Move3d(NULL, ARRAY_NS::array<float,6>());
  }
  else if (icmd == S3DM_IDS_ShowPivot || icmd == S3DM_IDS_HidePivot || icmd == S3DM_IDS_ShowMovingPivot)
  {
  }
  else if (icmd == S3DM_IDS_Rotate 
    || icmd == S3DM_IDS_PanZoom
    || icmd == S3DM_IDS_SingleAxisFilter
    || icmd == S3DM_IDS_LowSpeed
    || icmd == S3DM_IDS_SlowerSpeed
    || icmd == S3DM_IDS_MidSpeed
    || icmd == S3DM_IDS_FasterSpeed
    || icmd == S3DM_IDS_HighSpeed)
  {
    m_bSyncDirty = !Sync3dmouseSettings();
  }

  else if (Standard3dmouse()->GetNavigationMode() != tdx::objectMode 
      && Standard3dmouse()->GetNavigationMode() != tdx::targetCameraMode
      && pView->Projection == eParallel)
  {
      pView->Projection = e2D;
      MessageBox (TEXT("Switching to 2D Projection"), TEXT("Camera Mode Navigation"), MB_ICONWARNING|MB_OK);
  }
  pView->RedrawWindow();
}

LRESULT CMainFrame::On3dmouseKeyDown(WPARAM nVirtualKey, LPARAM hDevice)
{
  static long n3dmouseKeyDown=0;
  LRESULT lResult=0;
  ++n3dmouseKeyDown;
  try {
    switch (nVirtualKey)
    {
    case s3dm::V3DK_1:
      if (n3dmouseKeyDown == 1)
      {
        CS3DMApp* pApp =dynamic_cast<CS3DMApp*>(AfxGetApp());
        if (pApp)
          pApp->OnFileOpen();
      }
      break;

    case s3dm::V3DK_2: // Switch to perspective projection
      if (n3dmouseKeyDown == 1)
      {
        CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
        if (pView)
          pView->OnProjectionPerspective();
      }
      break;

    case s3dm::V3DK_3: // Switch to parallel projection
      if (n3dmouseKeyDown == 1)
      {
        CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
        if (pView)
          pView->OnProjectionParallel();
      }
      break;

    case s3dm::V3DK_4:  // Switch to 2d projection
      if (n3dmouseKeyDown == 1)
      {
        CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
        if (pView)
          pView->OnProjection2d();
      }
      break;

    case s3dm::V3DK_5: // Toggle the grid
      if (n3dmouseKeyDown == 1)
      {
        CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
        if (pView)
          pView->OnToggleGrid();
      }
      break;

    case s3dm::V3DK_6: // Select None
      if (n3dmouseKeyDown == 1)
      {
        CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
        if (pView)
          pView->SelectNone();
      }
      break;

    case s3dm::V3DK_7: 
      break;

    case s3dm::V3DK_8:
      break;

    case s3dm::V3DK_9:
      break;

    case s3dm::V3DK_10: // On about
      if (n3dmouseKeyDown == 1)
      {
        CS3DMApp* pApp =dynamic_cast<CS3DMApp*>(AfxGetApp());
        if (pApp)
          pApp->OnAppAbout();
      }
      break;

    case s3dm::V3DK_FIT:
      if (n3dmouseKeyDown == 1)
        On_v3dk_fit();
      break;

    case s3dm::V3DK_TOP:
      if (n3dmouseKeyDown == 1)
        On_v3dk_top();
      break;

    case s3dm::V3DK_BOTTOM:
      if (n3dmouseKeyDown == 1)
        On_v3dk_bottom();
      break;

    case s3dm::V3DK_LEFT:
      if (n3dmouseKeyDown == 1)
        On_v3dk_left();
      break;

    case s3dm::V3DK_RIGHT:
      if (n3dmouseKeyDown == 1)
        On_v3dk_right();
      break;

    case s3dm::V3DK_FRONT:
      if (n3dmouseKeyDown == 1)
        On_v3dk_front();
      break;

    case s3dm::V3DK_BACK:
      if (n3dmouseKeyDown == 1)
        On_v3dk_back();
      break;

    case s3dm::V3DK_ROLL_CW:
      if (n3dmouseKeyDown == 1)
        On_v3dk_roll_cw();
      break;

    case s3dm::V3DK_ROLL_CCW:
      if (n3dmouseKeyDown == 1)
        On_v3dk_roll_ccw();
      break;

    case s3dm::V3DK_ISO1:
      if (n3dmouseKeyDown == 1)
        On_v3dk_iso1();
      break;

    case s3dm::V3DK_ISO2:
      if (n3dmouseKeyDown == 1)
        On_v3dk_iso2();
      break;

    case s3dm::V3DK_SPIN_CW:
      if (n3dmouseKeyDown == 1)
        On_v3dk_spin_cw();
      break;

    case s3dm::V3DK_SPIN_CCW:
      if (n3dmouseKeyDown == 1)
        On_v3dk_spin_ccw();
      break;

    case s3dm::V3DK_TILT_CW:
      if (n3dmouseKeyDown == 1)
        On_v3dk_tilt_cw();
      break;

    case s3dm::V3DK_TILT_CCW:
      if (n3dmouseKeyDown == 1)
        On_v3dk_tilt_ccw();
      break;

    default:
      lResult=__super::On3dmouseKeyDown(nVirtualKey, hDevice);
      break;
    }
  }
  catch (...) {
  }
  --n3dmouseKeyDown;
  return lResult;
}

LRESULT CMainFrame::On3dmouseKeyUp(WPARAM nVirtualKey, LPARAM hDevice)
{
  LRESULT lresult = __super::On3dmouseKeyUp(nVirtualKey, hDevice);
  if (nVirtualKey == s3dm::V3DK_ROTATE  || nVirtualKey == s3dm::V3DK_PANZOOM
    || nVirtualKey == s3dm::V3DK_DOMINANT || nVirtualKey == s3dm::V3DK_MINUS
    || nVirtualKey == s3dm::V3DK_PLUS)
    m_bSyncDirty = !Sync3dmouseSettings();

  return lresult;
}

const DWORD kFrameTime = 50;
const DWORD kAnimationTime = 1000;

void CMainFrame::AnimateView (CMCADView* pView, const Matrix3d& viewTM)
{
  if (!pView)
    return;

  CPause3dmouse pause(this);

  Matrix3d transForm = viewTM * pView->GetDocument()->Camera->m_positionInParent.Inverse();
  
  Vector3d translationSpeed = transForm.GetPosition()/static_cast<double>(kAnimationTime);

  Vector3d axis;
  float rotationSpeed = static_cast<float>(transForm.GetRotationAxisAngle(axis)/static_cast<double>(kAnimationTime));

  if (fabs(rotationSpeed) < static_cast<float>(epsilon) 
    && fabs(translationSpeed.Length()) < epsilon)
  {
    pView->GetDocument()->Camera->m_positionInParent = viewTM;
    pView->DrawScene();
    return;
  }


  DWORD dwWait = (kAnimationTime+(kFrameTime>>1))/kFrameTime;
  DWORD dwPreviousTime = GetTickCount();
  DWORD dwTime = 0;

  Matrix3d animationTM;
  animationTM.Identity();
  do
  {
    CS3DMApp* pApp = dynamic_cast<CS3DMApp*>(AfxGetApp());
    if (pApp)
    {
      if (pApp->Wait(dwWait))
        return; // Quit
    }

    DWORD dwNow = GetTickCount();
    DWORD dwDeltaTime = dwNow - dwPreviousTime;
    if (dwTime + dwDeltaTime > kAnimationTime)
      dwDeltaTime = kAnimationTime - dwTime;

    dwTime += dwDeltaTime;
    dwPreviousTime = dwNow;

    Matrix3d cameraToWorld = animationTM.Inverse() * pView->GetDocument()->Camera->m_positionInParent;
    animationTM.SetFromAngleAxis(axis * rotationSpeed * static_cast<double>(dwTime));
    animationTM.TranslateBy(translationSpeed * static_cast<double>(dwTime));
    pView->GetDocument()->Camera->m_positionInParent = animationTM * cameraToWorld;
    pView->DrawScene();


    dwWait += (kAnimationTime+(kFrameTime>>1))/kFrameTime - dwDeltaTime;
    if (dwWait > (kAnimationTime+(kFrameTime>>1))/kFrameTime)
      dwWait = 0;
  }
  while (dwTime < kAnimationTime);
  
}

bool CMainFrame::Sync3dmouseSettings()
{
#if(_WIN32_WINNT >= 0x0600)
   LANGID langId = ::GetThreadUILanguage();
#else
   LANGID langId = ::GetUserDefaultUILanguage();
#endif

  S3DM_3DMOUSE_SETTINGS _3dmouseSettings = 
  {
    Standard3dmouse()->IsRotate()
    , Standard3dmouse()->IsPanZoom()
    , Standard3dmouse()->IsSingleAxisFilter()
    , tdx::eSpeed2factor[static_cast<size_t>(Standard3dmouse()->GetSpeed())]
  };
  
  std::map<std::wstring, std::wstring> map3dmouseButtons;
  // Write the default mappings
  size_t i;
  for (i=0; i<sizeof(s3dm::_3dmouseButtonAssignments)/sizeof(s3dm::_3dmouseButtonAssignments[0]); ++i)
  {
    CString strText(L" ");
    if (!strText.LoadString(AfxGetResourceHandle(), s3dm::_3dmouseButtonAssignments[i].resourceId, langId))
      strText.LoadString(AfxGetResourceHandle(), s3dm::_3dmouseButtonAssignments[i].resourceId);

    s3dm::e3dmouse_virtual_key virtualkey=s3dm::_3dmouseButtonAssignments[i].vkey;
    map3dmouseButtons[s3dm::VirtualKeyToId(virtualkey)] = strText.GetString();
  }

  // Hardcoded button assignments
  for (i=0; i<sizeof(ViewerButtonAssignments)/sizeof(ViewerButtonAssignments[0]); ++i)
  {
    CString strText(L" ");
    if (!strText.LoadString(AfxGetResourceHandle(), ViewerButtonAssignments[i].resourceId, langId))
      strText.LoadString(AfxGetResourceHandle(), ViewerButtonAssignments[i].resourceId);

    s3dm::e3dmouse_virtual_key virtualkey=ViewerButtonAssignments[i].vkey;
    map3dmouseButtons[s3dm::VirtualKeyToId(virtualkey)] = strText.GetString();
  }

  tdx::array_auto_ptr<S3DM_BUTTON_ASSIGNMENT> sp3dmouseButtons(new S3DM_BUTTON_ASSIGNMENT[map3dmouseButtons.size()]);
  std::map<std::wstring, std::wstring>::iterator it;
  for (i=0,it=map3dmouseButtons.begin(); it!=map3dmouseButtons.end();++i,++it)
  {
    sp3dmouseButtons[i].button_id = it->first.c_str();
    sp3dmouseButtons[i].text = it->second.c_str();
  }

  S3DM_BUTTON_SETTINGS _3dmouseButtonSettings =
  {
    static_cast<int>(map3dmouseButtons.size())
    , L" "
    , sp3dmouseButtons.get()
  };

  if (write_3dmouse_xml (&m_sAppInfo
    , &_3dmouseSettings
    , &_3dmouseButtonSettings) == 0)
    return true;

  return false;
}

void CMainFrame::On_v3dk_fit()
{  // Fit
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
  if (pView)
  {
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
  RecalculateAutoPivot(true);
}

void CMainFrame::On_v3dk_top()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
  if (pView)
  {
    Matrix3d topTM(1.,0.,0.,0.
                  ,0.,0.,1.,0.
                  ,0.,-1.,0.,0.
                  ,0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(topTM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_bottom()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
  if (pView)
  {
    Matrix3d bottomTM(1.,0.,0.,0.
                     ,0.,0.,-1.,0.
                     ,0.,1.,0.,0.
                     ,0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(bottomTM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_front()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
  if (pView)
  {
    Matrix3d frontTM(1.,0.,0.,0.
                    ,0.,1.,0.,0.
                    ,0.,0.,1.,0.
                    ,0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(frontTM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_back()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Matrix3d backTM(-1.,0.,0.,0.
                    ,0.,1.,0.,0.
                    ,0.,0.,-1.,0.
                    ,0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(backTM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_left()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Matrix3d leftTM( 0.,0.,-1.,0.
                    ,0.,1.,0.,0.
                    ,1.,0.,0.,0.
                    ,0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(leftTM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_right()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Matrix3d rightTM( 0.,0.,1.,0.
                    ,0.,1.,0.,0.
                    ,-1.,0.,0.,0.
                    ,0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(rightTM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_iso1()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Matrix3d iso1TM( sqrt(1./2.),  sqrt(1./6.),  -sqrt(1./3.),     0.
                   , 0,            sqrt(2./3.),   sqrt(1./3.),     0.
                   , sqrt(1./2.), -sqrt(1./6.),   sqrt(1./3.),     0.
                   , 0.,0.,0.,1.);

    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(iso1TM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_iso2()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Matrix3d iso2TM( -sqrt(1./2.),  -sqrt(1./6.),  sqrt(1./3.),     0.
                   , 0,            sqrt(2./3.),   sqrt(1./3.),     0.
                   , -sqrt(1./2.), sqrt(1./6.),   -sqrt(1./3.),     0.
                   , 0.,0.,0.,1.);
      
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM.SetOrientation(iso2TM);
    pView->GetZoomExtents(camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_roll_cw()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Vector3d axis(0.,0.,1.); 
    Matrix3d rotate;
    rotate.SetFromAngleAxis(tdx::kPI/2., axis);
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM = camera2WorldTM*rotate;
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_roll_ccw()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Vector3d axis(0.,0.,1.); 
    Matrix3d rotate;
    rotate.SetFromAngleAxis(-tdx::kPI/2., axis);
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    camera2WorldTM = camera2WorldTM*rotate;
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_spin_cw()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Vector3d axis(0.,1.,0.); 
    Matrix3d rotate;
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    Vector3d centerOfRotation = camera2WorldTM.GetPosition();
    if (Standard3dmouse()->GetNavigationMode() == tdx::objectMode || Standard3dmouse()->GetNavigationMode() == tdx::targetCameraMode)
    {
      // If the rotation center is not in the view point then spin about that using the world up axis
      Matrix3d world2CameraTM = camera2WorldTM.Inverse();
      axis = world2CameraTM.GetOrientation() * axis;
      rotate.SetFromAngleAxis(tdx::kPI/2., axis);

      Matrix3d translate;
      Matrix3d modelToWorldTM=pView->GetDocument()->Model->m_positionInParent;
      centerOfRotation = modelToWorldTM * pView->Get3dcontroller().CenterOfRotation;
      translate.TranslateBy(centerOfRotation - camera2WorldTM.GetPosition());
      translate = world2CameraTM * translate * camera2WorldTM;
      rotate = translate * rotate * translate.Inverse();
    }
    else
      rotate.SetFromAngleAxis(tdx::kPI/2., axis);

    camera2WorldTM = camera2WorldTM*rotate;
    if (Standard3dmouse()->IsLockHorizon())
      LevelHorizon(centerOfRotation, camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_spin_ccw()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Vector3d axis(0.,1.,0.); 
    Matrix3d rotate;
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    Vector3d centerOfRotation = camera2WorldTM.GetPosition();
    if (Standard3dmouse()->GetNavigationMode() == tdx::objectMode || Standard3dmouse()->GetNavigationMode() == tdx::targetCameraMode)
    {
      // If the rotation center is not in the view point then spin about that using the world up axis
      Matrix3d world2CameraTM = camera2WorldTM.Inverse();
      axis = world2CameraTM.GetOrientation() * axis;
      rotate.SetFromAngleAxis(-tdx::kPI/2., axis);

      Matrix3d translate;
      Matrix3d modelToWorldTM=pView->GetDocument()->Model->m_positionInParent;
      centerOfRotation = modelToWorldTM * pView->Get3dcontroller().CenterOfRotation;
      translate.TranslateBy(centerOfRotation - camera2WorldTM.GetPosition());
      translate = world2CameraTM * translate * camera2WorldTM;
      rotate = translate * rotate * translate.Inverse();
    }
    else
      rotate.SetFromAngleAxis(-tdx::kPI/2., axis);
  
    camera2WorldTM = camera2WorldTM*rotate;
    if (Standard3dmouse()->IsLockHorizon())
      LevelHorizon(centerOfRotation, camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_tilt_cw()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Vector3d axis(1.,0.,0.); 
    Matrix3d rotate;
    rotate.SetFromAngleAxis(tdx::kPI/2., axis);
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    Vector3d centerOfRotation = camera2WorldTM.GetPosition();
    if (Standard3dmouse()->GetNavigationMode() == tdx::objectMode || Standard3dmouse()->GetNavigationMode() == tdx::targetCameraMode)
    {
      // If the rotation center is not in the view point then tilt about that
      Matrix3d translate;
      Matrix3d modelToWorldTM=pView->GetDocument()->Model->m_positionInParent;
      centerOfRotation = modelToWorldTM * pView->Get3dcontroller().CenterOfRotation;
      translate.TranslateBy(centerOfRotation - camera2WorldTM.GetPosition());
      translate = camera2WorldTM.Inverse() * translate * camera2WorldTM;
      rotate = translate * rotate * translate.Inverse();
    }
    camera2WorldTM = camera2WorldTM*rotate;
    if (Standard3dmouse()->IsLockHorizon())
      LevelHorizon(centerOfRotation, camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::On_v3dk_tilt_ccw()
{
  CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());  
  if (pView)
  {
    Vector3d axis(1.,0.,0.); 
    Matrix3d rotate;
    rotate.SetFromAngleAxis(-tdx::kPI/2., axis);
    Matrix3d camera2WorldTM = pView->GetDocument()->Camera->m_positionInParent;
    Vector3d centerOfRotation = camera2WorldTM.GetPosition();
    if (Standard3dmouse()->GetNavigationMode() == tdx::objectMode || Standard3dmouse()->GetNavigationMode() == tdx::targetCameraMode)
    {
      // If the rotation center is not in the view point then tilt about that
      Matrix3d translate;
      Matrix3d modelToWorldTM=pView->GetDocument()->Model->m_positionInParent;
      centerOfRotation = modelToWorldTM * pView->Get3dcontroller().CenterOfRotation;
      translate.TranslateBy(centerOfRotation - camera2WorldTM.GetPosition());
      translate = camera2WorldTM.Inverse() * translate * camera2WorldTM;
      rotate = translate * rotate * translate.Inverse();
    }
    camera2WorldTM = camera2WorldTM*rotate;
    if (Standard3dmouse()->IsLockHorizon())
      LevelHorizon(centerOfRotation, camera2WorldTM);
    AnimateView(pView, camera2WorldTM);
  }
}

void CMainFrame::Move3d(HANDLE hDevice, ARRAY_NS::array<float, 6>& motionData)
{
  if (!m_bIs3dmousePaused)
  {
    CMCADView* pView = dynamic_cast<CMCADView*>(GetActiveView());
    if (pView)
      pView->Move3d(hDevice, motionData);
  }
}

BOOL CMainFrame::Is3dmouseAttached()
{
  return m_b3dmouseAttached;
}