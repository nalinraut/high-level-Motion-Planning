// C3dcontroller.cpp: implementation of the C3dcontroller class.
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#include "stdafx.h"
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: c3dcontroller.cpp 6377 2011-01-19 13:56:18Z markus_bonk $
//
// 22.11.10 MSB Fix: In Helicopter mode the input axis frame is dependent on the fov
//              (just data from the device's y-axis (HID) doesn't result in motion remaining
//               at a fixed height to the world ground plane).
// 30.10.09 MSB Initial Design 
//
#include "s3dm_viewer.h"
#include "C3dcontroller.hpp"
#include "Matrix3d.h"
#include "MCADView.h"
#include "MCADDoc.h"
#include "i3dmouseparam.hpp"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

#include "3dmouseconstants.hpp"
#include "coordinate_conversion.hpp"
#include "quaternion.hpp"

//stl
#include <cmath>


#define _LOCK_HORIZON_OUTPUT_ALGORITHM 1
//////////////////////////////////////////////////////////////////////
// Implementation
 void levelHorizon (const Vector3d& centerOfRotation, Matrix3d& view)
 {
    // If the world y-axis (up) vector has a component in the camera x it has 'fallen' over
    if (fabs(view.m[1][0]) > epsilon)
    {
       Matrix3d world2viewTM = view.Inverse();
       // Calculate the pivot position - this must stay invariant in camera coordinates as well
       Vector3d pivotCC = world2viewTM * centerOfRotation;

       // Remove the x component of the up vector
       Vector3d yAxis (0.f, world2viewTM.m[1][1], world2viewTM.m[2][1]);
       if (yAxis.Length() < epsilon)
          yAxis.y = 1.0f;
       yAxis.Normalize();

       Vector3d zAxis (world2viewTM.m[0][2], world2viewTM.m[1][2], world2viewTM.m[2][2]);
       zAxis.Normalize();
    
       // Calculate a new x-axis
       Vector3d xAxis = yAxis.CrossProduct(zAxis);
       if (xAxis.Length() < epsilon)
          xAxis = Vector3d(1.,0.,0.);
       else
          xAxis.Normalize();

       // Calculate a new z-axis
       zAxis = xAxis.CrossProduct(yAxis);
       
       // set the new frame
       world2viewTM.m[0][0] = xAxis.x;
       world2viewTM.m[1][0] = xAxis.y;
       world2viewTM.m[2][0] = xAxis.z;

       world2viewTM.m[0][1] = yAxis.x;
       world2viewTM.m[1][1] = yAxis.y;
       world2viewTM.m[2][1] = yAxis.z;

       world2viewTM.m[0][2] = zAxis.x;
       world2viewTM.m[1][2] = zAxis.y;
       world2viewTM.m[2][2] = zAxis.z;

       // Calculate where the pivot has moved to
       Vector3d pivotFinalCC = world2viewTM * centerOfRotation;

       // move the camera so that the pivot position hasn't change in camera coordinates
       world2viewTM.TranslateBy(pivotCC-pivotFinalCC);

       view = world2viewTM.Inverse();
    }
 }

class C3dcontroller::C3dcontrollerImpl
{
   // construction
public:
   C3dcontrollerImpl(CMCADView& view) : m_view(view)
      , m_bIsMoving(false)
   {
   };
   
   virtual ~C3dcontrollerImpl() 
   {
   };

   // interface
public:
   void Move(const ARRAY_NS::array<float,6>& inputData)
   {
      m_bIsMoving = (0. != inputData[0] || 0. != inputData[1] || 0. != inputData[2] || 
         0. != inputData[3] || 0. != inputData[4] || 0. != inputData[5]);

      ARRAY_NS::array<float,6> motionData(inputData);
      if (m_view.Projection == e2D)
         motionData[3] = motionData[4] = motionData[5] = 0.;

      if (m_view.Standard3dmouse()->GetNavigationMode()==tdx::helicopterMode)
         helicopterControl(motionData);
      else if (m_view.Standard3dmouse()->GetNavigationMode()==tdx::cameraMode)
         cameraControl(motionData);
      else if (m_view.Standard3dmouse()->GetNavigationMode()==tdx::targetCameraMode)
         targetCameraControl(motionData);
      else
	      objectControl(motionData);
   }

   bool GetIsMoving() const
   {
      return m_bIsMoving;
   }

   const Vector3d& GetRotationCenter() const
   {
      return m_centerOfRotationMC;
   }

   void PutRotationCenter(const Vector3d& centerOfRotation)
   {
      m_centerOfRotationMC = centerOfRotation;
   }

private:
   void cameraControl (const ARRAY_NS::array<float,6>& motionData)
   {
	   Vector3d translation(motionData[0], motionData[1], motionData[2]);
      Vector3d rotation(motionData[3], motionData[4], motionData[5]);

      // Scale rotation for the FOV
      rotation.x *= tan(m_view.FOV/2.);
      rotation.y *= tan(m_view.FOV/2.);

      // Scale translation for the FOV
      translation.x *= tan(m_view.FOV/2.);
      translation.y *= tan(m_view.FOV/2.);

      translation *= relativeCameraSpeed();

#if _LOCK_HORIZON_INPUT_ALGORITHM
      if (m_view.Standard3dmouse()->IsLockHorizon())
         rotation = lockHorizon(rotation);
#endif

      Matrix3d transformTM;
	   transformTM.SetFromAngleAxis(rotation);
      transformTM.SetPosition(translation);

	   CMCADDoc *pDoc = m_view.GetDocument();
      Matrix3d camera2worldTM = pDoc->Camera->m_positionInParent;
   
      camera2worldTM *= transformTM;

#if _LOCK_HORIZON_OUTPUT_ALGORITHM
      if (m_view.Standard3dmouse()->IsLockHorizon())
         levelHorizon(camera2worldTM.GetPosition(), camera2worldTM);
#endif

      // Set the new positions and zoom level
      pDoc->Camera->m_positionInParent = camera2worldTM;

      // Handle Parallel projections
      if (m_view.Projection != ePerspective)
         fovZoom(translation.z);
   }

   void helicopterControl (const ARRAY_NS::array<float,6>& motionData)
   {
      Vector3d inputTranslation(motionData[0], motionData[1], motionData[2]);
      Vector3d inputRotation(motionData[3], motionData[4], 0.);


      // Scale rotation for the FOV
      inputRotation.x *= tan(m_view.FOV/2.);
      inputRotation.y *= tan(m_view.FOV/2.);

      // Scale translation for the FOV
      inputTranslation.x *= tan(m_view.FOV/2.);
      inputTranslation.y *= tan(m_view.FOV/2.);

	    CMCADDoc *pDoc = m_view.GetDocument();
      Matrix3d camera2worldTM = pDoc->Camera->m_positionInParent;

      // Construct the frame for the 3d mouse input in camera coordinates
      // The up vector is the world y-axis (use rows instead of inverting 
      // camera2worldTM)
      Vector3d yAxis(camera2worldTM.m[1][0], camera2worldTM.m[1][1], camera2worldTM.m[1][2]);
      if (yAxis.y < 0.)
         yAxis = -yAxis;
      Vector3d xAxis (1.,0.,0.);
      Vector3d zAxis = xAxis.CrossProduct(yAxis);

      Matrix3d input2cameraTM;
      input2cameraTM.m[0][0] = xAxis.x;
      input2cameraTM.m[1][0] = xAxis.y;
      input2cameraTM.m[2][0] = xAxis.z;

      input2cameraTM.m[0][1] = yAxis.x;
      input2cameraTM.m[1][1] = yAxis.y;
      input2cameraTM.m[2][1] = yAxis.z;

      input2cameraTM.m[0][2] = zAxis.x;
      input2cameraTM.m[1][2] = zAxis.y;
      input2cameraTM.m[2][2] = zAxis.z;

      Vector3d rotation = input2cameraTM * inputRotation;
      Vector3d translation = input2cameraTM * inputTranslation;
      translation *= relativeCameraSpeed();  // v = wr; s = wrt

      Matrix3d transformTM;
	    transformTM.SetFromAngleAxis(rotation);
      transformTM.SetPosition(translation);

      camera2worldTM *= transformTM;

      levelHorizon(camera2worldTM.GetPosition(), camera2worldTM);
      pDoc->Camera->m_positionInParent = camera2worldTM;

      // Handle Parallel projections
      if (m_view.Projection != ePerspective)
         fovZoom(translation.z);
   }

   void targetCameraControl (const ARRAY_NS::array<float,6>& motionData)
   {
      ARRAY_NS::array<float,6> objectData;
      for (size_t i=0; i<objectData.size(); ++i)
      {
        objectData[i] = -motionData[i];
      }
      objectControl (objectData);
   }

   void objectControl (const ARRAY_NS::array<float,6>& motionData)
   {
      // Motion is in camera coordinate system and is normally applied
      // to the camera. TO move object in the direction of the forces 
      // applied to the cap we need to negate the data.
	    Vector3d translation(-motionData[0], -motionData[1], -motionData[2]);
      Vector3d rotation(-motionData[3], -motionData[4], -motionData[5]);

      // Scale translation and rotation for the FOV
      translation.x *= tan(m_view.FOV/2.);
      translation.y *= tan(m_view.FOV/2.);

      CMCADDoc *pDoc = m_view.GetDocument();
      Matrix3d camera2worldTM = pDoc->Camera->m_positionInParent;
      Vector3d cameraPosWC = camera2worldTM.GetPosition();

      Matrix3d world2cameraTM = camera2worldTM.Inverse();

      Matrix3d model2worldTM = pDoc->Model->m_positionInParent;
      Vector3d pivotPosWC = model2worldTM * m_centerOfRotationMC;

      Vector3d camera2PivotWC = pivotPosWC-cameraPosWC;
      Vector3d camera2PivotCC = world2cameraTM.GetOrientation() * camera2PivotWC;

      Matrix3d camera2PivotTM;
      camera2PivotTM.SetPosition(camera2PivotCC);

      // Use distance to pivot to convert to longitudinal displacement
      translation *= relativeObjectSpeed(camera2PivotCC.Length());

#if _LOCK_HORIZON_INPUT_ALGORITHM
      if (m_view.Standard3dmouse()->IsLockHorizon())
         rotation = lockHorizon(rotation);
#endif

      Matrix3d transformTM;
      transformTM.SetFromAngleAxis(rotation);
      transformTM.SetPosition(translation);

      transformTM = camera2PivotTM * transformTM * camera2PivotTM.Inverse();

      // Perform the incremental rotation and translation due to 3d mouse
      camera2worldTM *= transformTM;

#if _LOCK_HORIZON_OUTPUT_ALGORITHM
      if (m_view.Standard3dmouse()->IsLockHorizon())
         levelHorizon(pivotPosWC, camera2worldTM);
#endif

      pDoc->Camera->m_positionInParent = camera2worldTM;

      // Handle Parallel projections
      if (m_view.Projection != ePerspective)
         fovZoom(translation.z);
   }

   double relativeCameraSpeed()
   {
      if (m_view.Projection == ePerspective)
         return m_view.TargetDistance < m_view.FocalDistance ? m_view.TargetDistance : m_view.FocalDistance;
      else
         return relativeObjectSpeed(m_view.TargetDistance);
   }

   void fovZoom(double deltaZ)
   {
      double fov = 2. * atan( tan(m_view.FOV/2.) * exp( deltaZ / m_view.TargetDistance ));
      m_view.FOV = fov;
   }

   double relativeObjectSpeed(double targetDistance)
   {
      if (m_view.Projection != ePerspective)
         targetDistance = m_view.TargetDistance;

      if (0. > targetDistance)
         targetDistance = -targetDistance;

      if (targetDistance < m_view.NearClippingDistance)
         targetDistance = m_view.NearClippingDistance;

      return targetDistance;
   }

   Vector3d lockHorizon (const Vector3d& directedRotation)
   {
      CMCADDoc *pDoc = m_view.GetDocument(); 
      Matrix3d world2cameraTM = pDoc->Camera->m_positionInParent.Inverse();

      Vector3d worldYCC (world2cameraTM.m[0][1], world2cameraTM.m[1][1], world2cameraTM.m[2][1]);
      // or  Vector3d worldYCC = world2cameraTM.GetOrientation() * Vector3d(0,1,0);

      Vector3d xVector(1,0,0);
      if (fabs(worldYCC.x) > epsilon)
         xVector = worldYCC.CrossProduct(Vector3d(0,0,1));

      tdx::CQuaternionT<Vector3d> rotation = tdx::QuatFromAngleAxis (worldYCC.DotProduct(directedRotation), worldYCC) *
         tdx::QuatFromAngleAxis (xVector.DotProduct(directedRotation), xVector);


      double angle;
      Vector3d upRotation;
      tdx::AngleAxisFromQuat (rotation, angle, upRotation);
      return upRotation * angle;
   }


   // Properties
private:
   CMCADView&  m_view;
   Vector3d    m_centerOfRotationMC;      // Center of rotation for object control 
                                          // in model coordinates
   bool        m_bIsMoving;
};
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
C3dcontroller::C3dcontroller(CMCADView& view) : m_pImpl (new C3dcontrollerImpl(view))
{
}

C3dcontroller::~C3dcontroller()
{
}

void C3dcontroller::Move(const ARRAY_NS::array<float,6>& motionData) const
{
   m_pImpl->Move(tdx::hid_to_opengl_coord_system(ARRAY_NS::array<float,6>(), motionData));
}

const Vector3d& C3dcontroller::GetRotationCenter() const
{
   return m_pImpl->GetRotationCenter();
}

void C3dcontroller::PutRotationCenter(const Vector3d& centerOfRotation)
{
   m_pImpl->PutRotationCenter(centerOfRotation);
}

bool C3dcontroller::IsMoving() const
{
  return m_pImpl->GetIsMoving();
}


void LevelHorizon (const Vector3d& centerOfRotation, Matrix3d& view)
{
  levelHorizon(centerOfRotation, view);
}