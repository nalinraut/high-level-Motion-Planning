// MCAD.h : main header file for the MCAD application
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: s3dm_viewer.h 6278 2010-11-23 15:33:16Z markus_bonk $
//
// 20.09.10 MSB Added method Wait()
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


/////////////////////////////////////////////////////////////////////////////
// CS3DMApp:
// See s3dm_viewer.cpp for the implementation of this class
//

class CS3DMApp : public CWinApp
{
public:
	CS3DMApp();
	virtual ~CS3DMApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMCADApp)
	public:
	virtual BOOL InitInstance();
  virtual BOOL OnIdle(LONG lCount);
	virtual int Run();
	//}}AFX_VIRTUAL

// Implementation
  BOOL Wait (DWORD dwMilliseconds);
	
    //{{AFX_MSG(CMCADApp)
	afx_msg void OnAppAbout();
  afx_msg void OnFileOpen();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
