#ifndef Matrix3d_H_INCLUDED_
#define Matrix3d_H_INCLUDED_
// Matrix3d.h
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#ifndef __cplusplus
#error Matrix3d requires C++ compilation (use a .cpp suffix)
#endif
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: Matrix3d.h 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 20.09.10 MSB Added GetRotationAxisAngle()
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#include "array_auto_ptr.hpp"
#include <tchar.h>

static const double epsilon=1.0e-5;

class Vector3d
{
public:
   Vector3d() {
      v[0]=v[1]=v[2]=0.;v[3]=1.;
   }
   Vector3d(double x, double y, double z, double w=1.){
      v[0]=x;v[1]=y;v[2]=z;v[3]=w;
   }

public:
   double Length() const;
   Vector3d Negative() const;
   Vector3d& Negate();
   Vector3d& Normalize();
   Vector3d UnitVector() const;
   Vector3d& SingleAxisFilter();
   int MaxComponent() const;
   virtual ~Vector3d() {};

   void Zero() {
      v[0]=v[1]=v[2]=0.;v[3]=1.;
   }
   void Set(double x, double y, double z, double w=1.) {
      v[0]=x;v[1]=y;v[2]=z;v[3]=w;
   }
   double DotProduct(const Vector3d &vec) const;
   void DumpVector(TCHAR *s) const;

   Vector3d CrossProduct(const Vector3d &vec) const;
   Vector3d  operator+ (const Vector3d &vec) const;
   Vector3d& operator+=(const Vector3d &vec);
   Vector3d  operator- (const Vector3d &vec) const;
   Vector3d  operator-() const;
   Vector3d& operator-=(const Vector3d &vec);
   Vector3d& operator/=(double factor) {
      v[0]/=factor;v[1]/= factor;v[2]/= factor;
      return *this;
   }
   Vector3d operator/(double factor) {
      Vector3d result(*this);
      result/=factor;
      return result;
   }
   Vector3d& operator*=(double factor) {
      v[0]*=factor;v[1]*= factor;v[2]*= factor;
      return *this;
   }
   Vector3d operator *(double factor) {
      Vector3d result(*this);
      result *= factor;
      return result;
   }


   __declspec (property (get = GetX, put = PutX)) double x;
   double GetX() const {return v[0];}
   void PutX(double x) {v[0]=x;}

   __declspec (property (get = GetY, put = PutY)) double y;
   double GetY() const {return v[1];}
   void PutY(double y) {v[1]=y;}

   __declspec (property (get = GetZ, put = PutZ)) double z;
   double GetZ() const {return v[2];}
   void PutZ(double z) {v[2]=z;}

   __declspec (property (get = GetW, put = PutW)) double w;
   double GetW() const {return v[3];}
   void PutW(double w) {v[3]=w;}

   double v[4];
};

class Matrix3d  
{
public:
   Matrix3d & SetFromScaleFactors(double sx, double sy, double sz);
   void SetFromOpenGLFormat(double mat[4][4]);
   void SetFromOpenGLFormat(double mat[16]);
   double GetRotationAxisAngle(Vector3d &axis);
   Matrix3d GetOrientation();
   Vector3d GetColumn(size_t column);
   Vector3d GetPosition();
   Matrix3d& SetOrientation(const Matrix3d & mat);
   Matrix3d& SetPosition(const Vector3d& vec);
   Matrix3d& TransposeRotOnly();
   Matrix3d& TranslateBy(const Vector3d &v);
   Matrix3d();
   Matrix3d(double m00, double m01, double m02, double m03,
      double m10, double m11, double m12, double m13,
      double m20, double m21, double m22, double m23, 
      double m30, double m31, double m32, double m33)
   {
      m[0][0]=m00; m[0][1]=m01; m[0][2]=m02; m[0][3]=m03;
      m[1][0]=m10; m[1][1]=m11; m[1][2]=m12; m[1][3]=m13;
      m[2][0]=m20; m[2][1]=m21; m[2][2]=m22; m[2][3]=m23;
      m[3][0]=m30; m[3][1]=m31; m[3][2]=m32; m[3][3]=m33;
   }
   virtual ~Matrix3d();

   void Identity() {for(int i=0;i<4;i++)for(int j=0;j<4;j++)m[i][j]=(i==j);}
   void Set(double m00, double m01, double m02, double m03,
      double m10, double m11, double m12, double m13,
      double m20, double m21, double m22, double m23, 
      double m30, double m31, double m32, double m33)
   {
      m[0][0]=m00; m[0][1]=m01; m[0][2]=m02; m[0][3]=m03;
      m[1][0]=m10; m[1][1]=m11; m[1][2]=m12; m[1][3]=m13;
      m[2][0]=m20; m[2][1]=m21; m[2][2]=m22; m[2][3]=m23;
      m[3][0]=m30; m[3][1]=m31; m[3][2]=m32; m[3][3]=m33;
   }
   Matrix3d& Transpose();
   Matrix3d  Inverse() const;
   Matrix3d& Invert(); // inverts inplace
   Matrix3d& SetFromAngleAxis(const Vector3d &angleAxis);
   Matrix3d& SetFromAngleAxis(double angle, const Vector3d &axis);
   void DumpMatrix(TCHAR *s);

   double * openGLformat();

   Matrix3d  operator* (const Matrix3d &mat) const;
   Matrix3d& operator*=(const Matrix3d &mat);
   Matrix3d  operator+ (const Matrix3d &mat) const;
   Matrix3d& operator+=(const Matrix3d &mat);
   Matrix3d  operator- (const Matrix3d &mat) const;
   Matrix3d& operator-=(const Matrix3d &mat);
   Vector3d  operator* (const Vector3d &vec) const;
   bool      operator==(const Matrix3d &mat) const;

   double m[4][4];

   void Test();
private:
   double m_openGLformat[4][4];
};

class MatrixStack
{
public:
   MatrixStack() : m_nsize(32)
      , m_topOfStack(0)
      , m_pStack(new Matrix3d[m_nsize])
   {
      m_pStack[m_topOfStack].Identity();
   }
      MatrixStack(int size) : m_nsize(size)
      , m_topOfStack(0)
      , m_pStack(new  Matrix3d[m_nsize])
   {
      m_pStack[m_topOfStack].Identity();
   }
   virtual ~MatrixStack() {}
   bool IsFull()  { return m_topOfStack >= m_nsize-1; }
   const Matrix3d& TopMatrix() { return m_pStack[m_topOfStack];}
   void LoadMatrix(const Matrix3d& m) { m_pStack[m_topOfStack] = m; }
   void PushMatrix()	{ if (m_topOfStack <= m_nsize-2) {m_pStack[m_topOfStack+1] = m_pStack[m_topOfStack]; m_topOfStack++; }}
   void PopMatrix()	{ if (m_topOfStack != 0) m_topOfStack--;}
   void MultMatrix(const Matrix3d &m) { m_pStack[m_topOfStack] = m_pStack[m_topOfStack] * m;}
private:
   int m_nsize;
   int m_topOfStack; // (has something in it or is -1 if stack is empty)
   tdx::array_auto_ptr<Matrix3d> m_pStack;
};

#endif // Matrix3d_H_INCLUDED_

