// MCADdoc.cpp : implementation of the CMCADDoc class
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#include "stdafx.h"
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: mcaddoc.cpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#include "s3dm_viewer.h"

#include "MCADdoc.h"
#include "GeomObj.h"

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMCADDoc

IMPLEMENT_DYNCREATE(CMCADDoc, CDocument)

BEGIN_MESSAGE_MAP(CMCADDoc, CDocument)
	//{{AFX_MSG_MAP(CMCADDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMCADDoc construction/destruction

CMCADDoc::CMCADDoc() : m_pCurrentSelectedObj(NULL)
, m_pViewObj(new CViewObj)
, m_pModel(new CGeomObj)
{
}

CMCADDoc::~CMCADDoc()
{
}

BOOL CMCADDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)


	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMCADDoc serialization

void CMCADDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
      m_pModel.reset (new CWavefrontObj());
      m_pCurrentSelectedObj = m_pModel.get();
      dynamic_cast<CWavefrontObj *>(m_pModel.get())->Serialize(ar);
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMCADDoc diagnostics

#ifdef _DEBUG
void CMCADDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMCADDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMCADDoc commands

