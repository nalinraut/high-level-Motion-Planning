//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by s3dm.rc
//
#define S3DM_IDS_Rotate                     0xa000
#define S3DM_IDB_AutoPivot                  0xa000
#define S3DM_IDS_PanZoom                    0xa001
#define S3DM_IDB_ManualPivot                0xa001
#define S3DM_IDS_SingleAxisFilter           0xa002
#define S3DM_IDS_Pivot                      0xa003
#define S3DM_IDS_ManualPivot                0xa004
#define S3DM_IDS_AutoPivot                  0xa005
#define S3DM_IDS_SelectionPivot             0xa006
#define S3DM_IDS_ShowPivot                  0xa007
#define S3DM_IDS_HidePivot                  0xa008
#define S3DM_IDS_ShowMovingPivot            0xa009

#define S3DM_IDS_Speed                      0xa010
#define S3DM_IDS_LowSpeed                   0xa011
#define S3DM_IDS_SlowerSpeed                0xa012
#define S3DM_IDS_MidSpeed                   0xa013
#define S3DM_IDS_FasterSpeed                0xa014
#define S3DM_IDS_HighSpeed                  0xa015

#define S3DM_IDS_ObjectMode                 0xa020
#define S3DM_IDS_CameraMode                 0xa021
#define S3DM_IDS_HelicopterMode             0xa022
#define S3DM_IDS_WalkMode                   0xa023
#define S3DM_IDS_FlyMode                    0xa024
#define S3DM_IDS_TargetCameraMode           0xa025

#define S3DM_IDS_AdvancedOptions            0xa030
#define S3DM_IDS_LockHorizon                0xa031
#define S3DM_IDS_LockNavigationTo3dViews    0xa032
#define S3DM_IDS_AutokeyAnimation           0xa033
#define S3DM_IDS_MoveObjects                0xa034
#define S3DM_IDS_SuspendMotion              0xa035

#define S3DM_IDS_ButtonAssignments          0xa040
#define S3DM_IDS_CustomizeButtons           0xa041

#define S3DM_IDS_SetPivot                   0xa050
#define S3DM_IDS_ResetPivot                 0xa051


// programmable button names
#define S3DM_IDS_P1                         0xa06d
#define S3DM_IDS_P2                         0xa06e
#define S3DM_IDS_P3                         0xa06f
#define S3DM_IDS_P4                         0xa070
#define S3DM_IDS_P5                         0xa071
#define S3DM_IDS_P6                         0xa072
#define S3DM_IDS_P7                         0xa073
#define S3DM_IDS_P8                         0xa074
#define S3DM_IDS_P9                         0xa075
#define S3DM_IDS_P10                        0xa076


// default button functions
#define S3DM_IDS_Menu_Function              0xa201
#define S3DM_IDS_Fit_Function               0xa202
#define S3DM_IDS_Top_Function               0xa203
#define S3DM_IDS_Left_Function              0xa204
#define S3DM_IDS_Right_Function             0xa205
#define S3DM_IDS_Front_Function             0xa206
#define S3DM_IDS_Bottom_Function            0xa207
#define S3DM_IDS_Back_Function              0xa208
#define S3DM_IDS_RollCW_Function            0xa209
#define S3DM_IDS_RollCCW_Function           0xa20a
#define S3DM_IDS_Iso1_Function              0xa20b
#define S3DM_IDS_Iso2_Function              0xa20c
#define S3DM_IDS_Esc_Function               0xa20d
#define S3DM_IDS_Alt_Function               0xa20e
#define S3DM_IDS_Shift_Function             0xa20f
#define S3DM_IDS_Ctrl_Function              0xa210
#define S3DM_IDS_Rotate_Function            0xa211
#define S3DM_IDS_PanZoom_Function           0xa212
#define S3DM_IDS_Dominant_Function          0xa213
#define S3DM_IDS_IncreaseSpeed_Function     0xa215
#define S3DM_IDS_DecreaseSpeed_Function     0xa216
#define S3DM_IDS_SpinCW_Function            0xa217
#define S3DM_IDS_SpinCCW_Function           0xa218
#define S3DM_IDS_TiltCW_Function            0xa219
#define S3DM_IDS_TiltCCW_Function           0xa21a

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        0xa21b
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1068
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
