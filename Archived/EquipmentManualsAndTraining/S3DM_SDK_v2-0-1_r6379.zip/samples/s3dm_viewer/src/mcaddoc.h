// MCADdoc.h : interface of the CMCADDoc class
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: mcaddoc.h 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#include "GeomObj.h"	// Added by ClassView

//stl
#include <memory>

class CMCADDoc : public CDocument
{
protected: // create from serialization only
	CMCADDoc();
	DECLARE_DYNCREATE(CMCADDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMCADDoc)
	public:
	virtual BOOL OnNewDocument();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CMCADDoc();
	virtual void Serialize(CArchive& ar);   // overridden for document i/o
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

   __declspec( property( get=GetSelectedObject, put=PutSelectedObject ) ) CGeomObj *SelectedObject;
   CGeomObj *GetSelectedObject() {return m_pCurrentSelectedObj;}
   CGeomObj *PutSelectedObject(CGeomObj *SelectedObject) {m_pCurrentSelectedObj=SelectedObject; return SelectedObject;}

   __declspec( property( get=GetModel, put=PutModel ) ) CGeomObj *Model;
   CGeomObj *GetModel() {return m_pModel.get();}
   CGeomObj *PutModel(CGeomObj *ModelObject) {m_pModel.reset(ModelObject); return m_pModel.get();}

   __declspec( property( get=GetView) ) CViewObj *Camera;
   CViewObj *GetView() {return m_pViewObj.get();}

private:
	CGeomObj *m_pCurrentSelectedObj;	// currently selected node
   std::auto_ptr<CViewObj> m_pViewObj;
	std::auto_ptr<CGeomObj> m_pModel;  // ptr to the world node

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMCADDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
