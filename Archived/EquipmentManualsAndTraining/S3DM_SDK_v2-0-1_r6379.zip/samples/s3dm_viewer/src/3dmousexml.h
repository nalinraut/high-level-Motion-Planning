#ifndef _3dmouseXML_H_INCLUDED_
#define _3dmouseXML_H_INCLUDED_
// 3dmousexml.h
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: 3dmousexml.h 6230 2010-11-11 09:43:24Z markus_bonk $
//
// 28.09.10 MSB Initial Design 
//
#include <windows.h>

   ///////////////////////////////////////////////////////////////////////////////////
   // Forward declaration
   typedef struct tag_3dmouse_application_info
   {
      DWORD threadId;
      const wchar_t *name;
      BOOL button_editor;
   } S3DM_APPLICATION_INFO;

   typedef struct tag_3dmouse_sensor_settings
   {
     BOOL rotate;
     BOOL pan_zoom;
     BOOL single_axis;
     float speed;
   } S3DM_3DMOUSE_SETTINGS;

   typedef struct tag_3dmouse_button_assignment
   {
      const wchar_t *button_id;
      const wchar_t *text;
   } S3DM_BUTTON_ASSIGNMENT;

   typedef struct tag_3dmouse_button_settings
   {
      int count;
      const wchar_t *name;
      S3DM_BUTTON_ASSIGNMENT *assignments;
   } S3DM_BUTTON_SETTINGS;

#ifdef __cplusplus
   extern "C"
   {
#endif
   DWORD write_3dmouse_xml (S3DM_APPLICATION_INFO* pAppInfo
     , S3DM_3DMOUSE_SETTINGS* pMouseSettings, S3DM_BUTTON_SETTINGS* pMouseButtonSettings);
   DWORD delete_3dmouse_xml (S3DM_APPLICATION_INFO* pAppInfo);
#ifdef __cplusplus
   } // extern "C"
#endif
#endif // _3dmouseXML_H_INCLUDED_