// s3dm_viewer.cpp : Defines the class behaviors for the application.
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#include "stdafx.h"
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: s3dm_viewer.cpp 6278 2010-11-23 15:33:16Z markus_bonk $
//
// 23.11.10 MSB Added SelectNone method
// 17.10.10 MSB Added OnInitDilaog handler to the about dialog
//              which loads a language dependant description text
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#include "s3dm_viewer.h"

#include "mainfrm.h"
#include "MCADdoc.h"
#include "MCADview.h"

#include "resource.h"
// atl
#include <atlpath.h>

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

// Implementation
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
  BOOL OnInitDialog();
};

/////////////////////////////////////////////////////////////////////////////
// CMCADApp

BEGIN_MESSAGE_MAP(CS3DMApp, CWinApp)
	//{{AFX_MSG_MAP(CMCADApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	//ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	//ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
   ON_COMMAND(ID_FILE_OPEN, &CS3DMApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMCADApp construction

CS3DMApp::CS3DMApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

CS3DMApp::~CS3DMApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMCADApp object

CS3DMApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMCADApp initialization

BOOL CS3DMApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.
	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CMCADDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CMCADView));
	AddDocTemplate(pDocTemplate);

	// create a new (empty) document
	OnFileNew();

	if (m_lpCmdLine[0] != '\0')
	{
		// TODO: add command line processing here
	}

   CPath file(_T(".\\Bicycle.obj"));
   if (file.FileExists())
      OpenDocumentFile(file);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMCADApp commands

int CS3DMApp::Run() 
{
	// TODO: Add your specialized code here and/or call the base class
	
	return CWinApp::Run();
}

BOOL CS3DMApp::OnIdle(LONG lCount)
{
   BOOL bMore = CWinApp::OnIdle(lCount);
   if (lCount == 0)
   {
      CMainFrame* pMainFrame = dynamic_cast<CMainFrame*>(AfxGetMainWnd());
      if (pMainFrame)
         pMainFrame->OnIdle(lCount);
   }
   return bMore;
}

BOOL CS3DMApp::Wait (DWORD dwMilliseconds)
{ 
  DWORD dwTime = GetTickCount() + dwMilliseconds;
  HANDLE hHandle = GetCurrentThread();

  while (TRUE)
  {
     DWORD result ; 
     MSG msg ; 

     while (PeekMessage(&msg, NULL, 0, 0, PM_NOREMOVE|PM_NOYIELD)) 
     { 
        // If it's a quit message, we're out of here.
        if (msg.message == WM_QUIT)  
           return TRUE; // Quit
        
        PumpMessage();
     } // End of PeekMessage while loop.

     // Wait for any message sent or posted to this queue 
     // or for one of the passed handles be set to signaled.
     DWORD dwWait;
     if (dwMilliseconds == INFINITE)
        dwWait = INFINITE;
     else
     {
        DWORD dwTimeout = GetTickCount();
        if (dwTimeout < dwTime)
           dwWait = dwTime - dwTimeout;
        else
           dwWait = 0;
     }

     if (dwWait != 0)
        result = MsgWaitForMultipleObjects(1, &hHandle, 
        FALSE, dwWait, QS_ALLINPUT); 
     else
        result = WaitForSingleObject (hHandle, 0);


     // The result tells us the type of event we have.
     if (result == (WAIT_OBJECT_0 +1))
     {
        // New messages have arrived. 
        // Continue to the top of the always while loop to 
        // dispatch them and resume waiting.
        continue;
     } 
     else 
     { 
        // the handle has became signaled. 
        return FALSE;
     }
  }
  return FALSE;
}

/////////////////////////////////////////////////////////////////////////////
// Message handlers
// App command to run the dialog
void CS3DMApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

void CS3DMApp::OnFileOpen()
{
   CWinApp::OnFileOpen();
   // TODO: Add your command handler code here
}
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CAboutDlg::OnInitDialog()
{
  CDialog::OnInitDialog();

#if(_WIN32_WINNT >= 0x0600)
  LANGID langId = ::GetThreadUILanguage();
#else
  LANGID langId = ::GetUserDefaultUILanguage();
#endif

  CString strText;
  if (!strText.LoadString(AfxGetResourceHandle(), IDS_ABOUT_TITLE, langId))
    strText.LoadString(AfxGetResourceHandle(), IDS_ABOUT_TITLE);
  SetWindowText(strText.GetString());

  if (!strText.LoadString(AfxGetResourceHandle(), IDS_ABOUT_DESCRIPTION, langId))
    strText.LoadString(AfxGetResourceHandle(), IDS_ABOUT_DESCRIPTION);
  CWnd* pWnd = GetDlgItem(IDC_ABOUT_DESCRIPTION);
  if (pWnd)
    pWnd->SetWindowTextW(strText.GetString());

  return TRUE;
}


