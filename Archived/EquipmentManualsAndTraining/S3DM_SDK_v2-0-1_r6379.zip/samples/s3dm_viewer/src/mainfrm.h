#ifndef Mainfrm_H_INCLUDED_
#define Mainfrm_H_INCLUDED_
// mainfrm.h
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: mainfrm.h 6272 2010-11-22 15:24:01Z markus_bonk $
//
// 07.06.10 MSB Corrected declaration of OnTimer()
// 11.05.10 MSB Added Handler for WM_INPUT_DEVICE_CHANGE
// 10.05.10 MSB Added method to query if a 3dmouse is attached
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//

#include "Matrix3d.h"
// tdx
#include "array.hpp"
#include "3dmousexml.h"
// _3dx
#include "rawinput.hpp"

// stl
#include <map>
class CMCADView;
class CMainFrame : public CRawInputMFCImplT<CMainFrame, CFrameWnd>
{
  friend class _MyRawInputImpl;
  friend class CPause3dmouse;

  class CPause3dmouse
  {
  public:
    explicit CPause3dmouse(CMainFrame *p) : m_p(p)
    {
      if (m_p)
      {
        m_IsPaused = m_p->m_bIs3dmousePaused;
        m_p->m_bIs3dmousePaused = true;
      }
    }

    virtual ~CPause3dmouse()
    {
      if (m_p)
        m_p->m_bIs3dmousePaused = m_IsPaused;
    }
  private:
    bool m_IsPaused;
    CMainFrame *m_p;
  };

protected: // create from serialization only
  CMainFrame();
  DECLARE_DYNCREATE(CMainFrame)

  // Attributes
public:

  // Operations
public:

  // Overrides
  // ClassWizard generated virtual function overrides
  //{{AFX_VIRTUAL(CMainFrame)
protected:
  virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
  //}}AFX_VIRTUAL

  // Implementation
public:
  virtual ~CMainFrame();
#ifdef _DEBUG
  virtual void AssertValid() const;
  virtual void Dump(CDumpContext& dc) const;
#endif
  BOOL OnIdle(LONG lCount);
  BOOL Is3dmouseAttached();
  void RecalculateAutoPivot(bool force=false);

  // Generated message map functions
protected:
  //{{AFX_MSG(CMainFrame)
  afx_msg LRESULT On3dmouseKeyDown(WPARAM nVirtualKey, LPARAM hDevice);
  afx_msg LRESULT On3dmouseKeyUp(WPARAM nVirtualKey, LPARAM hDevice);
  afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
  afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
#if (_MFC_VER >= 0x0a00)
  afx_msg void OnInputDeviceChange(unsigned short nFlags, HANDLE hDevice);
#else
  afx_msg void OnInputDeviceChange(unsigned short nFlags);
#endif
  afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
  afx_msg BOOL OnQueryNewPalette();
  afx_msg void OnTimer(UINT_PTR nIDEvent);
  //}}AFX_MSG
  DECLARE_MESSAGE_MAP()

  // CRawInputImplT overrides
  void On3dmouseParameters(int icmd);
  void Move3d(HANDLE hDevice, ARRAY_NS::array<float, 6>& deviceData);

  // 3dmouse button handlers
  void On_v3dk_fit();
  void On_v3dk_top();
  void On_v3dk_bottom();
  void On_v3dk_front();
  void On_v3dk_back();
  void On_v3dk_left();
  void On_v3dk_right();
  void On_v3dk_iso1();
  void On_v3dk_iso2();
  void On_v3dk_roll_cw();
  void On_v3dk_roll_ccw();
  void On_v3dk_spin_cw();
  void On_v3dk_spin_ccw();
  void On_v3dk_tilt_cw();
  void On_v3dk_tilt_ccw();


  void AnimateView (CMCADView* pView, const Matrix3d& viewTM);

private:
  bool  m_bRecalculatePivot;
  bool  m_bPivotDirty;

  Matrix3d m_autoPivotTransform;         // Used to cache position at last autoPivot
  Matrix3d m_autoFocusTransform;         // Used to cache position at last autoFocus
  bool  m_b3dmouseAttached;
  bool  m_bIs3dmousePaused;

  // s3dm synchronisaton
  bool Sync3dmouseSettings();
  S3DM_APPLICATION_INFO m_sAppInfo;
  bool  m_bSyncDirty;
};
/////////////////////////////////////////////////////////////////////////////
#endif //  Mainfrm_H_INCLUDED_