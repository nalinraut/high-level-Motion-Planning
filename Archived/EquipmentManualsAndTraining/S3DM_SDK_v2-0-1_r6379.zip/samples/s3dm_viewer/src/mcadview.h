// MCADview.h : interface of the CMCADView class
// Matrix3d.h
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: mcadview.h 6278 2010-11-23 15:33:16Z markus_bonk $
//
// 23.11.10 MSB Added SelectNone() method
// 23.11.10 MSB Added ResetUserPivot() method
// 20.09.10 MSB Added method GetZoomExtents()
// 07.06.10 MSB Corrected declaration of OnTimer()
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//

#define _AUTO_PIVOT_ONLY_IF_OBJECT_ZOOMED 1

#include "Matrix3d.h"	// Added by ClassView
#include "gl/gl.h"
#include "c3dcontroller.hpp"

//atl
#include <atlimage.h>

// stl
#include <cmath>
#include <vector>

// stl wrapper
#include "array.hpp"

// Forward declarations
class CMCADDoc;
class CGeomObj;
class CMainFrame;
enum eRenderStyle;

namespace tdx {
   class I3dmouseParam;
}

enum eProjection {
   ePerspective,
   eParallel,
   e2D
};

class CMCADView : public CView
{
protected: // create from serialization only
	CMCADView();
	DECLARE_DYNCREATE(CMCADView)

// Attributes
public:
	CMCADDoc* GetDocument();

	CPalette    m_cPalette;
	CPalette    *m_pOldPalette;
	CRect       m_clientRect;
	CClientDC   *m_pDC;

// Operations
public:
   void DrawScene(void);
   void GetZoomExtents(Matrix3d& cameraToWorldTM);
   void ZoomExtents(void);
   void AutoFocus(void);
   void AutoPivot(void);
   void ManualPivot(void);
   void ResetUserPivot(void);
   void SelectNone(void);
   void Move3d(HANDLE hDevice, ARRAY_NS::array<float, 6>& deviceData);

   tdx::I3dmouseParam*  Standard3dmouse();
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMCADView)
public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
   virtual void OnInitialUpdate();
	protected:
	//}}AFX_VIRTUAL

// Implementation
private:
	bool m_ControlKeyDepressed;
	bool m_ShiftKeyDepressed;
   long m_isDrawing;
	virtual ~CMCADView();
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

   ATL::CImage          m_imageManualPivot;
   ATL::CImage          m_imageAutoPivot;

   C3dcontroller        m_3dcontroller;
   CMainFrame*          m_pMainFrame;
   bool                 m_bUserPivot;

   UINT_PTR             m_animationTimer;
   UINT                 m_uAnimationUpdatePeriod;
   int                  m_animationTimeToLive;
   bool                 m_bRedrawView;
   // attributes
public:
   const C3dcontroller& Get3dcontroller() { return m_3dcontroller;}

   __declspec (property (get=GetFocalDistance)) double FocalDistance;
   double GetFocalDistance()
   {
      return m_focalDistance;
   }
   __declspec (property (get=GetFieldWidth)) double FieldWidth;
   double GetFieldWidth()
   {
      return m_frustumRight-m_frustumLeft;
   }
   __declspec (property (get=GetTargetDistance)) double TargetDistance;
   double GetTargetDistance()
   {
      return m_targetDistance;
   }
   __declspec (property (get=GetNearClippingDistance)) double NearClippingDistance;
   double GetNearClippingDistance()
   {
      return m_frustumNearClippingPlane;
   }
   __declspec (property (get=GetFOV,put=PutFOV)) double FOV;
   double GetFOV()
   {
      return 2.*atan((m_frustumRight-m_frustumLeft)/2./m_frustumNearDistance);
   }
   void PutFOV(double fov)
   {
      m_frustumRight = m_frustumNearDistance * tan(fov/2.);
      m_frustumLeft = -m_frustumRight;
      double aspectRatio = static_cast<double>(m_clientRect.bottom)/static_cast<double>(m_clientRect.right);
      m_frustumTop    = (m_frustumRight-m_frustumLeft)*aspectRatio/2.;
      m_frustumBottom = -m_frustumTop;
      m_bRedrawFrustum = true;
   }

   __declspec (property (get=GetProjection,put=PutProjection)) eProjection Projection;
   eProjection GetProjection()
   {
      return m_projection;
   }
   void PutProjection(eProjection projection)
   {
      if (m_projection != projection)
         m_bRedrawFrustum = true;
      m_projection = projection;
   }


private:
   bool  AutoFocus(Vector3d& focalPointCC, const CPoint& point, const CSize& size=CSize(1,1));
	unsigned char ComponentFromIndex(int i, UINT nbits, UINT shift);
	void  CreateRGBPalette(void);
  void  DrawObjects(CGeomObj *pGeomObj, eRenderStyle renderStyle);
	void  DrawObjects(CGeomObj *pGeomObj, eRenderStyle renderStyle, int flags);
  void  DrawGrid();
  void  DrawPivot();
  void  SetFrustum();
	void  InitGL();
  double PerspectiveFOVToParallel();
  int   PickObject(const CPoint& point, const CSize& size=CSize(1,1), int flags=0);
  int   PickObject(const CPoint& point, float& z_depth, const CSize& size, int flags);
  int   PickObject(ARRAY_NS::array<GLuint, 256>& selectBuffer, const CPoint& point, const CSize& size, int flags);
  int   PickPivot(Vector3d& pivotMC, const CPoint& point, const CSize& size=CSize(1,1), int flags=0);
	BOOL  PickLevelOfObjects(CGeomObj *pGeomObj, CMCADDoc *pDoc, unsigned int pickName);
	BOOL  SetupPixelFormat(void);

   GLdouble m_frustumLeft, m_frustumRight, m_frustumBottom, m_frustumTop;
   GLdouble m_frustumNearDistance;
   GLdouble m_frustumNearClippingPlane, m_frustumFarClippingPlane;
   double m_targetDistance, m_focalDistance;
   bool m_bRedrawFrustum;
   GLdouble m_extentsGrid;
   eProjection m_projection;
   eRenderStyle m_renderStyle;
   bool         m_bShowGrid;

   std::vector<int> m_selection;
   void SelectionChanged();
   // Generated message map functions     
protected:
	//{{AFX_MSG(CMCADView)
	afx_msg int  OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnFilePlay();
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnMButtonDown(UINT nFlags, CPoint point);
   afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnTimer(UINT_PTR nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
   afx_msg void OnProjectionPerspective();
   afx_msg void OnProjectionParallel();
   afx_msg void OnProjection2d();
   afx_msg void OnToggleGrid();
   afx_msg void OnUpdateProjectionPerspective(CCmdUI *pCmdUI);
   afx_msg void OnUpdateProjectionParallel(CCmdUI *pCmdUI);
   afx_msg void OnUpdateProjection2d(CCmdUI *pCmdUI);
   afx_msg void OnUpdateShowGrid(CCmdUI *pCmdUI);
};

#ifndef _DEBUG  // debug version in MCADview.cpp
inline CMCADDoc* CMCADView::GetDocument()
   { return (CMCADDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////
