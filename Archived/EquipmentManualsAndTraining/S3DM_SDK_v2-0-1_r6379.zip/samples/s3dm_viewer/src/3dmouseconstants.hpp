#ifndef _3dmouseconstants_H_INCLUDED_
#define _3dmouseconstants_H_INCLUDED_
// 3dmouseconstants.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#ifndef __cplusplus
#error i3dmouseparam requires C++ compilation (use a .cpp suffix)
#endif
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: 3dmouseconstants.hpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 17.12.09 MSB Initial Design 
//

#include <cmath>
namespace tdx {
   /////////////////////////////////////////////////////////////////////////////////
   // 3dmouse constants
   static const double kPI = 3.1415926535897932384626433832795;
   
   // object angular velocity per mouse tick 0.008 milliradians per second per count
   static const double k3dmouseAngularVelocity = 8.0e-6; // radians per second per count

}; // namespace tdx
#endif // _3dmouseconstants_H_INCLUDED_