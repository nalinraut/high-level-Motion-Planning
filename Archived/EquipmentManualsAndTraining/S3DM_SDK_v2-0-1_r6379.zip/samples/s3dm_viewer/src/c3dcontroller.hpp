#ifndef C3dcontroller_HPP_INCLUDED_
#define C3dcontroller_HPP_INCLUDED_
// c3dcontroller.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

#ifndef __cplusplus
#error c3dcontroller requires C++ compilation (use a .cpp suffix)
#endif
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: c3dcontroller.hpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 17.09.10 MSB Changed IsMoving from property to method
// 30.10.09 MSB Initial Design 
//
class CMCADView;
class Vector3d;
class Matrix3d;

//tdx
#include "array.hpp"

class C3dcontroller
{
   // Construction
public:
   C3dcontroller(CMCADView& view);
   virtual ~C3dcontroller();

   // Interface
public:
	void Move(const ARRAY_NS::array<float,6>& motionData) const;

   __declspec (property (get=GetRotationCenter, put=PutRotationCenter)) Vector3d CenterOfRotation;
   void PutRotationCenter(const Vector3d& centerOfRotation);
   const Vector3d& GetRotationCenter() const;

   bool IsMoving() const;

   // Implementation
private:
   class C3dcontrollerImpl;
   std::auto_ptr<C3dcontrollerImpl> m_pImpl;
};

#include <cmath>
static const double kDefaultFOV = 2 * atan(31.3364/(2. * 50.));
//static const double kDefaultFOV = 60./180.*tdx::kPI;

void LevelHorizon (const Vector3d& centerOfRotation, Matrix3d& view);

#endif // C3dcontroller_HPP_INCLUDED_
