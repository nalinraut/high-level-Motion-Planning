#ifndef array_HPP_INCLUDED_
#define array_HPP_INCLUDED_
// array.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: array.hpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 11.03.10 MSB Only include array in vs9 sp1 and later
// 11.11.09 MSB Initial Design 
//
#if _MSC_FULL_VER >= 150030729
#include <array>
#define ARRAY_NS std::tr1
#else
#define ARRAY_NS tdx
#include <vector>

namespace tdx {
  /////////////////////////////////////////////////////////////////////////////////
  // array - only works because we know how vector is implemented
  template <class _Ty, size_t _Size> class array : private std::vector<_Ty>
  {
  public:
    typedef array<_Ty, _Size> _Myt;
    typedef std::vector<_Ty> _Mybase;

    typedef _Ty& reference;
    typedef const _Ty& const_reference;
    typedef _Ty value_type;
    typedef size_t size_type;

    array() :  std::vector<_Ty>(_Size) 
    { }

    array(const _Myt& _Right) :  _Mybase(_Right) 
    { }

    reference operator[] (size_type _Idx)
    {
      if (_Idx >= size())
        _Xran();
      return _Mybase::operator[](_Idx);
    }

    const_reference operator[] (size_type _Idx) const
    {
      if (_Idx >= size())
        _Xran();
      return _Mybase::operator[](_Idx);
    }

    const _Myt& operator=(const _Myt& _Right)
    {
      _Mybase::operator=(_Right);
      return *this;
    }

    void assign(const _Ty& _Value)
    {
      _Mybase::assign(size(), _Value);
    }

    size_type size() const
    {	
      return _Mybase::size();
    }

    _Ty* data()
    {
      return _Mybase::_Myfirst;
    }

    const _Ty* data() const
    {
      return _Mybase::_Myfirst;
    }

    static void _Xran()
    {	// report an out_of_range error
      _THROW(std::out_of_range, "invalid array<T,size> subscript");
    }

  };

}; // namespace tdx
#endif // _MSC_VER
#endif // array_HPP_INCLUDED_