#ifndef rawinput_HPP_INCLUDED_
#define rawinput_HPP_INCLUDED_
// rawinput.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*
* 
* CRawInputImplT is a header only crtp pattern implementation and is intended 
* to be used for both mfc and atl application implementations.
* classes derived from CRawInputImplT can either poll the 3d mouse input periodically 
* by specifying t_bPoll3dmouse=true in the derived class declaration, or 
* receive the 3d mouse input data immediately when it arrives (t_bPoll3dmouse=false).
* When data is available Move3d (HANDLE hDevice, ARRAY_NS::array<float, 6> aMotionData); 
* is invoked.
* 
* CRawInputImplT also implements handlers for the two standard 3d mouse buttons v3dk_menu 
* and v3dk_fit.
* The handler for v3dk_menu implements the popup menu as specified in "programming for the
* 3dmouse". The 3dmouse paramters can be access through the method Standard3dmouse which
* returns the interface I3dmouseParam.
* The handler for v3dk_fit invokes the On_v3dk_fit method which needs to be 
* overridden in the inheriting class.
* 
* ///////////////////////////////////////////////////////////////////////////////////////
* MFC applications will need to add the windows message handlers
* 
* ON_WM_INPUT()               // For rawinput
* ON_WM_INPUT_DEVICE_CHANGE() // For input device change messages
* ON_WM_TIMER()               // Required if polling 3d mouse data, otherwise not
* ON_WM_ACTIVATEAPP()         // Required if NOT polling the 3d mouse data
* ON_REGISTERED_MESSAGE(WM_S3DM_KEYDOWN, On3dmouseKeyDown) // Required to process 3dmouse buttons
* ON_REGISTERED_MESSAGE(WM_S3DM_KEYDOWN, On3dmouseKeyUp)  // Required to process 3dmouse buttons
* to the AFX_MSG_MAP of the derived class. If any of the handlers already exist
* be sure to chain to the handlers in the template class
*
*
* Change the declaration of the class that handles rawinput from
* class MyClass : public CWndorCWndDerivedClass
* {
* ....
* };
*
* to either
* class MyClass : public CRawInputMFCImplT<MyClass, CWndorCWndDerivedClass>
* {
*     friend class _MyRawInputImpl;
* ...
* };
*
* or 
* class MyClass : public CRawInputImplT<MyClass> , public CWndorCWndDerivedClass
* {
*    friend class _MyRawInputImpl;
* ...
*    afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID);
*    afx_msg void OnInputDeviceChange(unsigned short nFlags);
*    afx_msg void OnRawInput(UINT nInputCode, HRAWINPUT hRawInput);
*    afx_msg void OnTimer(UINT_PTR nIDEvent);
* ...
* };
* ////////////////////////////////////////////////////////////////////////////////////////
* ATL applications will need to add the windows message handlers
* 
* MESSAGE_HANDLER(WM_INPUT_DEVICE_CHANGE, OnInputDeviceChange)// For device change messages
* MESSAGE_HANDLER(WM_INPUT, OnRawInput)                       // For rawinput
* MESSAGE_HANDLER(WM_TIMER, OnWmTimer)                        // Required if polling 3d mouse data
* MESSAGE_HANDLER(WM_ACTIVATEAPP, OnWmActivateApp)            // Required if NOT polling 3d mouse data
* MESSAGE_HANDLER(WM_S3DM_KEYDOWN, On3dmouseKeyDown)          // Required to process 3dmouse buttons
* MESSAGE_HANDLER(WM_S3DM_KEYDOWN, On3dmouseKeyUp)            // Required to process 3dmouse buttons
* to the MSG_MAP of the derived class. If any of the handlers already exist
* be sure to chain to the handlers in the template
*
*
* Change the declaration of the class that handles rawinput from
* class MyClass : public CSomethingOrOther
* {
* ....
* };
*
* to
* class MyClass : public CRawInputImplT<MyClass> , public CSomethingOrOther
* {
*    friend class CRawInputImpl;
* ...
* };
*
* ////////////////////////////////////////////////////////////////////////////////////////
* If you are using a switch in a WndProc() then add the cases to it.
*
* RawInput handling is initialized by calling InitalizeRawInput() after the derived classes window
* has been created i.e m_hWnd is valid.
*
* An Application will need to override the template methods
*     void Move3d (HANDLE hDevice, ARRAY_NS::array<float, 6> aMotionData);
*     void On_v3dk_fit();
* 
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: rawinput.hpp 6259 2010-11-19 09:17:32Z markus_bonk $
//
// 11/19/10 MSB Call On3dmouseParameters() when a key changes the 3D Mouse settings
// 11/18/10 MSB Change: If not polling then call Mov3d() with an all zero motion data
//              package when the application loses foreground focus
// 10/28/10 MSB Fix: Only open the popup menu on V3DK_MENU up if we are the foreground 
//              process
// 09/17/10 MSB Post the key presses to the window's message queue instead of calling 
//              the handlers directly. Redefined the handler signatures to match
//              standard key handlers
//              Added key release logic to OnActivateApp
// 09/17/10 MSB Catered for more speed factors
// 06/29/10 MSB Fix: KillTimer was not killing the polling timer as NULL instead 
//              of the HWND used to set the timer was being passed to KillTimer()
// 06/24/10 MSB Added ~CRawInputImplT() to clean up polling timer
// 08.06.10 MSB Workaround for incorrect alignment of the RAWINPUT structure returned by
//              GetRawInputBuffer() on x64 os when running as Wow64
//              Renamed ZoomExtents to On_v3dk_fit
//              Added handlers for +/- buttons On_v3dk_plus and On_v3dk_minus
// 07.06.10 MSB Corrected declaration of OnTimer()
// 11.05.10 MSB Added handler for WM_INPUT_DEVICE_CHANGE. InitializeRawInput automatically
//              sets the RIDEV_DEVNOTIFY to enabled receiving the message.
// 10.05.10 MSB Added Is3dmouseAttached method which checks if a 3dmouse
//              is currently attached to the os
// 04.12.09 MSB Changed default to t_bPoll3dmouse=true
// 19.11.09 MSB Initial Design 
//


#define _TRACE_WM_INPUT_PERIOD 0
#define _TRACE_3DINPUT_PERIOD 0
#define _TRACE_RI_RAWDATA 0
#define _TRACE_RI_TYPE 0
#define _TRACE_RIDI_DEVICENAME 0
#define _TRACE_RIDI_DEVICEINFO 0
#define _TRACE_KEYUP 0


// tdx
#include "array.hpp"
#include "3dmouseparams.hpp"
#include "3dmouseconstants.hpp"
#include "3dmousepopupmenu.hpp"

// stl
#include <map>

// helper
#include "virtualkeys.hpp"

#ifndef afx_msg
#define afx_msg
#endif

#if _AFX
#if (_MFC_VER < 0x0900)
#if(_WIN32_WINNT >= 0x0501)
#define ON_WM_INPUT() \
	{ WM_INPUT, 0, 0, 0, AfxSig_v_b_h, \
		(AFX_PMSG)(AFX_PMSGW) \
		(static_cast< void (AFX_MSG_CALL CWnd::*)(UINT, HRAWINPUT) > ( OnRawInput)) },
#endif
#if(_WIN32_WINNT >= 0x0501)
#ifndef WM_INPUT_DEVICE_CHANGE
#define WM_INPUT_DEVICE_CHANGE 0x00fe
#endif
#ifndef RIDEV_DEVNOTIFY
#define RIDEV_DEVNOTIFY 0x00002000
#endif
#define ON_WM_INPUT_DEVICE_CHANGE() \
	{ WM_INPUT_DEVICE_CHANGE, 0, 0, 0, AfxSig_v_u_v, \
		(AFX_PMSG)(AFX_PMSGW) \
		(static_cast< void (AFX_MSG_CALL CWnd::*)(unsigned short) > ( OnInputDeviceChange)) },
#endif
#endif // _MFC_VER <= 0x0800
#endif // _AFX

#define LOGITECH_VENDOR_ID 0x46d
#define _CONSTANT_INPUT_PERIOD 0

#ifndef QWORD
typedef ULONGLONG QWORD;
#endif

#define WM_S3DM_KEYDOWN S3DM_KeyDown
#define WM_S3DM_KEYUP S3DM_KeyUp


static const UINT S3DM_KeyDown=::RegisterWindowMessage(_T("S3DM_KeyDown"));
static const UINT S3DM_KeyUp=::RegisterWindowMessage(_T("S3DM_KeyUp"));

///////////////////////////////////////////////////////////////////////////////////
// CRawInputImplT

template <class T, bool t_bPoll3dmouse=true> 
class CRawInputImplT
{
   class CInputData 
   {
   public:
      int                      timeToLive; // For telling if the device was unplugged while sending data
      bool                     isDirty;
      ARRAY_NS::array<float,6> axes;
      bool IsZero() {
         return (0.==axes[0] && 0.==axes[1] && 0.==axes[2] && 
            0.==axes[3] && 0.==axes[4] && 0.==axes[5]);
      }
      static const int kTimeToLive=5;
   };

  class CKeyData 
  {
  public:
    DWORD dwProductId;
    typedef ARRAY_NS::array<unsigned short, 8> key_array;
    key_array keys;

    bool IsZero() 
    {
      for (size_t i=0; i<keys.size(); ++i)
        if (keys[i] != 0) return false;

      return true;
    }
  };

protected:
  ~CRawInputImplT()
  {
    KillPollingTimer();
  }

public:
   typedef CRawInputImplT<T, t_bPoll3dmouse> _MyRawInputImpl;

   CRawInputImplT() : m_dwLast3dmouseInputTime(0)
      , m_3dmouseTimer(0)
      , m_u3dmousePollingPeriod(20)
      , m_nActivePopupMenu(0)
   {
   }

   /////////////////////////////////////////////////////////////////////////////////
   // static PRAWINPUTDEVICE GetDevicesToRegister(UINT* pNumDevices)
   //    *pNumDevices - the number of devices in PRAWINPUTDEVICE
   //    PRAWINPUTDEVICE - array of RAWINPUTDEVICE structures (devices) to register
   static PRAWINPUTDEVICE GetDevicesToRegister(UINT* pNumDevices)
   {
      // Array of raw input devices to register
      static RAWINPUTDEVICE sRawInputDevices[] = {
         {0x01, 0x08, 0x00, 0x00} // Usage Page = 0x01 Generic Desktop Page, Usage Id= 0x08 Multi-axis Controller
      };
      if (pNumDevices)
         *pNumDevices = sizeof(sRawInputDevices)/sizeof(sRawInputDevices[0]);
      return sRawInputDevices;
   }

   static bool Is3dmouseAttached()
   {
      UINT uiNumDevicesOfInterest=0;
      PRAWINPUTDEVICE pDevicesToRegister = T::GetDevicesToRegister(&uiNumDevicesOfInterest);


      UINT nDevices=0;
      tdx::array_auto_ptr<RAWINPUTDEVICELIST> spRawInputDeviceList;
      if (::GetRawInputDeviceList(NULL, &nDevices, sizeof(RAWINPUTDEVICELIST)) != 0)
         return false;

      if (nDevices == 0)
         return false;

      spRawInputDeviceList.reset(new RAWINPUTDEVICELIST[nDevices]);
      if (spRawInputDeviceList.get() == NULL)
         return false;

      if (::GetRawInputDeviceList(spRawInputDeviceList.get(), &nDevices, sizeof(RAWINPUTDEVICELIST)) == static_cast<UINT>(-1))
         return false;

      UINT i;
      for (i=0; i<nDevices; ++i)
      {
         RID_DEVICE_INFO rdi = {sizeof(rdi)};
         UINT cbSize = sizeof(rdi);
         if (GetRawInputDeviceInfo(spRawInputDeviceList[i].hDevice
            , RIDI_DEVICEINFO
            , &rdi
            , &cbSize) > 0)
         {
            if (rdi.dwType != RIM_TYPEHID || rdi.hid.dwVendorId != LOGITECH_VENDOR_ID)
               continue;

            UINT j;
            for (j=0; j<uiNumDevicesOfInterest; ++j)
            {
               if (pDevicesToRegister[j].usUsage == rdi.hid.usUsage 
                  && pDevicesToRegister[j].usUsagePage == rdi.hid.usUsagePage)
                  return true;
            }
         }
      }
      return false;
   }

protected:
   //////////////////////////////////////////////////////////////////////////////////
   // Raw input initialization
   //
   bool InitializeRawInput()
   {
      // We want the rawinput messages for the devices we are registering
      // to always go to this window. 
      // Use the HWND operator to get m_hWnd 
      HWND hwndTarget = static_cast<T*>(this)->operator HWND(); 

      // Simply fail if there is no window
      if (!hwndTarget)
         return false;

      UINT uiNumDevices=0;
      PRAWINPUTDEVICE pDevicesToRegister = T::GetDevicesToRegister(&uiNumDevices);
      if (uiNumDevices)
      {
         // Get OS version.
         OSVERSIONINFO osvi = {sizeof(OSVERSIONINFO),0};
         ::GetVersionEx(&osvi);

         UINT cbSize = sizeof (pDevicesToRegister[0]);
         for (size_t i=0; i<uiNumDevices; i++)
         {
            // Set the target window to us
            pDevicesToRegister[i].hwndTarget = hwndTarget;

            // If Vista or newer, enable receiving the WM_INPUT_DEVICE_CHANGE message.
            if (osvi.dwMajorVersion >= 6)
               pDevicesToRegister[i].dwFlags |= RIDEV_DEVNOTIFY;
         }
         return (::RegisterRawInputDevices(pDevicesToRegister, uiNumDevices, cbSize) != FALSE);
      }
      return false;
   }


   //////////////////////////////////////////////////////////////////////////////////
   // Windows message handlers
   //
protected:
   //////////////////////////////////////////////////////////////////////////////////
   // atl message handler for WM_ACTIVATEAPP
   // To enable rawinput message handling add
   //    MESSAGE_HANDLER(WM_ACTIVATEAPP, OnActivateApp)           // required if we are not polling
   // to the MSG_MAP of the derived class T
   LRESULT OnActivateApp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      bHandled = false;
      static_cast<T*>(this)->OnActivateApp (static_cast<BOOl>(wParam) 
         , static_cast<DWORD>(lParam));
      return 0;
   }

   //////////////////////////////////////////////////////////////////////////////////
   // atl message handler for WM_INPUT_DEVICE_CHANGE
   // To enable message handling for device changes add
   //    MESSAGE_HANDLER(WM_INPUT_DEVICE_CHANGE, OnInputDeviceChange)  // For device change messages
   // to the MSG_MAP of the derived class T
   LRESULT OnInputDeviceChange(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      bHandled = false;
      static_cast<T*>(this)->OnInputDeviceChange (static_cast<UINT>(wParam));
      return 0;
   }

   //////////////////////////////////////////////////////////////////////////////////
   // atl message handler for WM_INPUT
   // To enable rawinput message handling add
   //    MESSAGE_HANDLER(WM_INPUT, OnRawInput)           // For rawinput
   // to the MSG_MAP of the derived class T
   LRESULT OnRawInput(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      bHandled = false;
      static_cast<T*>(this)->OnRawInput (static_cast<UINT>(GET_RAWINPUT_CODE_WPARAM(wParam))
         , reinterpret_cast<HRAWINPUT>(lParam));
      return 0;
   }

   //////////////////////////////////////////////////////////////////////////////////
   // atl message handler for WM_TIMER
   // If polling has been enabled add
   //    MESSAGE_HANDLER(WM_TIMER, OnWmTimer)           // For polling
   // to the MSG_MAP of the derived class T
   // if a timer handler already exists then be sure to
   // chain to this one
   LRESULT OnWmTimer(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      bHandled = false;
      static_cast<T*>(this)->OnTimer(wParam);

      return 0;
   }

   //////////////////////////////////////////////////////////////////////////////////
   // atl message handler for S3DM_KEYDOWN
   // To enable keydown message handling add
   //    MESSAGE_HANDLER(S3DM_KEYDOWN, On3dmouseKeyDown) // For keydown
   // to the MSG_MAP of the derived class T
   LRESULT On3dmouseKeyDown(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      bHandled = false;
      static_cast<T*>(this)->On3dmouseKeyDown (wParam, lParam);
      return 0;
   }

   //////////////////////////////////////////////////////////////////////////////////
   // atl message handler for S3DM_KEYDOWN
   // To enable keydown message handling add
   //    MESSAGE_HANDLER(S3DM_KEYDOWN, On3dmouseKeyDown) // For keydown
   // to the MSG_MAP of the derived class T
   LRESULT On3dmouseKeyUp(UINT uMsg, WPARAM wParam, LPARAM lParam, BOOL& bHandled)
   {
      bHandled = false;
      static_cast<T*>(this)->On3dmouseKeyUp (wParam, lParam);
      return 0;
    }

  //////////////////////////////////////////////////////////////////////////////////
  // mfc message handler for WM_ACTIVATEAPP
  // To enable rawinput message handling add
  //    ON_WM_ACTIVATEAPP()           
  // to the AFX_MSG_MAP of the derived class T
  // if an OnActivateApp handler already exists be sure to
  // chain to this one
  afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID)
  {
    if (!bActive)
    {
      // Send key up for all pressed buttons
      std::map< HANDLE, CKeyData>::iterator iter= m_mapDevice2Keystate.begin();
      while (iter != m_mapDevice2Keystate.end())
      {
        CKeyData& keyState = iter->second;
        size_t i;
        for (i=0; i<keyState.keys.size(); ++i)
        {
          CKeyData::key_array::value_type keys_down = keyState.keys[i];
          if (keys_down)
          {
            size_t nKeycode;
            size_t nLSB = i*sizeof(CKeyData::key_array::value_type)*8;
            CKeyData::key_array::value_type mask = 0x01;
            for (nKeycode=1+nLSB; nKeycode<1+nLSB+sizeof(CKeyData::key_array::value_type)*8; ++nKeycode)
            {
              if (keys_down & mask)
              {
                int nVirtualKeyCode = tdx::HidToVirtualKey(keyState.dwProductId, static_cast<UINT>(nKeycode));
                if (nVirtualKeyCode)
                  ::PostMessage(static_cast<T*>(this)->operator HWND(), WM_S3DM_KEYUP, nVirtualKeyCode, reinterpret_cast<LPARAM>(iter->first));
              }
              mask <<=1;
            }
          }
        }
        iter = m_mapDevice2Keystate.erase(iter);
      }

      if (!t_bPoll3dmouse)
      {
        m_dwLast3dmouseInputTime=0;

        ARRAY_NS::array<float, 6> motionData;
        motionData.assign(0.);

        std::map< HANDLE, CInputData>::iterator iterator= m_mapDevice2Data.begin();
        while (iterator!=m_mapDevice2Data.end())
        {
          HANDLE hDevice =  iterator->first;
          iterator = m_mapDevice2Data.erase(iterator);

          // Work out which will be the next device
          HANDLE hNextDevice=0;
          if (iterator != m_mapDevice2Data.end())
             hNextDevice = iterator->first;

          // Pass the 3dmouse input to the view controller
          static_cast<T*>(this)->Move3d(hDevice, motionData);

          // Because we don't know what happened in the previous call, the cache might have
          // changed so reload the iterator
          iterator = m_mapDevice2Data.find(hNextDevice);
        }
      }
    }
  }

   //////////////////////////////////////////////////////////////////////////////////
   // mfc message handler for WM_INPUT_DEVICE_CHANGE
   // To enable rawinput message handling add
   //    ON_WM_INPUT_DEVICE_CHANGE()           // For rawinput device changes
   // to the AFX_MSG_MAP of the derived class T
   // also add an OnInputDeviceChange handler and then be sure to
   // chain to this one
   afx_msg void OnInputDeviceChange(unsigned short nInputCode)
   {
   }
     
     //////////////////////////////////////////////////////////////////////////////////
   // mfc message handler for WM_INPUT
   // To enable rawinput message handling add
   //    ON_WM_INPUT()           // For rawinput
   // to the AFX_MSG_MAP of the derived class T
   // also add an OnRawInput handler and then be sure to
   // chain to this one
   afx_msg void OnRawInput(UINT nInputCode, HRAWINPUT hRawInput)
   {
#if _TRACE_WM_INPUT_PERIOD
      static DWORD s_OnRawInputTime = ::GetTickCount();  
      DWORD dwNow = ::GetTickCount();                 // Current time;
      DWORD dwElapsedTime = dwNow-s_OnRawInputTime;   // Elapsed time since we were last here
      s_OnRawInputTime = dwNow;
      TRACE(L"OnRawInput( 0x%x, 0x%x) Time=%dms\n", nInputCode, hRawInput, dwElapsedTime);
#endif
       // flag if we have new 6dof data and need to invoke the on3dmouseinput handler
      bool b3dmouseInput = false;

      const size_t cbSizeOfBuffer=1024;
      BYTE pBuffer[cbSizeOfBuffer];

      PRAWINPUT pRawInput = reinterpret_cast<PRAWINPUT>(pBuffer);
      UINT cbSize=cbSizeOfBuffer;

      if (::GetRawInputData(hRawInput, RID_INPUT, pRawInput, &cbSize, sizeof(RAWINPUTHEADER)) == static_cast<UINT>(-1))
         return;
      b3dmouseInput = TranslateRawInputData(nInputCode, pRawInput);
      ::DefRawInputProc(&pRawInput, 1, sizeof(RAWINPUTHEADER)); 

      // Check for any buffered messages
      cbSize = cbSizeOfBuffer;
      UINT nCount=this->GetRawInputBuffer(pRawInput, &cbSize, sizeof(RAWINPUTHEADER));
      if (nCount == (UINT)-1)
      {
         TRACE ("GetRawInputBuffer returned error %d\n", GetLastError());
      }
      while (nCount>0 && nCount !=  static_cast<UINT>(-1))
      {
         PRAWINPUT pri = pRawInput;
         UINT nInput;
         for (nInput=0; nInput<nCount; ++nInput)
         {
            b3dmouseInput |= TranslateRawInputData(nInputCode, pri);
            // clean the buffer
            ::DefRawInputProc(&pri, 1, sizeof(RAWINPUTHEADER)); 

            pri = NEXTRAWINPUTBLOCK(pri);
         }
         cbSize = cbSizeOfBuffer;
         nCount = this->GetRawInputBuffer(pRawInput, &cbSize, sizeof(RAWINPUTHEADER));
      }

      // If we have mouse input data for the app then tell tha app about it
      if (b3dmouseInput)
      {
         // If we are polling and the timer is not running then start it
         if (t_bPoll3dmouse)
         {
            if (!m_3dmouseTimer)
            {
               // Create a brand new unused timer
               m_3dmouseTimer = ::SetTimer(NULL, 0, USER_TIMER_MAXIMUM, NULL);
               // Now set the HWND to the derived window and correct the timeout
               m_3dmouseTimer = ::SetTimer(static_cast<T*>(this)->operator HWND()
                  , m_3dmouseTimer
                  , m_u3dmousePollingPeriod
                  , NULL);
            }
         }
         else
            // Process the motion data
            static_cast<T*>(this)->On3dmouseInput();
      }
   }

   //////////////////////////////////////////////////////////////////////////////////
   // mfc message handler for WM_TIMER
   // If polling has been enabled add
   //    ON_WM_TIMER          // For polling
   // to the AFX_MSG_MAP of the derived class T
   // Add a timer handler and then be sure to
   // chain to this one
   afx_msg void OnTimer(UINT_PTR nIDEvent) 
   {
      // Only if polling is enabled
      if (t_bPoll3dmouse)
      {
         if (nIDEvent == m_3dmouseTimer)
            static_cast<T*>(this)->On3dmouseInput();
      }
   }

   //////////////////////////////////////////////////////////////////////////////////
   // 3d mouse data handlers
protected:

   //////////////////////////////////////////////////////////////////////////////////
   // Move3d is invoked when new 3d mouse data is available.
   // Override this method to process 3d mouse 6dof data in the application
   // Input:
   //    HANDLE hDevice - the raw input device handle 
   //                     this can be used to identify the device the data is coming
   //                     from or simply ignored.
   //
   //    ARRAY_NS::array<float, 6> aMotionData - contains the displacement data, using
   //                     a right-handed coordinate system with z down
   //                     see 'Programing for the 3dmouse' document available at
   //                     www.3dconnexion.com.
   //                     aMotionData[0], aMotionData[1], aMotionData[2] is the
   //                     incremental pan zoom displacement vector (x,y,z).
   //                     aMotionData[3], aMotionData[4], aMotionData[5] is the
   //                     incremental rotation vector (NOT Euler angles)
   void Move3d (HANDLE hDevice, ARRAY_NS::array<float, 6> aMotionData)
   {
      TRACE(L"CRawinputImplT::Move3d(device=0x%x, data=[%f,%f,%f,%f,%f,%f)\n"
         , hDevice
         , aMotionData[0], aMotionData[1], aMotionData[2], aMotionData[3], aMotionData[4], aMotionData[5]
      );
      TRACE(L"\tOverride this method to process 3d mouse 6dof data in the application\n");
   }

   //////////////////////////////////////////////////////////////////////////////////
   // On_v3dk_fit is invoked when key v3dk_fit is pressed on the standard 3d mouse
   // Override this method to zoom extents and reset the center of rotation 
   // to center of volume. See the 'Programming for the 3d mouse' document
   void On_v3dk_fit()
   {
      TRACE(L"CRawinputImplT::On_v3dk_fit()\n");
      TRACE(L"\tOverride to zoom extents and reset the center of rotation to center of volume\n");
   }

   //////////////////////////////////////////////////////////////////////////////////
   // On3dmouseParameters is invoked when 3dmsoue parameters are changed in the popup
   // menu
   // Override this method to handle parameter changes
   void On3dmouseParameters(int icmd)
   {
      TRACE(L"CRawinputImplT::On3dmouseParameters()\n");
      TRACE(L"\tOverride to handle 3d mouse parameter changes\n");
   }

  //////////////////////////////////////////////////////////////////////////////////
  // MFC message handler for S3DM_KeyDown registered message
  // On3dmouseKeyDown processes the standard 3d mouse key presses
  // This method can be overwritten
  // Input:
  //   LPARAM hDevice     - the raw input device handle 
  //                        this can be used to identify the device the data is coming
  //                        from or simply ignored.
  //   WPARAM nVirtualKey - Standard 3d mouse key code 
  afx_msg LRESULT On3dmouseKeyDown(WPARAM nVirtualKey, LPARAM hDevice)
  {
    switch (nVirtualKey)
    {
    case s3dm::V3DK_MENU:
      { // 3D mouse popup menu
        GUITHREADINFO guiThreadInfo = {sizeof(guiThreadInfo)};
        ::GetGUIThreadInfo(GetCurrentThreadId(), &guiThreadInfo);
        if (guiThreadInfo.flags & (GUI_INMENUMODE | GUI_POPUPMENUMODE) && m_nActivePopupMenu==0)
        {
          const KEYBDINPUT ki[2] = {
            {VK_MENU, 0, 0, 0, ::GetMessageExtraInfo()},
            {VK_MENU, 0, KEYEVENTF_KEYUP, 0, ::GetMessageExtraInfo()}
          };

          size_t i;
          for (i=0; i<sizeof(ki)/sizeof(ki[0]); ++i)
          {
            INPUT input = {INPUT_KEYBOARD};
            input.ki = ki[i];
            ::SendInput(1, &input, sizeof(INPUT));
          }
        }
      }
      break;

    case s3dm::V3DK_DOMINANT:
      Standard3dmouse()->SetSingleAxisFilter(!Standard3dmouse()->IsSingleAxisFilter());
      static_cast<T*>(this)->On3dmouseParameters(S3DM_IDS_SingleAxisFilter);
      break;

    case s3dm::V3DK_ROTATE:
      Standard3dmouse()->SetRotate(!Standard3dmouse()->IsRotate());
      static_cast<T*>(this)->On3dmouseParameters(S3DM_IDS_Rotate);
      break;

    case s3dm::V3DK_PANZOOM:
      Standard3dmouse()->SetPanZoom(!Standard3dmouse()->IsPanZoom());
      static_cast<T*>(this)->On3dmouseParameters(S3DM_IDS_PanZoom);
      break;

    case s3dm::V3DK_PLUS:
     Standard3dmouse()->SetSpeed(
       Standard3dmouse()->GetSpeed() == tdx::lowSpeed ? tdx::slowerSpeed : 
       Standard3dmouse()->GetSpeed() == tdx::slowerSpeed ? tdx::midSpeed :
       Standard3dmouse()->GetSpeed() == tdx::midSpeed ? tdx::fasterSpeed :
        tdx::highSpeed
      );
      static_cast<T*>(this)->On3dmouseParameters(S3DM_IDS_LowSpeed);
      break;

    case s3dm::V3DK_MINUS:
      Standard3dmouse()->SetSpeed(
        Standard3dmouse()->GetSpeed() == tdx::highSpeed ? tdx::fasterSpeed :
        Standard3dmouse()->GetSpeed() == tdx::fasterSpeed ? tdx::midSpeed :
        Standard3dmouse()->GetSpeed() == tdx::midSpeed ? tdx::slowerSpeed :
         tdx::lowSpeed
        );
      static_cast<T*>(this)->On3dmouseParameters(S3DM_IDS_LowSpeed);
      break;

    case s3dm::V3DK_ESC:
      break;

    case s3dm::V3DK_ALT:
      break;

    case s3dm::V3DK_SHIFT:
      break;

    case s3dm::V3DK_CTRL:
      break;
    }
    return 0;
  }

  //////////////////////////////////////////////////////////////////////////////////
  // MFC message handler for S3DM_KeyUp registered message
  // On3dmouseKeyUp processes the standard 3d mouse key releases
  // This method can be overwritten
  // Input:
  //   LPARAM hDevice -   the raw input device handle 
  //                      this can be used to identify the device the data is coming
  //                      from or simply ignored.
  //   WPARAM nVirtualKey - Standard 3d mouse key code 
  afx_msg LRESULT On3dmouseKeyUp(WPARAM nVirtualKey, LPARAM hDevice)
  {
    switch (nVirtualKey)
    {
    case s3dm::V3DK_MENU:
      { // 3D mouse popup menu
        GUITHREADINFO guiThreadInfo = {sizeof(guiThreadInfo)};
        ::GetGUIThreadInfo(GetCurrentThreadId(), &guiThreadInfo);
        if (guiThreadInfo.flags & GUI_POPUPMENUMODE)
        {
          const KEYBDINPUT ki[2] = {
            {VK_MENU, 0, 0, 0, ::GetMessageExtraInfo()},
            {VK_MENU, 0, KEYEVENTF_KEYUP, 0, ::GetMessageExtraInfo()}
          };

          size_t i;
          for (i=0; i<sizeof(ki)/sizeof(ki[0]); ++i)
          {
            INPUT input = {INPUT_KEYBOARD};
            input.ki = ki[i];
            ::SendInput(1, &input, sizeof(INPUT));
          }

        }
        else
        {
          // Only if we are the foreground app
          DWORD dwProcessId;
          ::GetWindowThreadProcessId(::GetForegroundWindow(), &dwProcessId);
          if (::GetCurrentProcessId() == dwProcessId)
          {
            tdx::C3dmousePopupMenu popupMenu;
            popupMenu.CreatePopupMenu();
            POINT point;
            ::GetCursorPos(&point);
            ++m_nActivePopupMenu;
            int icmd = popupMenu.TrackPopupMenuEx( point.x
              , point.y
              , static_cast<T*>(this)->operator HWND()
              , NULL
              , &static_cast<tdx::I3dmouseParam&>(m_3dmouseParams)
              );
            --m_nActivePopupMenu;
            if (icmd)
              static_cast<T*>(this)->On3dmouseParameters(icmd);
          }
        }
      }
      break;
    }

#if _TRACE_KEYUP
    TRACE(L"CRawinputImplT::On3dmouseKeyUp(device=0x%x, nVirtualKey=0x%x)\n", hDevice, nVirtualKey);
#endif
    return 0;
  }


   //////////////////////////////////////////////////////////////////////////////////
   // 3d mouse data pre-processing
private:
   void KillPollingTimer()
   {
      if (t_bPoll3dmouse)
      {
         UINT_PTR timer = m_3dmouseTimer;
         m_3dmouseTimer = 0;
         if (timer)
            ::KillTimer(static_cast<T*>(this)->operator HWND(), timer);
      }
   }

   //////////////////////////////////////////////////////////////////////////////////
   // On3dmouseInput() does all the preprocessing of the rawinput device data before
   // finally calling the Move3d method.
   // if polling is enabled (t_bPoll3dmouse==true) On3dmouseInput() is called from 
   // the windows timer message handler (OnTimer())
   // if polling is NOT enabled (t_bPoll3dmouse==false) On3dmouseInput() is called 
   // directly from the WM_INPUT handler (OnRawInput())
   void On3dmouseInput()
   {
      // Don't do any data processing in background
      bool bIsForeground = (::GetActiveWindow() != NULL);
      if (!bIsForeground)
      {
         // set all cached data to zero so that a zero event is seen 
         // and the cached data deleted 
         std::map<HANDLE, CInputData>::iterator iterator=m_mapDevice2Data.begin();
         while (iterator!=m_mapDevice2Data.end())
         {
            iterator->second.axes.assign(.0);
            iterator->second.isDirty=true;
            ++iterator;
         }
      }

      DWORD dwNow = ::GetTickCount();           // Current time;
      DWORD dwElapsedTime;                      // Elapsed time since we were last here

#if _CONSTANT_INPUT_PERIOD
      if (t_bPoll3dmouse)
         dwElapsedTime = m_u3dmousePollingPeriod;
      else
         dwElapsedTime = 16;
#else
      if (0==m_dwLast3dmouseInputTime)
         dwElapsedTime = 10;                    // System timer resolution
      else 
      {
         dwElapsedTime = dwNow - m_dwLast3dmouseInputTime;
         if (m_dwLast3dmouseInputTime > dwNow)
            dwElapsedTime = ~dwElapsedTime+1;
         if (dwElapsedTime<1)
            dwElapsedTime=1;
         // Check for wild numbers because the device was removed while sending data
         else if (dwElapsedTime > 500)
            dwElapsedTime = 10;
      }
#endif

#if _TRACE_3DINPUT_PERIOD
      TRACE(L"On3DmouseInput() period is %dms\n", dwElapsedTime);
#endif

      float fMouseData2Rotation = static_cast<float>(tdx::k3dmouseAngularVelocity);

      // v = w * r,  we don't know r yet so lets assume r=1.)
      float fMouseData2PanZoom = static_cast<float>(tdx::k3dmouseAngularVelocity);

      // Grab the I3dmouseParam interface
      tdx::I3dmouseParam& i3dmouseParam = m_3dmouseParams;
      // Take a look at the users preferred speed setting and adjust the sensitivity accordingly
      tdx::eSpeed speedSetting = i3dmouseParam.GetSpeed();
      // See "Programming for the 3D Mouse", Section 5.1.3
      float fSpeed = 1.;
      if (static_cast<size_t>(speedSetting) < sizeof(tdx::eSpeed2factor)/sizeof(tdx::eSpeed2factor[0]))
        fSpeed = tdx::eSpeed2factor[static_cast<size_t>(speedSetting)];

      // Multiplying by the following will convert the 3d mouse data to real world units
      fMouseData2PanZoom *= fSpeed;
      fMouseData2Rotation *= fSpeed;

      std::map<HANDLE, CInputData>::iterator iterator=m_mapDevice2Data.begin();
      while (iterator!=m_mapDevice2Data.end())
      {
         // If we have not received data for a while send a zero event 
         if ((--(iterator->second.timeToLive))==0)
         {
            iterator->second.axes.assign(.0);
         }
         // If we are not polling then only handle the data that was actually received
         else if (!t_bPoll3dmouse && !iterator->second.isDirty)
         {
            ++iterator;
            continue;
         }
         iterator->second.isDirty=false;

         ////////////////////////////////////////////////////////////////////////////////
         // get a copy of the device
         HANDLE hdevice = iterator->first;

         ////////////////////////////////////////////////////////////////////////////////
         // get a copy of the motion vectors and apply the user filters
         ARRAY_NS::array<float, 6> motionData = iterator->second.axes;

         ////////////////////////////////////////////////////////////////////////////////
         // apply the user filters

         // Pan Zoom filter
         // See "Programming for the 3D Mouse", Section 5.1.2
         if (!i3dmouseParam.IsPanZoom())
         {
            // Pan zoom is switched off so set the translation vector values to zero
            motionData[0] =  motionData[1] =  motionData[2] = 0.;
         }

         // Rotate filter
         // See "Programming for the 3D Mouse", Section 5.1.1
         if (!i3dmouseParam.IsRotate())
         {
            // Rotate is switched off so set the rotation vector values to zero
            motionData[3] =  motionData[4] =  motionData[5] = 0.;
         }

         size_t axis;
         // Single axis filter
         if (i3dmouseParam.IsSingleAxisFilter())
         {
           size_t maxIndex=0;
           for (axis=1; axis<6; axis++)
           {
             if (fabs(motionData[axis]) > fabs(motionData[maxIndex]))
             {
               motionData[maxIndex]=0.;
               maxIndex=axis;
             }
             else
               motionData[axis]=0.;
           }
         }

         // convert the translation vector into physical data
         for (axis=0; axis<3; axis++)
            motionData[axis] *= fMouseData2PanZoom;
         // convert the directed Rotate vector into physical data
         // See "Programming for the 3D Mouse", Section 7.2.2
         for (axis=3; axis<6; axis++)
            motionData[axis] *= fMouseData2Rotation;

         ////////////////////////////////////////////////////////////////////////////
         // Now that the data has had the filters and sensitivty settings applied
         // calculate the displacements since the last view update
         for (axis=0; axis<6; axis++)
            motionData[axis] *= static_cast<float>(dwElapsedTime);


         // Now a bit of book keeping before passing on the data
         if (iterator->second.IsZero())
            iterator = m_mapDevice2Data.erase(iterator);
         else
            ++iterator;

         // Work out which will be the next device
         HANDLE hNextDevice=0;
         if (iterator != m_mapDevice2Data.end())
            hNextDevice = iterator->first;

         // Pass the 3dmouse input to the view controller
         static_cast<T*>(this)->Move3d(hdevice, motionData);

         // Because we don't know what happened in the previous call, the cache might have
         // changed so reload the iterator
         iterator = m_mapDevice2Data.find(hNextDevice);
      }
      if (!m_mapDevice2Data.empty())
         m_dwLast3dmouseInputTime = dwNow;
      else
      {  
         m_dwLast3dmouseInputTime = 0;
         KillPollingTimer();
      }
   }

   bool TranslateRawInputData(UINT nInputCode, PRAWINPUT pRawInput)
   {
      bool bIsForeground = (nInputCode == RIM_INPUT);

#if _TRACE_RI_TYPE
      TRACE(L"Rawinput.header.dwType=0x%x\n", pRawInput->header.dwType);
#endif
      // We are not interested in keyboard or mouse data received via raw input
      if (pRawInput->header.dwType != RIM_TYPEHID)
         return false;

#if _TRACE_RIDI_DEVICENAME
      UINT dwSize=0;
      if (::GetRawInputDeviceInfo(pRawInput->header.hDevice,
         RIDI_DEVICENAME,
         NULL,
         &dwSize) == 0)
      {
         tdx::array_auto_ptr<wchar_t> pszDeviceName;
         pszDeviceName.reset(new wchar_t[dwSize+1]);
         if (pszDeviceName.get())
         {
            if (::GetRawInputDeviceInfo(pRawInput->header.hDevice,
               RIDI_DEVICENAME,
               pszDeviceName.get(),
               &dwSize) >0)
            {
               TRACE(L"Device Name = %s\nDevice handle = 0x%x\n", pszDeviceName.get(), pRawInput->header.hDevice);
            }
         }
      }
#endif

      RID_DEVICE_INFO sRidDeviceInfo;
      sRidDeviceInfo.cbSize = sizeof(RID_DEVICE_INFO);
      UINT cbSize = sizeof(RID_DEVICE_INFO);

      if (::GetRawInputDeviceInfo(pRawInput->header.hDevice,
         RIDI_DEVICEINFO,
         &sRidDeviceInfo,
         &cbSize) == cbSize)
      {
#if _TRACE_RIDI_DEVICEINFO
         switch (sRidDeviceInfo.dwType)
         {
         case RIM_TYPEMOUSE:
            TRACE(L"\tsRidDeviceInfo.dwType=RIM_TYPEMOUSE\n");
            break;

         case RIM_TYPEKEYBOARD:
            TRACE(L"\tsRidDeviceInfo.dwType=RIM_TYPEKEYBOARD\n");
            break;

         case RIM_TYPEHID:
            TRACE(L"\tsRidDeviceInfo.dwType=RIM_TYPEHID\n");
            TRACE(L"\tVendor=0x%x\n\tProduct=0x%x\n\tUsagePage=0x%x\n\tUsage=0x%x\n",
               sRidDeviceInfo.hid.dwVendorId, 
               sRidDeviceInfo.hid.dwProductId, 
               sRidDeviceInfo.hid.usUsagePage,
               sRidDeviceInfo.hid.usUsage);
            break;
         }
#endif
         if (sRidDeviceInfo.hid.dwVendorId == LOGITECH_VENDOR_ID)
         {
            if (pRawInput->data.hid.bRawData[0] == 0x01) // Translation vector
            {
               CInputData& deviceData = m_mapDevice2Data[pRawInput->header.hDevice];
               deviceData.timeToLive = CInputData::kTimeToLive;
               if (bIsForeground)
               {
                  short* pnRawData = reinterpret_cast<short*>(&pRawInput->data.hid.bRawData[1]);
                  // Cache the pan zoom data
                  deviceData.axes[0] = static_cast<float>(pnRawData[0]);
                  deviceData.axes[1] = static_cast<float>(pnRawData[1]);
                  deviceData.axes[2] = static_cast<float>(pnRawData[2]);

#if _TRACE_RI_RAWDATA
                  TRACE(L"Pan/Zoom RI Data =\t0x%x,\t0x%x,\t0x%x\n",
                     pnRawData[0],
                     pnRawData[1],
                     pnRawData[2]);
#endif
                  if (pRawInput->data.hid.dwSizeHid >= 13) // Highspeed package
                  {
                     // Cache the rotation data
                     deviceData.axes[3] = static_cast<float>(pnRawData[3]);
                     deviceData.axes[4] = static_cast<float>(pnRawData[4]);
                     deviceData.axes[5] = static_cast<float>(pnRawData[5]);
                     deviceData.isDirty = true;
#if _TRACE_RI_RAWDATA
                     TRACE(L"Rotation RI Data =\t0x%x,\t0x%x,\t0x%x\n",
                        pnRawData[3],
                        pnRawData[4],
                        pnRawData[5]);
#endif
                     return true;
                  }
               }
               else  // Zero out the data if the app is not in forground
                  deviceData.axes.assign(0.f);
            }
            else if (pRawInput->data.hid.bRawData[0] == 0x02)  // Rotation vector
            {
               // If we are not in foreground do nothing 
               // The rotation vector was zeroed out with the translation vector in the previous message
               if (bIsForeground)
               {
                  CInputData& deviceData = m_mapDevice2Data[pRawInput->header.hDevice];
                  deviceData.timeToLive = CInputData::kTimeToLive;

                  short* pnRawData = reinterpret_cast<short*>(&pRawInput->data.hid.bRawData[1]);
                  // Cache the rotation data
                  deviceData.axes[3] = static_cast<float>(pnRawData[0]);
                  deviceData.axes[4] = static_cast<float>(pnRawData[1]);
                  deviceData.axes[5] = static_cast<float>(pnRawData[2]);
                  deviceData.isDirty = true;

#if _TRACE_RI_RAWDATA
                  TRACE(L"Rotation RI Data =\t0x%x,\t0x%x,\t0x%x\n",
                     pnRawData[0],
                     pnRawData[1],
                     pnRawData[2]);
#endif
                  return true;
               }
            }
            /////////////////////////////////////////////////////////////////////////////////////////////
            // this is a package that contains 3d mouse keystate information
            // bit0=key1, bit=key2 etc.
            else if (pRawInput->data.hid.bRawData[0] == 0x03)  // Keystate change
            {
              CKeyData& keyStateCache = m_mapDevice2Keystate[pRawInput->header.hDevice];
              CKeyData previousKeyState = keyStateCache;

              size_t sizeHid = (pRawInput->data.hid.dwSizeHid-1) / (sizeof(CKeyData::key_array::value_type)/sizeof(pRawInput->data.hid.bRawData[0]));
              size_t nMaxCount = sizeHid < keyStateCache.keys.size() ? sizeHid : keyStateCache.keys.size();
              size_t i;
              for (i=0; i<nMaxCount; ++i)
                keyStateCache.keys[i] = reinterpret_cast<CKeyData::key_array::value_type *>(&pRawInput->data.hid.bRawData[1])[i];
              keyStateCache.dwProductId = sRidDeviceInfo.hid.dwProductId;

              CKeyData keyState = keyStateCache;
              if (keyState.IsZero())
                m_mapDevice2Keystate.erase(pRawInput->header.hDevice);

              //  Only call the keystate change handlers if the app is in foreground
              if (bIsForeground)
              {
                for (i=0; i<nMaxCount; ++i)
                {
#if _TRACE_RI_RAWDATA
                  TRACE(L"ButtonData[%d] =0x%x\n", i, keyState.keys[i]);
#endif        
                  CKeyData::key_array::value_type change = keyState.keys[i] ^ previousKeyState.keys[i];
                  if (!change)
                    continue;

                  size_t nKeycode;
                  size_t nLSB = i*sizeof(CKeyData::key_array::value_type)*8;
                  CKeyData::key_array::value_type mask = 0x01;

                  for (nKeycode=1+nLSB; nKeycode<1+nLSB+sizeof(CKeyData::key_array::value_type)*8; ++nKeycode)
                  {
                    if (change & mask)
                    {
                      int nVirtualKeyCode = tdx::HidToVirtualKey(keyState.dwProductId, static_cast<UINT>(nKeycode));
                      if (nVirtualKeyCode)
                      {
                        if (keyState.keys[i]&mask)
                          ::PostMessage(static_cast<T*>(this)->operator HWND(), WM_S3DM_KEYDOWN, nVirtualKeyCode, reinterpret_cast<LPARAM>(pRawInput->header.hDevice));
                        else
                          ::PostMessage(static_cast<T*>(this)->operator HWND(), WM_S3DM_KEYUP, nVirtualKeyCode, reinterpret_cast<LPARAM>(pRawInput->header.hDevice));
                      }
                    }
                    mask <<=1;
                  }
                }
              }
            }
         }
      }
      return false;
   }

public:
   // Method to access the standard 3d mouse parameters
   tdx::I3dmouseParam* Standard3dmouse()
   {
      return dynamic_cast<tdx::I3dmouseParam*>(&m_3dmouseParams);
   }

   // 3dmouse to app conversion parameters
   float m_f3dmouse2PanUnitsPerMillisecond;  // 3dmouse unit = 4.0e-6f world units per second
   float k3dmouse2AngularVelocity;   // 3dmouse unit = 8.0e-6f radians per second


   // Workaround for incorrect alignment of the RAWINPUT structure on x64 os
   // when running as Wow64
   UINT GetRawInputBuffer(PRAWINPUT pData, PUINT pcbSize, UINT cbSizeHeader)
   {
#ifdef _WIN64
     return ::GetRawInputBuffer(pData, pcbSize, cbSizeHeader);
#else
      BOOL bIsWow64=FALSE;
      ::IsWow64Process(GetCurrentProcess(), &bIsWow64);
      if (!bIsWow64 || pData==NULL)
        return ::GetRawInputBuffer(pData, pcbSize, cbSizeHeader);
      else
      {
         size_t cbDataSize=0;
         UINT nCount=0;
         PRAWINPUT pri = pData;

         MSG msg;
         while (PeekMessage(&msg
            , static_cast<T*>(this)->operator HWND()
            , WM_INPUT
            , WM_INPUT
            , PM_NOREMOVE))
         {
           HRAWINPUT hRawInput = reinterpret_cast<HRAWINPUT>(msg.lParam);
           size_t cbSize = *pcbSize - cbDataSize;
           if (::GetRawInputData(hRawInput, RID_INPUT, pri, &cbSize, cbSizeHeader) == static_cast<UINT>(-1))
           {
             if (nCount==0)
               return static_cast<UINT>(-1);
             else
               break;
           }
           ++nCount;

           // Remove the message for the data just read
           PeekMessage(&msg
                , static_cast<T*>(this)->operator HWND()
                , WM_INPUT
                , WM_INPUT
                , PM_REMOVE);

           pri = NEXTRAWINPUTBLOCK(pri);
           cbDataSize = reinterpret_cast<ULONG_PTR>(pri) - reinterpret_cast<ULONG_PTR>(pData);
           if (cbDataSize >= *pcbSize)
           {
             cbDataSize = *pcbSize;
             break;
           }
         }
         return nCount;
      }
#endif
   }


private:
   // 3dmouse parameters
   tdx::C3dmouseParams  m_3dmouseParams;     // Rotate, Pan Zoom etc.

   // use to calculate distance traveled since last event
   DWORD       m_dwLast3dmouseInputTime;

   // 3d mouse data polling timer
   UINT_PTR m_3dmouseTimer;               // only used if t_bPoll3dmouse == true
   UINT     m_u3dmousePollingPeriod; 

   // Data cache
   // To handle multiple rawinput devices
   std::map< HANDLE, CInputData>             m_mapDevice2Data;
   std::map< HANDLE, CKeyData>               m_mapDevice2Keystate;

   int                                       m_nActivePopupMenu;
};

#if _AFX
/////////////////////////////////////////////////////////////////////////////////
// Dummy base class for CRawInputMFCImplT
class _BaseClass 
{
public:
   void OnActivateApp(BOOL bActive, DWORD dwThreadID) {}
#if (_MFC_VER >= 0x0a00)
   void OnInputDeviceChange(unsigned short nFlags, HANDLE hDevice) {}
#else
   void OnInputDeviceChange(unsigned short nFlags) {}
#endif
   void OnRawInput(UINT nInputCode, HRAWINPUT hRawInput) {}
   void OnTimer(UINT_PTR nIDEvent) {}
};


/////////////////////////////////////////////////////////////////////////////////
// CRawInputMFCImplT 
template <class T, class TBase=_BaseClass, bool t_bPoll3dmouse=true> 
class CRawInputMFCImplT : public CRawInputImplT<T, t_bPoll3dmouse>, public TBase
{
public:
   typedef CRawInputMFCImplT<T, TBase, t_bPoll3dmouse> _MyRawInputMFCImpl;

protected:
   afx_msg void OnActivateApp(BOOL bActive, DWORD dwThreadID)
   {
      CRawInputImplT<T, t_bPoll3dmouse>::OnActivateApp(bActive, dwThreadID);
      TBase::OnActivateApp(bActive, dwThreadID);
   }

   afx_msg void OnInputDeviceChange(unsigned short nFlags, HANDLE hDevice)
   {
      CRawInputImplT<T, t_bPoll3dmouse>::OnInputDeviceChange(nFlags, HANDLE hDevice);
#if (_MFC_VER >= 0x0a00)
      TBase::OnInputDeviceChange(nFlags, HANDLE hDevice);
#elif (_MFC_VER > 0x0800)
      TBase::OnInputDeviceChange(nFlags);
#else
      static_cast<T*>(this)->DefWindowProc(WM_INPUT_DEVICE_CHANGE
         , static_cast<WPARAM>(nFlags)
         , static_cast<LPARAM>(hDevice));
#endif
   }

   afx_msg void OnRawInput(UINT nInputCode, HRAWINPUT hRawInput)
   {
      CRawInputImplT<T, t_bPoll3dmouse>::OnRawInput(nInputCode, hRawInput);
#if (_MFC_VER > 0x0800)
      TBase::OnRawInput(nInputCode, hRawInput);
#else
      static_cast<T*>(this)->DefWindowProc(WM_INPUT
         , static_cast<WPARAM>(nInputCode)
         , reinterpret_cast<LPARAM>(hRawInput));
#endif
   }

   afx_msg void OnTimer(UINT_PTR nIDEvent)
   {
      CRawInputImplT<T, t_bPoll3dmouse>::OnTimer(nIDEvent);
      TBase::OnTimer(nIDEvent);
   }
   
};
#endif // _AFX

#endif // rawinput_HPP_INCLUDED_