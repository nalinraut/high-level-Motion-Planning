#ifndef Stdafx_H_INCLUDED_
#define Stdafx_H_INCLUDED_
// stdafx.h : include file for standard system include files
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: stdafx.h 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#define VC_EXTRALEAN
#define WINVER 0x501

// Flavours
#define _AUTO_PIVOT_WHILE_MOVING 0

#include <afxwin.h>        // MFC core and standard components
#include <afxext.h>        // MFC extensions
#endif // Stdafx_H_INCLUDED_