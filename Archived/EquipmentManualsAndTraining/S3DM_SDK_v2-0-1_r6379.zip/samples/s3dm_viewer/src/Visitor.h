#ifndef Visitor_H_INCLUDED_
#define Visitor_H_INCLUDED_
// Visitor.h: interface for the Visitor class.
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: Visitor.h 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//

typedef bool (*VisitorCallback)(CGeomObj *, const Matrix3d &, void *, const std::vector<int>*);

class CVisitor  
{
public:
	explicit CVisitor(VisitorCallback pCallback , void *puserData, const std::vector<int>* pnodeFilter=NULL);
  bool operator ()(CGeomObj *pnode, const Matrix3d &accumMatrix);
  virtual ~CVisitor();
private:
	void *m_puserData;
  VisitorCallback m_pfunc;
  const std::vector<int>* m_pnodeFilter;
};

#endif // Visitor_H_INCLUDED_

