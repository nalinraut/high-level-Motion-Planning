// 3dmousexml.cpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: 3dmousexml.cpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 29.10.10 MSB Initial Design so that the libraries get linked in the right order
//
#include "stdafx.h"
extern "C"{
#include "3dmousexml.c"
}
