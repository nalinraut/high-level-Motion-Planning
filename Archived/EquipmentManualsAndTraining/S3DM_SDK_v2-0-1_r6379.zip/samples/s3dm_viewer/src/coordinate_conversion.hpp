#ifndef coordinate_conversion_HPP_INCLUDED_
#define coordinate_conversion_HPP_INCLUDED_
// coordinate_converion.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: coordinate_conversion.hpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 21.10.09 MSB Initial Design 
//
#include "array.hpp"
namespace tdx {
   /////////////////////////////////////////////////////////////////////////////////
   // hid_to_opengl
   template <typename _Ty> _Ty* hid_to_opengl_coord_system(_Ty _Array[6])
   {
      _Ty _Tmp[2] = {_Array[1],_Array[4]};
      _Array[1]=-_Array[2];
      _Array[2]=_Tmp[0];
      _Array[4]=-_Array[5];
      _Array[5]=_Tmp[1];
      return &_Array[0];
   }

   template <typename _Ty> _Ty* hid_to_opengl_coord_system(_Ty* _Dest, const _Ty _Src[6])
   {
      _Dest[0]=_Src[0];
      _Dest[1]=-_Src[2];
      _Dest[2]=_Src[1];
      _Dest[3]=_Src[3];
      _Dest[4]=-_Src[5];
      _Dest[5]=_Src[4];
      return _Dest;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,3>& hid_to_opengl_coord_system(ARRAY_NS::array<_Ty,3>& _Array)
   {
      _Ty _Tmp = {_Array[1]};
      _Array[1]=-_Array[2];
      _Array[2]=_Tmp[0];
      return _Array;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,6>& hid_to_opengl_coord_system(ARRAY_NS::array<_Ty,6>& _Array)
   {
      _Ty _Tmp[2] = {_Array[1],_Array[4]};
      _Array[1]=-_Array[2];
      _Array[2]=_Tmp[0];
      _Array[4]=-_Array[5];
      _Array[5]=_Tmp[1];
      return _Array;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,6>& hid_to_opengl_coord_system(ARRAY_NS::array<_Ty,6>& _Dest,const ARRAY_NS::array<_Ty,6>& _Src)
   {
      _Dest[0]=_Src[0];
      _Dest[1]=-_Src[2];
      _Dest[2]=_Src[1];
      _Dest[3]=_Src[3];
      _Dest[4]=-_Src[5];
      _Dest[5]=_Src[4];
      return _Dest;
   }
   /////////////////////////////////////////////////////////////////////////////////
   // hid_to_s80
   template <typename _Ty> _Ty* hid_to_s80_coord_system(_Ty _Array[6])
   {
      _Ty _Tmp[2] = {_Array[1],_Array[4]};
      _Array[1]=-_Array[2];
      _Array[2]=-_Tmp[0];
      _Array[4]=-_Array[5];
      _Array[5]=-_Tmp[1];
      return &_Array[0];
   }

   template <typename _Ty> _Ty* hid_to_s80_coord_system(_Ty* _Dest, const _Ty _Src[6])
   {
      _Dest[0]=_Src[0];
      _Dest[1]=-_Src[2];
      _Dest[2]=-_Src[1];
      _Dest[3]=_Src[3];
      _Dest[4]=-_Src[5];
      _Dest[5]=-_Src[4];
      return _Dest;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,6>& hid_to_s80_coord_system(ARRAY_NS::array<_Ty,6>& _Array)
   {
      _Ty _Tmp[2] = {_Array[1],_Array[4]};
      _Array[1]=-_Array[2];
      _Array[4]=-_Array[5];
      _Array[2]=-_Tmp[0];
      _Array[5]=-_Tmp[1];
      return _Array;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,6>& hid_to_s80_coord_system(ARRAY_NS::array<_Ty,6>& _Dest,const ARRAY_NS::array<_Ty,6>& _Src)
   {
      _Dest[0]=_Src[0];
      _Dest[1]=-_Src[2];
      _Dest[2]=-_Src[1];
      _Dest[3]=_Src[3];
      _Dest[4]=-_Src[5];
      _Dest[5]=-_Src[4];
      return _Dest;
   }
   /////////////////////////////////////////////////////////////////////////////////
   // lh_to_rh
   template <typename _Ty> _Ty* lh_to_rh_coord_system(_Ty _Array[6])
   {
      _Array[2]=-_Array[2];
      _Array[3]=-_Array[3];
      _Array[4]=-_Array[4];
      return &_Array[0];
   }

   template <typename _Ty> _Ty* lh_to_rh_coord_system(_Ty* _Dest, const _Ty _Src[6])
   {
      _Dest[0]=_Src[0];
      _Dest[1]=_Src[1];
      _Dest[2]=-_Src[2];
      _Dest[3]=-_Src[3];
      _Dest[4]=-_Src[4];
      _Dest[5]=_Src[5];
      return _Dest;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,6>& lh_to_rh_coord_system(ARRAY_NS::array<_Ty,6>& _Array)
   {
      _Array[2]=-_Array[2];
      _Array[3]=-_Array[3];
      _Array[4]=-_Array[4];
      return _Array;
   }

   template <typename _Ty> ARRAY_NS::array<_Ty,6>& lh_to_rh_coord_system(ARRAY_NS::array<_Ty,6>& _Dest,const ARRAY_NS::array<_Ty,6>& _Src)
   {
      _Dest[0]=_Src[0];
      _Dest[1]=_Src[1];
      _Dest[2]=-_Src[2];
      _Dest[3]=-_Src[3];
      _Dest[4]=-_Src[4];
      _Dest[5]=_Src[5];
      return _Dest;
   }

}; // namespace tdx
#endif // coordinate_conversion_HPP_INCLUDED_