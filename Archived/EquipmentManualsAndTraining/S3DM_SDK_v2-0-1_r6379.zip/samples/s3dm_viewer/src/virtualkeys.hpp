#ifndef virtualkeys_HPP_INCLUDED_
#define virtualkeys_HPP_INCLUDED_
// virtualkeys.hpp
/*
* Copyright notice:
* (c) 2010-2011 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: virtualkeys.hpp 6379 2011-01-21 15:53:08Z nuno_gomes $
//
// 19.01.11 MSB Added virtual key definitions for SPPro, SN and SNFN. This works
//              around data for non-existent buttons in the RI data structures.
// 19.10.10 MSB Moved the standard 3dmouse virtual buttons to the s3dm namespace
// 28.09.10 MSB Added spin and tilt buttons
//              Added structure to convert virtual key number to string identifier
// 04.12.09 MSB Fix spelling mistake 'panzoon'
//

#define _TRACE_VIRTUAL_KEYS 0

namespace s3dm {
   enum e3dmouse_virtual_key 
   {
      V3DK_INVALID=0
      , V3DK_MENU=1, V3DK_FIT
      , V3DK_TOP, V3DK_LEFT, V3DK_RIGHT, V3DK_FRONT, V3DK_BOTTOM, V3DK_BACK
      , V3DK_ROLL_CW, V3DK_ROLL_CCW
      , V3DK_ISO1, V3DK_ISO2
      , V3DK_1, V3DK_2, V3DK_3, V3DK_4, V3DK_5, V3DK_6, V3DK_7, V3DK_8, V3DK_9, V3DK_10
      , V3DK_ESC, V3DK_ALT, V3DK_SHIFT, V3DK_CTRL
      , V3DK_ROTATE, V3DK_PANZOOM, V3DK_DOMINANT
      , V3DK_PLUS, V3DK_MINUS
      , V3DK_SPIN_CW, V3DK_SPIN_CCW
      , V3DK_TILT_CW, V3DK_TILT_CCW
   };

   static const e3dmouse_virtual_key VirtualKeys[]=
   {
      V3DK_MENU, V3DK_FIT
      , V3DK_TOP, V3DK_LEFT, V3DK_RIGHT, V3DK_FRONT, V3DK_BOTTOM, V3DK_BACK
      , V3DK_ROLL_CW, V3DK_ROLL_CCW
      , V3DK_ISO1, V3DK_ISO2
      , V3DK_1, V3DK_2, V3DK_3, V3DK_4, V3DK_5, V3DK_6, V3DK_7, V3DK_8, V3DK_9, V3DK_10
      , V3DK_ESC, V3DK_ALT, V3DK_SHIFT, V3DK_CTRL
      , V3DK_ROTATE, V3DK_PANZOOM, V3DK_DOMINANT
      , V3DK_PLUS, V3DK_MINUS
      , V3DK_SPIN_CW, V3DK_SPIN_CCW
      , V3DK_TILT_CW, V3DK_TILT_CCW
   };

   static const size_t VirtualKeyCount = sizeof(VirtualKeys)/sizeof(VirtualKeys[0]);

   struct tag_VirtualKeyId
   {
     e3dmouse_virtual_key vkey;
     const wchar_t* szId;
   };

   static const struct tag_VirtualKeyId VirtualKeyId[] =
   {
     {V3DK_INVALID, L"V3DK_INVALID"}
     , {V3DK_MENU, L"V3DK_MENU"} , {V3DK_FIT, L"V3DK_FIT"}
     , {V3DK_TOP, L"V3DK_TOP"}, {V3DK_LEFT, L"V3DK_LEFT"}, {V3DK_RIGHT, L"V3DK_RIGHT"}, {V3DK_FRONT, L"V3DK_FRONT"}, {V3DK_BOTTOM, L"V3DK_BOTTOM"}, {V3DK_BACK, L"V3DK_BACK"}
     , {V3DK_ROLL_CW, L"V3DK_ROLL_CW"}, {V3DK_ROLL_CCW, L"V3DK_ROLL_CCW"}
     , {V3DK_ISO1, L"V3DK_ISO1"}, {V3DK_ISO2, L"V3DK_ISO2"}
     , {V3DK_1, L"V3DK_1"}, {V3DK_2, L"V3DK_2"}, {V3DK_3, L"V3DK_3"}, {V3DK_4, L"V3DK_4"}, {V3DK_5, L"V3DK_5"}
     , {V3DK_6, L"V3DK_6"}, {V3DK_7, L"V3DK_7"}, {V3DK_8, L"V3DK_8"}, {V3DK_9, L"V3DK_9"}, {V3DK_10, L"V3DK_10"}
     , {V3DK_ESC, L"V3DK_ESC"}, {V3DK_ALT, L"V3DK_ALT"}, {V3DK_SHIFT, L"V3DK_SHIFT"}, {V3DK_CTRL, L"V3DK_CTRL"}
     , {V3DK_ROTATE, L"V3DK_ROTATE"}, {V3DK_PANZOOM, L"V3DK_PANZOOM"}, {V3DK_DOMINANT, L"V3DK_DOMINANT"}
     , {V3DK_PLUS, L"V3DK_PLUS"}, {V3DK_MINUS, L"V3DK_MINUS"}
     , {V3DK_SPIN_CW, L"V3DK_SPIN_CW"}, {V3DK_SPIN_CCW, L"V3DK_SPIN_CCW"}
     , {V3DK_TILT_CW, L"V3DK_TILT_CW"}, {V3DK_TILT_CCW, L"V3DK_TILT_CCW"}
   };

   /*-----------------------------------------------------------------------------
   *
   * const TCHAR* VirtualKeyToId(e3dmouse_virtual_key virtualkey)
   *
   * Args:
   *    virtualkey  the 3dmouse virtual key 
   *
   * Return Value:
   *    Returns a string representation of the standard 3dmouse virtual key, or
   *    an empty string 
   *
   * Description:
   *    Converts a 3dmouse virtual key number to its string identifier
   *
   *---------------------------------------------------------------------------*/
   __inline const wchar_t* VirtualKeyToId(e3dmouse_virtual_key virtualkey)
   {
      if (0 < virtualkey && virtualkey <= sizeof(VirtualKeyId)/sizeof(VirtualKeyId[0]) 
        && virtualkey == VirtualKeyId[virtualkey-1].vkey)
        return VirtualKeyId[virtualkey-1].szId;

      for (size_t i=0; i<sizeof(VirtualKeyId)/sizeof(VirtualKeyId[0]); ++i)
      {
        if (VirtualKeyId[i].vkey == virtualkey)
          return VirtualKeyId[i].szId;
      }
      return L"";
   }
} // namespace s3dm

namespace tdx {
   enum e3dconnexion_pid {
      eSpacePilot = 0xc625,
      eSpaceNavigator = 0xc626,
      eSpaceExplorer = 0xc627,
      eSpaceNavigatorForNotebooks = 0xc628,
      eSpacePilotPRO = 0xc629
   };


   struct tag_VirtualKeys
   {
      e3dconnexion_pid pid;
      size_t nKeys;
      s3dm::e3dmouse_virtual_key *vkeys;
   };

   static const s3dm::e3dmouse_virtual_key SpaceExplorerKeys [] = 
   {
      s3dm::V3DK_INVALID     // there is no button 0
      , s3dm::V3DK_1, s3dm::V3DK_2
      , s3dm::V3DK_TOP, s3dm::V3DK_LEFT, s3dm::V3DK_RIGHT, s3dm::V3DK_FRONT
      , s3dm::V3DK_ESC, s3dm::V3DK_ALT, s3dm::V3DK_SHIFT, s3dm::V3DK_CTRL
      , s3dm::V3DK_FIT, s3dm::V3DK_MENU
      , s3dm::V3DK_PLUS, s3dm::V3DK_MINUS
      , s3dm::V3DK_ROTATE
   };

   static const s3dm::e3dmouse_virtual_key SpacePilotKeys [] = 
   {
      s3dm::V3DK_INVALID 
      , s3dm::V3DK_1, s3dm::V3DK_2, s3dm::V3DK_3, s3dm::V3DK_4, s3dm::V3DK_5, s3dm::V3DK_6
      , s3dm::V3DK_TOP, s3dm::V3DK_LEFT, s3dm::V3DK_RIGHT, s3dm::V3DK_FRONT
      , s3dm::V3DK_ESC, s3dm::V3DK_ALT, s3dm::V3DK_SHIFT, s3dm::V3DK_CTRL
      , s3dm::V3DK_FIT, s3dm::V3DK_MENU
      , s3dm::V3DK_PLUS, s3dm::V3DK_MINUS
      , s3dm::V3DK_DOMINANT, s3dm::V3DK_ROTATE
   };

   static const s3dm::e3dmouse_virtual_key SpaceNavigatorKeys [] = 
   {
      s3dm::V3DK_INVALID 
      , s3dm::V3DK_MENU, s3dm::V3DK_FIT
   };

   static const s3dm::e3dmouse_virtual_key SpacePilotProKeys [] = 
   {
      s3dm::V3DK_INVALID 
      , s3dm::V3DK_MENU, s3dm::V3DK_FIT
      , s3dm::V3DK_TOP, s3dm::V3DK_LEFT, s3dm::V3DK_RIGHT, s3dm::V3DK_FRONT, s3dm::V3DK_BOTTOM, s3dm::V3DK_BACK
      , s3dm::V3DK_ROLL_CW, s3dm::V3DK_ROLL_CCW
      , s3dm::V3DK_ISO1, s3dm::V3DK_ISO2
      , s3dm::V3DK_1, s3dm::V3DK_2, s3dm::V3DK_3, s3dm::V3DK_4, s3dm::V3DK_5
      , s3dm::V3DK_6, s3dm::V3DK_7, s3dm::V3DK_8, s3dm::V3DK_9, s3dm::V3DK_10
      , s3dm::V3DK_ESC, s3dm::V3DK_ALT, s3dm::V3DK_SHIFT, s3dm::V3DK_CTRL
      , s3dm::V3DK_ROTATE, s3dm::V3DK_PANZOOM, s3dm::V3DK_DOMINANT
      , s3dm::V3DK_PLUS, s3dm::V3DK_MINUS
   };

   static const struct tag_VirtualKeys _3dmouseVirtualKeys[]= 
   {
      eSpacePilot
      , sizeof(SpacePilotKeys)/sizeof(SpacePilotKeys[0])
      , const_cast<s3dm::e3dmouse_virtual_key *>(SpacePilotKeys),
      eSpaceExplorer
      , sizeof(SpaceExplorerKeys)/sizeof(SpaceExplorerKeys[0])
      , const_cast<s3dm::e3dmouse_virtual_key *>(SpaceExplorerKeys),
      eSpaceNavigator
      , sizeof(SpaceNavigatorKeys)/sizeof(SpaceNavigatorKeys[0])
      , const_cast<s3dm::e3dmouse_virtual_key *>(SpaceNavigatorKeys),
      eSpaceNavigatorForNotebooks
      , sizeof(SpaceNavigatorKeys)/sizeof(SpaceNavigatorKeys[0])
      , const_cast<s3dm::e3dmouse_virtual_key *>(SpaceNavigatorKeys),
      eSpacePilotPRO
      , sizeof(SpacePilotProKeys)/sizeof(SpacePilotProKeys[0])
      , const_cast<s3dm::e3dmouse_virtual_key *>(SpacePilotProKeys)
   };

   /*-----------------------------------------------------------------------------
   *
   * unsigned short HidToVirtualKey(unsigned short pid, unsigned short hidKeyCode)
   *
   * Args:
   *    pid - USB Product ID (PID) of 3D mouse device 
   *    hidKeyCode - Hid keycode as retrieved from a Raw Input packet
   *
   * Return Value:
   *    Returns the standard 3d mouse virtual key (button identifier) or zero if an error occurs.
   *
   * Description:
   *    Converts a hid device keycode (button identifier) of a pre-2009 3Dconnexion USB device
   *    to the standard 3d mouse virtual key definition.
   *
   *---------------------------------------------------------------------------*/
   __inline unsigned short HidToVirtualKey(unsigned long pid, unsigned short hidKeyCode)
   {
      unsigned short virtualkey=hidKeyCode;
      for (size_t i=0; i<sizeof(_3dmouseVirtualKeys)/sizeof(_3dmouseVirtualKeys[0]); ++i)
      {
         if (pid == _3dmouseVirtualKeys[i].pid)
         {
            if (hidKeyCode < _3dmouseVirtualKeys[i].nKeys)
               virtualkey = _3dmouseVirtualKeys[i].vkeys[hidKeyCode];
            else
              virtualkey = s3dm::V3DK_INVALID;
            break;
         }
      }
      // Remaining devices are unchanged
#if _TRACE_VIRTUAL_KEYS
     TRACE(L"Converted %d to %s(=%d) for pid 0x%x\n", hidKeyCode, VirtualKeyToId(virtualkey), virtualkey, pid);
#endif
      return virtualkey;
   }
}; //namespace tdx
#endif // virtualkeys_HPP_INCLUDED_