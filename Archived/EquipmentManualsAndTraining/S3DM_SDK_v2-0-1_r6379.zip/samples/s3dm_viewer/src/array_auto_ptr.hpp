#ifndef array_auto_ptr_HPP_INCLUDED_
#define array_auto_ptr_HPP_INCLUDED_
// array_auto_ptr.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: array_auto_ptr.hpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 21.10.09 MSB Initial Design 
//
#include <memory>

namespace tdx {
   /////////////////////////////////////////////////////////////////////////////////
   // array_auto_ptr
   template <class _Ty> class array_auto_ptr: public std::auto_ptr<_Ty>
   {
   public:
	   typedef _Ty& reference;
   	typedef const _Ty& const_reference;
	   typedef _Ty value_type;

	   explicit array_auto_ptr(_Ty *_Ptr = 0) _THROW0()
		   : auto_ptr(_Ptr) 
		   {	// construct from object pointer
		   }

	   void reset(_Ty* _Ptr = 0) _THROW0()
	   {	// destroy designated object and store new pointer
	      if (_Ptr != get())
		      delete[] release();
         if (_Ptr)
            __super::reset(_Ptr);
	   }

      const_reference operator[] (size_t _Idx) const _THROW0()
      {
         return get()[_Idx];
      }

      reference operator[] (size_t _Idx) _THROW0()
      {
         return get()[_Idx];
      }

      ~array_auto_ptr(){ delete[] release();}
   };

}; // namespace tdx
#endif // array_auto_ptr_HPP_INCLUDED_