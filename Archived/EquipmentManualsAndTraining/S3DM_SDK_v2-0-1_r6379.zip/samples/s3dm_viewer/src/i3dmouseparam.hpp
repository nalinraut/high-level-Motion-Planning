#ifndef I3dmouseParam_HPP_INCLUDED_
#define I3dmouseParam_HPP_INCLUDED_
// i3dmouseparam.hpp
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#ifndef __cplusplus
#error i3dmouseparam requires C++ compilation (use a .cpp suffix)
#endif
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: i3dmouseparam.hpp 6272 2010-11-22 15:24:01Z markus_bonk $
//
// 10.12.09 MSB Added LockHorizon to Navigation interface
// 20.10.09 MSB Initial Design 
//
#include "s3dm_resource.h"

namespace tdx {
   /////////////////////////////////////////////////////////////////////////////////
   // I3dmouseSensor
  enum eSpeed {
    lowSpeed = 0,
    slowerSpeed,
    midSpeed,
    fasterSpeed,
    highSpeed
  };

  static const float eSpeed2factor[] = {0.25, 0.5, 1.0, 2.0, 4.0};

   class I3dmouseSensor
   {
   protected:
      virtual ~I3dmouseSensor(){}
   public:
      virtual bool IsSingleAxisFilter() =0;
      virtual bool IsPanZoom() =0;
      virtual bool IsRotate() =0;
      virtual eSpeed GetSpeed() =0;
      virtual void SetPanZoom(bool isPanZoom) =0;
      virtual void SetRotate(bool isRotate) =0;
      virtual void SetSpeed(eSpeed speed) =0;
      virtual void SetSingleAxisFilter(bool on) =0;
   }; // I3dmouseSensor

   /////////////////////////////////////////////////////////////////////////////////
   // I3dmouseNavigation
   enum ePivot {
      manualPivot = 0,
      autoPivot
   };

  enum eNavigation {
    objectMode = 0,
    cameraMode,
    flyMode,
    walkMode,
    helicopterMode,
    targetCameraMode
  };

   enum ePivotVisibility {
      hidePivot = 0,
      showPivot,
      showMovingPivot
   };

   class I3dmouseNavigation
   {
   protected:
      virtual ~I3dmouseNavigation(){}
   public:
      virtual eNavigation GetNavigationMode() =0;
      virtual ePivot GetPivotMode() =0;
      virtual ePivotVisibility GetPivotVisibility() =0;
      virtual bool IsLockHorizon() =0;
      virtual bool IsSelectionFollower() const=0;
      virtual void SetLockHorizon(bool bOn) =0;
      virtual void SetNavigationMode(eNavigation navigation) =0;
      virtual void SetPivotMode(ePivot pivot) =0;
      virtual void SetPivotVisibility(ePivotVisibility visibility) =0;
      virtual void SetSelectionFollower(bool bOn) =0;
   }; // I3dmouseNavigation


   /////////////////////////////////////////////////////////////////////////////////
   // I3dmouseParam
   class I3dmouseParam : public I3dmouseSensor
      , public I3dmouseNavigation
   {
   public:
      virtual void Save() =0;
      virtual void Load() =0;
   };

}; // namespace tdx
#endif // I3dmouseParam_HPP_INCLUDED_