// MCADview.cpp : implementation of the CMCADView class
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#include "stdafx.h"
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: mcadview.cpp 6377 2011-01-19 13:56:18Z markus_bonk $
//
// 23.11.10 MSB Fix [5568] "Show On Motion" does not work correctly if "Auto" is disabled. The
//              Pivot remains visible.
// 16.11.10 MSB Fix [5558] Rotation center calculation is broken under certain circumstances
// 17.09.10 MSB Changed AutoPivot to use include a selection filter 
// 15.09.10 MSB Changed selection indicator to highlighted wireframe
// 10.05.10 MSB Pivot is not drawn if no 3dmouse attached
// 20.10.09 MSB Originally based on code from Jim Wick's BycycleDI sample
//

/* SceneAndNodeHitTestFlags Scene and Node Hit Testing Flags
The following describes hit testing flags that can be sent to the node and 
scene hit testing methods */
// Hit test selected items only.
#define HIT_SELONLY				(1<<0)
// Hit test unselected items only.
#define HIT_UNSELONLY			(1<<2)


#include "s3dm_viewer.h"

#include "MCADdoc.h"
#include "MCADview.h"
#include "Mainfrm.h"

#include "gl\gl.h"
#include "gl\glu.h"

#include "Matrix3d.h"

// c runtime
#include <math.h>


#include <algorithm>

#ifdef _DEBUG
#undef THIS_FILE
static char BASED_CODE THIS_FILE[] = __FILE__;
#endif

#define _PROFILE_AUTOPIVOT 0
#define _TRACE_PICK 0
#define _TRACE_PIVOT 0
#define _PIVOT_BITMAP_TEST 0
#define _TRACE_TIMER 0
#define _TRACE_COV 0

unsigned char threeto8[8] =
{
  0, 0111>>1, 0222>>1, 0333>>1, 0444>>1, 0555>>1, 0666>>1, 0377
};

unsigned char twoto8[4] =
{
  0, 0x55, 0xaa, 0xff
};

unsigned char oneto8[2] =
{
  0, 255
};

static int defaultOverride[13] =
{
  0, 3, 24, 27, 64, 67, 88, 173, 181, 236, 247, 164, 91
};

static PALETTEENTRY defaultPalEntry[20] =
{
  { 0,   0,   0,    0 },
  { 0x80,0,   0,    0 },
  { 0,   0x80,0,    0 },
  { 0x80,0x80,0,    0 },
  { 0,   0,   0x80, 0 },
  { 0x80,0,   0x80, 0 },
  { 0,   0x80,0x80, 0 },
  { 0xC0,0xC0,0xC0, 0 },

  { 192, 220, 192,  0 },
  { 166, 202, 240,  0 },
  { 255, 251, 240,  0 },
  { 160, 160, 164,  0 },

  { 0x80,0x80,0x80, 0 },
  { 0xFF,0,   0,    0 },
  { 0,   0xFF,0,    0 },
  { 0xFF,0xFF,0,    0 },
  { 0,   0,   0xFF, 0 },
  { 0xFF,0,   0xFF, 0 },
  { 0,   0xFF,0xFF, 0 },
  { 0xFF,0xFF,0xFF, 0 }
};

/////////////////////////////////////////////////////////////////////////////
// CMCADView

IMPLEMENT_DYNCREATE(CMCADView, CView)

BEGIN_MESSAGE_MAP(CMCADView, CView)
  //{{AFX_MSG_MAP(CMCADView)
  ON_WM_CREATE()
  ON_WM_DESTROY()
  ON_WM_SIZE()
  ON_WM_ERASEBKGND()
  ON_WM_LBUTTONDOWN()
  ON_WM_MBUTTONDOWN()
  ON_WM_KEYDOWN()
  ON_WM_KEYUP()
  ON_WM_TIMER()
  //}}AFX_MSG_MAP
  ON_COMMAND(ID_PROJECTION_PERSPECTIVE, &CMCADView::OnProjectionPerspective)
  ON_COMMAND(ID_PROJECTION_PARALLEL, &CMCADView::OnProjectionParallel)
  ON_COMMAND(ID_PROJECTION_2D, &CMCADView::OnProjection2d)
  ON_COMMAND(ID_VIEW_SHOWGRID, &CMCADView::OnToggleGrid)
  ON_UPDATE_COMMAND_UI(ID_PROJECTION_PERSPECTIVE, &CMCADView::OnUpdateProjectionPerspective)
  ON_UPDATE_COMMAND_UI(ID_PROJECTION_PARALLEL, &CMCADView::OnUpdateProjectionParallel)
  ON_UPDATE_COMMAND_UI(ID_PROJECTION_2D, &CMCADView::OnUpdateProjection2d)
  ON_UPDATE_COMMAND_UI(ID_VIEW_SHOWGRID, &CMCADView::OnUpdateShowGrid)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMCADView construction/destruction

#pragma warning( push )
#pragma warning( disable : 4355) 
CMCADView::CMCADView() : m_pOldPalette(NULL)
, m_pDC(NULL)
, m_3dcontroller(*this)
, m_isDrawing(FALSE)
, m_ControlKeyDepressed(FALSE)
, m_ShiftKeyDepressed(FALSE)
, m_bUserPivot(false)
, m_animationTimer(NULL)
, m_uAnimationUpdatePeriod(10)
, m_animationTimeToLive(0)
, m_bRedrawView(false)
, m_bRedrawFrustum(false)
, m_projection(ePerspective)
, m_renderStyle(eSmoothShaded)
, m_bShowGrid(true)
{
}
#pragma warning( pop )

CMCADView::~CMCADView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CMCADView drawing

void CMCADView::OnDraw(CDC* pDC)
{
  CMCADDoc* pDoc = GetDocument();
  ASSERT_VALID(pDoc);

  DrawScene();
}

/////////////////////////////////////////////////////////////////////////////
// CMCADView diagnostics

#ifdef _DEBUG
void CMCADView::AssertValid() const
{
  CView::AssertValid();
}

void CMCADView::Dump(CDumpContext& dc) const
{
  CView::Dump(dc);
}

CMCADDoc* CMCADView::GetDocument() // non-debug version is inline
{
  return STATIC_DOWNCAST(CMCADDoc, m_pDocument);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMCADView message handlers
BOOL CMCADView::PreCreateWindow(CREATESTRUCT& cs)
{
  // An OpenGL window must be created with the following flags and must not
  // include CS_PARENTDC for the class style. Refer to SetPixelFormat
  // documentation in the "Comments" section for further information.
  cs.style |= WS_CLIPSIBLINGS | WS_CLIPCHILDREN;

  return CView::PreCreateWindow(cs);
}

int CMCADView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
  if (CView::OnCreate(lpCreateStruct) == -1)
    return -1;

  m_pMainFrame = dynamic_cast<CMainFrame*>(EnsureParentFrame());

  // Link up the ViewObj in the Doc to this view.
  GetDocument()->Camera->m_plinkedView = this;

  InitGL(); // initialize OpenGL


#if _PIVOT_BITMAP_TEST
  m_imageManualPivot.Load(_T("pivot_white.png"));
  m_imageAutoPivot.Load(_T("pivot_blue.png"));
#else
  m_imageManualPivot.LoadFromResource(AfxGetResourceHandle(), S3DM_IDB_AutoPivot);
  m_imageAutoPivot.LoadFromResource(AfxGetResourceHandle(), S3DM_IDB_ManualPivot);
#endif
  return 0;

}

void CMCADView::OnInitialUpdate()
{
  Matrix3d iso( sqrt(0.5),  -sqrt(1./6.),   sqrt(1./3.),  2.,
    0.,          sqrt(2./3.),   sqrt(1./3.),  2.,
    -sqrt(0.5), -sqrt(1./6.),   sqrt(1./3.),  2.,
    0.,         0.,             0.,           1.);

  GetDocument()->Camera->m_positionInParent = iso;

  Matrix3d worldToCameraTM=GetDocument()->Camera->m_positionInParent.Inverse();
  // Get the extents of the model
  CExtents extents = GetDocument()->Model->GetExtents(worldToCameraTM);

  // Calculate the z position relative to the center of the
  // bounding box
  Vector3d boundingbox = extents.m_maxPt-extents.m_minPt;
  if (boundingbox.Length() < epsilon)
  {
    m_extentsGrid = 10.;
    // use the grid
    Vector3d extentsMax, extentsMin;
    for (int i =0; i<2; ++i)
    {
      for (int j =0; j<2; ++j)
      {
        Vector3d corner(i ? m_extentsGrid : -m_extentsGrid, 0., j ? m_extentsGrid : -m_extentsGrid);
        corner = worldToCameraTM * corner;
        if (i==0 && j==0)
          extentsMin = extentsMax = corner;
        for (int k=0; k<3; ++k)
        {
          if (corner.v[k] < extentsMin.v[k]) extentsMin.v[k] = corner.v[k];
          else if (corner.v[k] > extentsMax.v[k]) extentsMax.v[k] = corner.v[k];
        }
      }
    }
    boundingbox =  extentsMax - extentsMin;
  }
  else
  {
    int power = static_cast<int>(log10(boundingbox.Length())+1.);
    m_extentsGrid = exp(static_cast<double>(power) * log(10.));
  }
  m_frustumFarClippingPlane = 10.*m_extentsGrid;

  FOV = kDefaultFOV;
  Vector3d zoomCC;
  if (fabs(boundingbox.x/(m_frustumRight-m_frustumLeft)) > fabs(boundingbox.y/(m_frustumTop-m_frustumBottom)))
    zoomCC.z=fabs(boundingbox.x/(m_frustumRight-m_frustumLeft))*m_frustumNearDistance+boundingbox.z/2.;
  else
    zoomCC.z=fabs(boundingbox.y/(m_frustumTop-m_frustumBottom))*m_frustumNearDistance+boundingbox.z/2.;

  m_targetDistance = zoomCC.z;
  m_focalDistance = zoomCC.z;

  if (m_frustumFarClippingPlane < zoomCC.z *100.)
    m_frustumFarClippingPlane = zoomCC.z *100.;

  // clear the selection list
  m_selection.clear();

  m_bUserPivot = false;

  ZoomExtents();

  m_pMainFrame->RecalculateAutoPivot(true); 

}

void CMCADView::OnDestroy()
{
  HGLRC   hrc;

  hrc = ::wglGetCurrentContext();

  ::wglMakeCurrent(NULL,  NULL);

  if (hrc)
    ::wglDeleteContext(hrc);

  if (m_pOldPalette)
    m_pDC->SelectPalette(m_pOldPalette, FALSE);

  if (m_pDC)
    delete m_pDC;

  CView::OnDestroy();
}

void CMCADView::OnSize(UINT nType, int cx, int cy)
{
  CView::OnSize(nType, cx, cy);

  if(cy > 0)
  {
    glViewport(0, 0, cx, cy);

    m_clientRect.right = cx;
    m_clientRect.bottom = cy;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    double aspectRatio = static_cast<double>(m_clientRect.bottom)/static_cast<double>(m_clientRect.right);
    m_frustumTop    = (m_frustumRight-m_frustumLeft)*aspectRatio/2.;
    m_frustumBottom = -m_frustumTop;
    m_bRedrawFrustum = true;

    DrawScene();
  }
}


/////////////////////////////////////////////////////////////////////////////
// GL helper functions

void CMCADView::InitGL()
{
  PIXELFORMATDESCRIPTOR pfd;
  int         n;
  HGLRC       hrc;

  m_pDC = new CClientDC(this);

  ASSERT(m_pDC != NULL);

  if (!SetupPixelFormat())
    return;

  n = ::GetPixelFormat(m_pDC->GetSafeHdc());
  ::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);

  CreateRGBPalette();

  hrc = wglCreateContext(m_pDC->GetSafeHdc());
  wglMakeCurrent(m_pDC->GetSafeHdc(), hrc);

  glShadeModel(GL_SMOOTH);						// enables smooth shading
  glClearColor(0.0, 0.0, 0.0, 1.0);         // clear color
  glClearDepth(1.0f);							   // depth buffer setup
  glEnable(GL_DEPTH_TEST);						// enables depth testing
  glDepthFunc(GL_LEQUAL);							// type of depth test to do
  glEnable(GL_DITHER);                      // dither color components 


  glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);			// really nice perspective calculations
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);       // blend function to use
  glEnable(GL_BLEND);                                      // enable blending


  // define materials and lights
  GLfloat mat_specular[] = {.35f,.35f,.35f,1.f};
  GLfloat mat_shininess[]= {50.0};
  GLfloat light_model_ambient[] =  {0.2f,0.2f,0.2f,1.f};
  GLfloat light_model_two_side[]={1.0};
  GLfloat light_model_local_viewer[]={1.0};
  GLfloat light0_diffuse[] =  {.8f,.8f,.8f,1.f};
  GLfloat light0_position[] =  {0.f,0.f,1.f,1.f};

  glDisable(GL_CULL_FACE);  // Disable if we have bad normals (ordering)
  glCullFace(GL_BACK);

  glMaterialfv(GL_FRONT_AND_BACK, GL_SPECULAR, mat_specular);
  glMaterialfv(GL_FRONT_AND_BACK, GL_SHININESS, mat_shininess);

  glLightModelfv(GL_LIGHT_MODEL_LOCAL_VIEWER, light_model_local_viewer);
  glLightModelfv(GL_LIGHT_MODEL_AMBIENT, light_model_ambient);
  glLightModelfv(GL_LIGHT_MODEL_TWO_SIDE, light_model_two_side);  // for .obj files
  glLightfv(GL_LIGHT0, GL_POSITION, light0_position);
  glLightfv(GL_LIGHT0, GL_DIFFUSE, light0_diffuse);
  glLightfv(GL_LIGHT0, GL_AMBIENT, light_model_ambient);

  glDrawBuffer(GL_BACK);
  glEnable(GL_LIGHTING);
  glEnable(GL_LIGHT0);

  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();

  glMatrixMode(GL_MODELVIEW);
  glLoadIdentity();

  m_frustumNearClippingPlane = 0.01;
  m_frustumRight  =  0.005;
  m_frustumLeft   = -m_frustumRight;
  m_frustumNearDistance = m_frustumNearClippingPlane;
  m_frustumFarClippingPlane  = 1000.;
  m_frustumTop    = 1.0;
  m_frustumBottom = -m_frustumTop;
}

BOOL CMCADView::SetupPixelFormat()
{
  static PIXELFORMATDESCRIPTOR pfd =
  {
    sizeof(PIXELFORMATDESCRIPTOR),  // size of this pfd
    1,                              // version number
    PFD_DRAW_TO_WINDOW |            // support window
    PFD_SUPPORT_OPENGL |            // support OpenGL
    PFD_DOUBLEBUFFER,               // double buffered
    PFD_TYPE_RGBA,                  // RGBA type
    24,                             // 24-bit color depth
    0, 0, 0, 0, 0, 0,               // color bits ignored
    0,                              // no alpha buffer
    0,                              // shift bit ignored
    0,                              // no accumulation buffer
    0, 0, 0, 0,                     // accum bits ignored
    32,                             // 32-bit z-buffer
    0,                              // no stencil buffer
    0,                              // no auxiliary buffer
    PFD_MAIN_PLANE,                 // main layer
    0,                              // reserved
    0, 0, 0                         // layer masks ignored
  };
  int pixelformat;

  if ( (pixelformat = ::ChoosePixelFormat(m_pDC->GetSafeHdc(), &pfd)) == 0 )
  {
    MessageBox(TEXT("ChoosePixelFormat failed"));
    return FALSE;
  }

  if (SetPixelFormat(m_pDC->GetSafeHdc(), pixelformat, &pfd) == FALSE)
  {
    MessageBox(TEXT("SetPixelFormat failed"));
    return FALSE;
  }

  return TRUE;
}

unsigned char CMCADView::ComponentFromIndex(int i, UINT nbits, UINT shift)
{
  unsigned char val;

  val = (unsigned char) (i >> shift);
  switch (nbits)
  {

  case 1:
    val &= 0x1;
    return oneto8[val];
  case 2:
    val &= 0x3;
    return twoto8[val];
  case 3:
    val &= 0x7;
    return threeto8[val];

  default:
    return 0;
  }
}


void CMCADView::CreateRGBPalette()
{
  PIXELFORMATDESCRIPTOR pfd;
  LOGPALETTE *pPal;
  int n, i;

  n = ::GetPixelFormat(m_pDC->GetSafeHdc());
  ::DescribePixelFormat(m_pDC->GetSafeHdc(), n, sizeof(pfd), &pfd);

  if (pfd.dwFlags & PFD_NEED_PALETTE)
  {
    n = 1 << pfd.cColorBits;
    pPal = (PLOGPALETTE) new char[sizeof(LOGPALETTE) + n * sizeof(PALETTEENTRY)];

    ASSERT(pPal != NULL);

    pPal->palVersion = 0x300;
    pPal->palNumEntries = n;
    for (i=0; i<n; i++)
    {
      pPal->palPalEntry[i].peRed =
        ComponentFromIndex(i, pfd.cRedBits, pfd.cRedShift);
      pPal->palPalEntry[i].peGreen =
        ComponentFromIndex(i, pfd.cGreenBits, pfd.cGreenShift);
      pPal->palPalEntry[i].peBlue =
        ComponentFromIndex(i, pfd.cBlueBits, pfd.cBlueShift);
      pPal->palPalEntry[i].peFlags = 0;
    }

    /* fix up the palette to include the default GDI palette */
    if ((pfd.cColorBits == 8)                          &&
      (pfd.cRedBits   == 3) && (pfd.cRedShift   == 0) &&
      (pfd.cGreenBits == 3) && (pfd.cGreenShift == 3) &&
      (pfd.cBlueBits  == 2) && (pfd.cBlueShift  == 6)
      )
    {
      for (i = 1 ; i <= 12 ; i++)
        pPal->palPalEntry[defaultOverride[i]] = defaultPalEntry[i];
    }

    m_cPalette.CreatePalette(pPal);
    delete pPal;

    m_pOldPalette = m_pDC->SelectPalette(&m_cPalette, FALSE);
    m_pDC->RealizePalette();
  }
}

void CMCADView::DrawGrid()
{
  if (m_bShowGrid)
  {
    glBegin(GL_LINES);
    glNormal3f(0.f,1.f,0.f);

    float ka[4] = {1.f, 1.f, 1.f, 1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_AMBIENT, ka);
    float kd[4] = {.2f, .2f, .2f, 1.0f};
    glMaterialfv(GL_FRONT_AND_BACK, GL_DIFFUSE, kd);

    for (int i=-10; i<=10; i++)
    {
      if (i==0) { glColor3f(.6f,.3f,.3f); } else { glColor3f(.25f,.25f,.25f); };
      glVertex3f(static_cast<float>(i)*static_cast<float>(m_extentsGrid/10.),0.,-static_cast<float>(m_extentsGrid));
      glVertex3f(static_cast<float>(i)*static_cast<float>(m_extentsGrid/10.),0.,static_cast<float>(m_extentsGrid));
      if (i==0) { glColor3f(.3f,.3f,.6f); } else { glColor3f(.25f,.25f,.25f); };
      glVertex3f(-static_cast<float>(m_extentsGrid),0.,static_cast<float>(i)*static_cast<float>(m_extentsGrid/10.));
      glVertex3f(static_cast<float>(m_extentsGrid),0.,static_cast<float>(i)*static_cast<float>(m_extentsGrid/10.));
    }
    glEnd();
  }
}

void CMCADView::DrawScene(void)
{
  if (InterlockedExchange (&m_isDrawing, TRUE))
    return;

  if (m_bRedrawFrustum)
  {
    m_bRedrawFrustum = false;
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    SetFrustum();
    glMatrixMode(GL_MODELVIEW);
  }

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
  glLoadIdentity();

  // Multiply by the view matrix first (worldToEye)
  Matrix3d worldToCameraTM=(GetDocument()->Camera->m_positionInParent).Inverse();
  glMultMatrixd(worldToCameraTM.openGLformat());

  DrawGrid();

  DrawObjects(GetDocument()->Model, m_renderStyle, 0);

  DrawPivot();

  glFlush();

  SwapBuffers(wglGetCurrentDC());

  m_isDrawing = FALSE; 
}


// Helper class to automatically set and restore OpenGL seetings
class OpenGLPivotSettings
{
public:
  OpenGLPivotSettings()
  {
    // Enable blend (use alpha channel to render bitmaps)
    m_BlendEnabled = glIsEnabled(GL_BLEND);
    if (m_BlendEnabled == GL_FALSE)
      glEnable(GL_BLEND);

    // Disable the z-buffer (is that true?)
    glGetBooleanv(GL_DEPTH_WRITEMASK, &m_DepthMask);
    if (m_DepthMask == GL_TRUE)
      glDepthMask(GL_FALSE);
    // Disable depth test
    m_DepthTestEnabled = glIsEnabled(GL_DEPTH_TEST);
    if (m_DepthTestEnabled == GL_TRUE)
      glDisable(GL_DEPTH_TEST);
    // Disable all clipping planes
    for (int i = 0; i < 6; i++)
    {
      m_ClipPlaneEnabled[i] = glIsEnabled(GL_CLIP_PLANE0 + i);
      if (m_ClipPlaneEnabled[i] == GL_TRUE)
        glDisable(GL_CLIP_PLANE0 + i);
    }
  }

  ~OpenGLPivotSettings()
  {
    // Restore settings
    for (int i = 0; i < 6; i++)
    {
      if (m_ClipPlaneEnabled[i] == GL_TRUE)
        glEnable(GL_CLIP_PLANE0 + i);
    }

    if (m_DepthTestEnabled == GL_TRUE)
      glEnable(GL_DEPTH_TEST);

    if (m_DepthMask == GL_TRUE)
      glDepthMask(GL_TRUE);

    if (m_BlendEnabled == GL_FALSE)
      glDisable(GL_BLEND);

  }

private:
  GLboolean m_DepthMask;
  GLboolean m_BlendEnabled;
  GLboolean m_DepthTestEnabled;
  GLboolean m_ClipPlaneEnabled[6];
};


void CMCADView::DrawPivot()
{
  if (!m_pMainFrame->Is3dmouseAttached())
    return;

  if ((Standard3dmouse()->GetPivotVisibility() == tdx::hidePivot) ||
    (!m_3dcontroller.IsMoving() && (Standard3dmouse()->GetPivotVisibility() == tdx::showMovingPivot)))
    return;

  CImage* pimagePivot;
  Vector3d pivotWC;

  if (Standard3dmouse()->GetNavigationMode() == tdx::objectMode
    || Standard3dmouse()->GetNavigationMode()==tdx::targetCameraMode)
  {
    if (Standard3dmouse()->GetPivotMode() == tdx::autoPivot)
      pimagePivot = &m_imageAutoPivot;
    else
      pimagePivot = &m_imageManualPivot;

    // Multiply by the model matrix (modelToWorld)
    Matrix3d modelToWorldTM=GetDocument()->Model->m_positionInParent;
    pivotWC = modelToWorldTM * m_3dcontroller.CenterOfRotation;
  }
  else
    return;

  float pixelZoom=1.f;
  std::auto_ptr<OpenGLPivotSettings> ogls(new OpenGLPivotSettings);

  // Draw the pivot
  glPushMatrix();

  glRasterPos3d(pivotWC.x, pivotWC.y, pivotWC.z);
  if (pimagePivot->GetPitch() > 0)
  { 
    glPixelZoom (pixelZoom, -pixelZoom);
    glBitmap(0,0,0,0
      , -static_cast<float>(pimagePivot->GetWidth()>>1)
      , static_cast<float>(pimagePivot->GetHeight()>>1), NULL);
    glDrawPixels(pimagePivot->GetWidth()
      , pimagePivot->GetHeight()
      , GL_BGRA_EXT
      , GL_UNSIGNED_BYTE
      , pimagePivot->GetPixelAddress(0,0));
  }
  else
  {// bottom up image
    glPixelZoom (pixelZoom, pixelZoom);
    glBitmap(0,0,0,0
      , -static_cast<float>(pimagePivot->GetWidth()>>1)
      , -static_cast<float>(pimagePivot->GetHeight()>>1), NULL);
    glDrawPixels(pimagePivot->GetWidth()
      , pimagePivot->GetHeight()
      , GL_BGRA_EXT
      , GL_UNSIGNED_BYTE
      , pimagePivot->GetPixelAddress(0,pimagePivot->GetHeight()-1));
  }

  glPopMatrix();

  ogls.reset();   
}

// This method draws one level of objects.  I.e., all objects that are siblings.
// If it encounters a node that has children, it recursively calls itself.
void CMCADView::DrawObjects(CGeomObj *pGeomObj, eRenderStyle renderStyle)
{
  DrawObjects(pGeomObj, renderStyle, 0);
}

void CMCADView::DrawObjects(CGeomObj *pGeomObj, eRenderStyle renderStyle, int flags)
{
  for (; pGeomObj; pGeomObj=pGeomObj->m_pNext.get())
  {
    // Draw geometry at this level of the hierarchy tree
    glPushMatrix();
    glMultMatrixd(pGeomObj->m_positionInParent.openGLformat());
    glMultMatrixd(pGeomObj->m_localXformToObj.openGLformat());
    if (pGeomObj->m_pGeometry.get())
    {
      if ((flags & HIT_UNSELONLY) && m_selection.size() > 0)
      {
        if (std::find(m_selection.begin(), m_selection.end(), pGeomObj->m_pGeometry->m_pickName) == m_selection.end())
          pGeomObj->m_pGeometry->Draw(renderStyle);
      }
      else if ((flags & HIT_SELONLY) && m_selection.size())
      {
        if (std::find(m_selection.begin(), m_selection.end(), pGeomObj->m_pGeometry->m_pickName) != m_selection.end())
          pGeomObj->m_pGeometry->Draw(renderStyle);
      }
      else
      {
        pGeomObj->m_pGeometry->Draw(renderStyle);
        if (std::find(m_selection.begin(), m_selection.end(), pGeomObj->m_pGeometry->m_pickName) != m_selection.end())
          pGeomObj->m_pGeometry->Draw(eHighlightWireFrame);
      }
    }

    // If there are children, push the matrix then draw them
    // Obviously could run out of room on the gl matrix stack here.
    // Won't worry about it now; it's just a demo.  If we find that
    // we are running out of room, we'll have to do the math (push
    // and pop), at least for the extra levels, ourselves.
    if (pGeomObj->m_pChildren.get())
      DrawObjects(pGeomObj->m_pChildren.get(), renderStyle, flags);
    glPopMatrix();
  }
}

void  CMCADView::SetFrustum ()
{
  double zNear = m_frustumNearDistance;
  double left = m_frustumLeft;
  double right = m_frustumRight;
  double top = m_frustumTop;
  double bottom = m_frustumBottom;
  double zFar = m_frustumFarClippingPlane;

  if (m_projection == ePerspective)
  {
    // Move the near plane onto where we want the clipping plane to be
    if (fabs(zNear) != m_frustumNearClippingPlane)
    {
      zFar -= zNear;
      double _near = fabs(zNear);
      zNear *= m_frustumNearClippingPlane/_near;
      zFar += zNear;

      left *= m_frustumNearClippingPlane/_near;
      right *= m_frustumNearClippingPlane/_near;
      bottom *= m_frustumNearClippingPlane/_near;
      top *= m_frustumNearClippingPlane/_near;

    }
    glFrustum(left, right,
      bottom, top,
      zNear, zFar);
  }
  else
  {
    glOrtho(left*m_targetDistance/zNear, right*m_targetDistance/zNear,
      bottom*m_targetDistance/zNear, top*m_targetDistance/zNear,
      -zFar, zFar);
  }
}

BOOL CMCADView::OnEraseBkgnd(CDC* pDC)
{
  return TRUE;
}

int CMCADView::PickObject(const CPoint& point, const CSize& size, int flags)
{
  float z_depth;
  return PickObject(point, z_depth, size, flags);
}

int CMCADView::PickObject(const CPoint& point, float& z_depth, const CSize& size, int flags)
{
  ARRAY_NS::array<GLuint, 256> selectBuffer;
  GLint hits = PickObject(selectBuffer, point, size, flags);

  int pickid=0;
  z_depth = 1.0;

  if (hits>0)
  {
    int names=0;
    for(int i=0; i<hits; ++i)
    {
      float z_min = static_cast<float>(selectBuffer[names+i*3+1])/static_cast<float>(0xffffffff);
#if _TRACE_PICK
      float z_max = static_cast<float>(selectBuffer[names+i*3+2])/static_cast<float>(0xffffffff);
      TRACE("\tname=%d\tz_min=%g\tz_max=%g\n", 
        selectBuffer[names+i*3+3],
        z_min,
        z_max);
#endif
      if (z_min < z_depth)
      {
        z_depth = z_min;
        pickid = selectBuffer[names+i*3+3];
      }
      names += selectBuffer[names+i*3];
    }
#if _TRACE_PICK
    TRACE("item %d is being selected\n",pickid);
#endif
  }

  return pickid;
}

int CMCADView::PickObject(ARRAY_NS::array<GLuint, 256>& selectBuffer, const CPoint& point, const CSize& size, int flags)
{
  // The Size Of The Viewport. [0] Is <x>, [1] Is <y>, [2] Is <length>, [3] Is <width>
  GLint viewport[4];
  glGetIntegerv(GL_VIEWPORT,viewport);

  glSelectBuffer(static_cast<GLsizei>(selectBuffer.size()), selectBuffer.data());

  // Put OpenGL into selection mode. Nothing will be drawn. Object ID's and extents are stored in the buffer.
  glRenderMode(GL_SELECT);

  glInitNames();    // Initialize the name stack
  glPushName(0);    // Push an extry onto the stack

  glMatrixMode(GL_PROJECTION);  // select the project matrix stack
  glPushMatrix();               // push the current projection matrix
  glLoadIdentity();             // reset the projection matrix

  gluPickMatrix((GLdouble)point.x, (GLdouble)(viewport[3]-point.y), size.cx, size.cy, viewport);
  SetFrustum();
  glMatrixMode(GL_MODELVIEW);
  glPushMatrix();               // push the current modelview matrix
  glLoadIdentity();             // reset the modelview matrix

  // Multiply by the view matrix first (worldToEye)
  Matrix3d worldToCameraTM=(GetDocument()->Camera->m_positionInParent).Inverse();
  glMultMatrixd(worldToCameraTM.openGLformat());

  DrawObjects(GetDocument()->Model, eSmoothShaded, flags);

  glFlush();

  glMatrixMode(GL_PROJECTION);
  glPopMatrix();

  glMatrixMode(GL_MODELVIEW);
  GLint hits = glRenderMode(GL_RENDER);  // Switch back to render mode which causes the 
  // select buffer to be filled
  glPopMatrix();

#if _TRACE_PICK
  if (abs(hits)>0)
  {
    TRACE("CMCADView::PickObject %d hits\n", hits);
    int names=0;
    for(int i=0; i<abs(hits); ++i)
    {
      TRACE("\tname=%d\tz_min=%g\tz_max=%g\n", selectBuffer[names+i*3+3],
        static_cast<float>(selectBuffer[names+i*3+1])/static_cast<float>(0xffffffff),
        static_cast<float>(selectBuffer[names+i*3+2])/static_cast<float>(0xffffffff));
      names += selectBuffer[names+i*3];
    }
  }
  else
    TRACE("\nNothing picked\n");
#endif
  return abs(hits);
}

void CMCADView::OnLButtonDown(UINT nFlags, CPoint point) 
{
  int pickid = PickObject(point, CSize(3,3));

  std::vector<int> selection(m_selection);
  if (!(nFlags & MK_CONTROL))
    m_selection.clear();

  if (pickid)
  {
    std::vector<int>::iterator iterator;
    for (iterator=m_selection.begin(); iterator!= m_selection.end(); ++iterator)
    {
      if (*iterator == pickid)
      {
        m_selection.erase(iterator);
        return;
      }
    }
    m_selection.push_back(pickid);
  }

  if (selection != m_selection)
    SelectionChanged();
  DrawScene();
}

bool CMCADView::AutoFocus(Vector3d& focalPointCC, const CPoint& point, const CSize& size)
{
  float z_depth=1.0;
  int pickid = PickObject(point, z_depth, size, 0);
  if (pickid)
  {
    // Calculate new target position the projection
    // of the point onto the object surface
    GLdouble m[16];
    glGetDoublev(GL_PROJECTION_MATRIX, m);

    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT,viewport);

    CMCADDoc* pDoc = GetDocument();
    Matrix3d modelView = pDoc->Camera->m_positionInParent.Inverse();

    GLdouble objx, objy, objz;
    gluUnProject(static_cast<GLdouble>(point.x), static_cast<GLdouble>(viewport[3]-point.y), z_depth,
      modelView.openGLformat(),
      m,
      viewport,
      &objx,
      &objy,
      &objz);

    Vector3d focalPointWC(objx, objy, objz);
    focalPointCC = modelView * focalPointWC;
#if _TRACE_FOCALPOINT
    focalPointCC.DumpVector("Focal Point");
#endif
    return true;
  }
  return false;
}

void CMCADView::AutoPivot()
{
  // If we are not looking at a 3d view do nothing
  if (Projection == e2D)
    return;


  if (m_bUserPivot)
    return;
  // Only calculate the pivot if the object is up close otherwise use center of volume
  //   Matrix3d cameraToWorldTM=GetDocument()->Camera->m_positionInParent;
  //   Matrix3d worldToCameraTM=cameraToWorldTM.Inverse();

  // Get the extents of the model/selection in the world coordinates
  std::vector<int> *pselection = NULL;
  if (Standard3dmouse()->IsSelectionFollower())
    pselection = &m_selection;
  CExtents boundingBox = GetDocument()->Model->GetExtents(Matrix3d(), pselection);
  if (boundingBox.IsEmpty())
    return;

  // Make a cube
  CExtents cube;
  double sideLength = fabs(boundingBox.Width().v[boundingBox.Width().MaxComponent()]);
  cube.m_minPt = boundingBox.Center() - Vector3d(sideLength/2.,sideLength/2.,sideLength/2.);
  cube.m_maxPt = boundingBox.Center() + Vector3d(sideLength/2.,sideLength/2.,sideLength/2.);


  // Convert the bbox to screen coordinates
  GLdouble projection[16];
  glGetDoublev(GL_PROJECTION_MATRIX, projection);
  Matrix3d projMatrix;
  projMatrix.SetFromOpenGLFormat(projection);

  GLint viewport[4];
  glGetIntegerv(GL_VIEWPORT,viewport);

  CMCADDoc* pDoc = GetDocument();
  Matrix3d modelView = pDoc->GetView()->m_positionInParent.Inverse();

  CRect rcBox(0,0,0,0);
  size_t ivertex;
  for (ivertex=0; ivertex<8; ++ivertex)
  {
    Vector3d corner;
    corner = projMatrix * modelView * cube[ivertex];
    CPoint pointWin;
    pointWin.x = viewport[0] + static_cast<int>(static_cast<double>(viewport[2])*(corner.x/corner.w +1.)/2.);
    pointWin.y = viewport[1] + static_cast<int>(static_cast<double>(viewport[3])*(corner.y/corner.w +1.)/2.);
    pointWin.y = viewport[3]-pointWin.y;
    if (rcBox.IsRectNull())
      rcBox+=pointWin;
    else 
    {
      if (pointWin.x > rcBox.right)
        rcBox.right = pointWin.x;
      else if (pointWin.x < rcBox.left)
        rcBox.left = pointWin.x;
      if (pointWin.y > rcBox.bottom)
        rcBox.bottom = pointWin.y;
      else if (pointWin.y < rcBox.top)
        rcBox.top = pointWin.y;
    }
  }

  CRect rectViewport;
  GetClientRect(&rectViewport);
  CRect intersection;
  intersection.IntersectRect(&rectViewport, &rcBox);

  float area = static_cast<float>(intersection.Width()) * static_cast<float>(intersection.Height());
  float modelArea = static_cast<float>(rcBox.Width()) * static_cast<float>(rcBox.Height());
  if (area > modelArea * .64)
  {
    // Set the rotation center for object control in model coordinates to the
    // center of volume (bounding box)
    Matrix3d worldToModelTM=(GetDocument()->Model->m_positionInParent).Inverse();
    m_3dcontroller.CenterOfRotation = worldToModelTM * boundingBox.Center();
    // If not moving then redraw
    if (!m_3dcontroller.IsMoving())
      DrawScene();
    return;
  }


#define FIRST_TRY_SIZE_PERCENT (0.01f)
  // Use a pick region based on the FOV and 1% of the window width
  int pickWidth = static_cast<int>(
    static_cast<float>(rectViewport.Width())*FIRST_TRY_SIZE_PERCENT
    / tan(FOV/2.)
    );

  int pickHeight = static_cast<int>(
    static_cast<float>(rectViewport.Height())*FIRST_TRY_SIZE_PERCENT
    / tan(FOV/2.)
    );

  int pickRadius = pickWidth>pickHeight ? pickWidth : pickHeight;

  CSize pickRegion(pickRadius < rectViewport.Width() ? pickRadius : rectViewport.Width()
    , pickRadius < rectViewport.Height() ? pickRadius : rectViewport.Height());



  // if an object has been picked then use that as the center of rotation
  // pivot is returned in model coordinates
  float z_depth=1.0;
  int flags = 0;
  if ((m_selection.size() > 0) && Standard3dmouse()->IsSelectionFollower())
    flags = HIT_SELONLY;
  int pickid = PickObject(rectViewport.CenterPoint(), z_depth, pickRegion, flags);
  if (!pickid)
  {
    // Didn't find anything increase by SECOND_TRY_SIZE_FACTOR
#define SECOND_TRY_SIZE_FACTOR 3
    pickRegion.SetSize(pickRadius*SECOND_TRY_SIZE_FACTOR < rectViewport.Width() ? pickRadius*SECOND_TRY_SIZE_FACTOR : rectViewport.Width()
    , pickRadius*SECOND_TRY_SIZE_FACTOR < rectViewport.Height() ? pickRadius*SECOND_TRY_SIZE_FACTOR : rectViewport.Height());
    pickid = PickObject(rectViewport.CenterPoint(), z_depth, pickRegion, flags);
  }

  if (!pickid)
  {
    // Nothing picked
    if (!intersection.IsRectEmpty())
    {
      // Use the real bounding box and check that the rotation pivot is in it
      CRect rcBox(0,0,0,0);
      size_t ivertex;
      for (ivertex=0; ivertex<8; ++ivertex)
      {
        Vector3d corner;
        corner = projMatrix * modelView * boundingBox[ivertex];
        CPoint pointWin;
        pointWin.x = viewport[0] + static_cast<int>(static_cast<double>(viewport[2])*(corner.x/corner.w +1.)/2.);
        pointWin.y = viewport[1] + static_cast<int>(static_cast<double>(viewport[3])*(corner.y/corner.w +1.)/2.);
        pointWin.y = viewport[3]-pointWin.y;
        if (rcBox.IsRectNull())
          rcBox+=pointWin;
        else 
        {
          if (pointWin.x > rcBox.right)
            rcBox.right = pointWin.x;
          else if (pointWin.x < rcBox.left)
            rcBox.left = pointWin.x;
          if (pointWin.y > rcBox.bottom)
            rcBox.bottom = pointWin.y;
          else if (pointWin.y < rcBox.top)
            rcBox.top = pointWin.y;
        }
      }

      // Increase the size of the intersection by the pick region
      rcBox.InflateRect(pickRegion);


      // Check if the current pivot is inside the bounding box
      Matrix3d modelToWorldTM=GetDocument()->Model->m_positionInParent;
      Vector3d pivot = projMatrix * modelView * modelToWorldTM * m_3dcontroller.CenterOfRotation;
      CPoint point;
      point.x = viewport[0] + static_cast<int>(static_cast<double>(viewport[2])*(pivot.x/pivot.w +1.)/2.);
      point.y = viewport[1] + static_cast<int>(static_cast<double>(viewport[3])*(pivot.y/pivot.w +1.)/2.);
      point.y = viewport[3]-point.y;



      if (!rcBox.PtInRect(point))
      {
        Matrix3d worldToModelTM=(GetDocument()->Model->m_positionInParent).Inverse();
        m_3dcontroller.CenterOfRotation = worldToModelTM*boundingBox.Center();
        // If not moving then redraw
        if (!m_3dcontroller.IsMoving())
          DrawScene();
        return;
      }
    }
  }

  if (pickid)
  {
    // Calculate new center of rotation from the projection
    // of the cursor onto the object surface
    GLdouble m[16];
    glGetDoublev(GL_PROJECTION_MATRIX, m);

    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT,viewport);

    CMCADDoc* pDoc = GetDocument();
    Matrix3d modelView = pDoc->Camera->m_positionInParent.Inverse();
    modelView *= pDoc->GetModel()->m_positionInParent;

    GLdouble objx, objy, objz;
    gluUnProject(static_cast<GLdouble>(rectViewport.CenterPoint().x)
      , static_cast<GLdouble>(viewport[3]-rectViewport.CenterPoint().y)
      , z_depth,
      modelView.openGLformat(),
      m,
      viewport,
      &objx,
      &objy,
      &objz);

    m_3dcontroller.CenterOfRotation = Vector3d(objx, objy, objz);
    // If not moving then redraw
    if (!m_3dcontroller.IsMoving())
      DrawScene();
#if _TRACE_PIVOT
    pivotMC.DumpVector("Pivot");
#endif
    return;
  }
}

void CMCADView::ManualPivot()
{
  // If we are not looking at a 3d view do nothing
  if (Projection == e2D)
    return;

  if (m_bUserPivot)
    return;

  // set the center of rotation to the center of volume
  // Get the extents of the model
  std::vector<int> *pselection = NULL;
  if (Standard3dmouse()->IsSelectionFollower())
    pselection = &m_selection;

  CExtents extents = GetDocument()->Model->GetExtents(Matrix3d(), pselection);
  Vector3d centerOfVolumeWC = (extents.m_maxPt+extents.m_minPt)/2.;

  Matrix3d worldToModelTM=(GetDocument()->Model->m_positionInParent).Inverse();
  Vector3d pivot = worldToModelTM*centerOfVolumeWC;

  m_3dcontroller.CenterOfRotation = pivot;
  if (!m_3dcontroller.IsMoving())
     DrawScene();
}

void CMCADView::ResetUserPivot()
{
  if (m_bUserPivot)
  {
    m_bUserPivot = false;
    m_pMainFrame->RecalculateAutoPivot(true);
  }
}

void CMCADView::SelectNone()
{
  if (m_selection.size())
  {
    m_selection.clear();
    SelectionChanged();
  }
}


int CMCADView::PickPivot(Vector3d& pivotMC, const CPoint& point, const CSize& size, int flags)
{
  // if an object has been picked then use that as the center of rotation
  // pivot is returned in model coordinates
  float z_depth=1.0;
  int pickid = PickObject(point, z_depth, size, flags);
  if (pickid)
  {
    // Calculate new center of rotation from the projection
    // of the cursor onto the object surface
    GLdouble m[16];
    glGetDoublev(GL_PROJECTION_MATRIX, m);

    GLint viewport[4];
    glGetIntegerv(GL_VIEWPORT,viewport);

    CMCADDoc* pDoc = GetDocument();
    Matrix3d modelView = pDoc->GetView()->m_positionInParent.Inverse();
    modelView *= pDoc->GetModel()->m_positionInParent;

    GLdouble objx, objy, objz;
    gluUnProject(static_cast<GLdouble>(point.x), static_cast<GLdouble>(viewport[3]-point.y), z_depth,
      modelView.openGLformat(),
      m,
      viewport,
      &objx,
      &objy,
      &objz);

    pivotMC.Set(objx, objy, objz);
#if _TRACE_PIVOT
    pivotMC.DumpVector("Pivot");
#endif
  }
  return pickid;
}

void CMCADView::OnMButtonDown(UINT nFlags, CPoint point) 
{
  // Set a new center of rotation 
  // if an object has been picked then use that as the center of rotation
  // if nothing has been picked then reset the center of rotation to the
  // center of volume of everything

  bool bWasUserPivot = m_bUserPivot;
  m_bUserPivot = false;

  if (Standard3dmouse()->GetNavigationMode()!=tdx::objectMode
    && Standard3dmouse()->GetNavigationMode()!=tdx::targetCameraMode)
    return;

  Vector3d pivot;
  m_bUserPivot = (PickPivot(pivot, point)!= 0);

  if (m_bUserPivot)
  {
    m_3dcontroller.CenterOfRotation = pivot;
    if (!m_3dcontroller.IsMoving())
      DrawScene();
  }
  else if (Standard3dmouse()->GetPivotMode() == tdx::autoPivot)
  {
    if (bWasUserPivot)
      AutoPivot();
  }
  else if (Standard3dmouse()->GetPivotMode() == tdx::manualPivot)
  {
    if (bWasUserPivot)
      ManualPivot();
  }
}


BOOL CMCADView::PickLevelOfObjects(CGeomObj *pGeomObj, CMCADDoc *pDoc, unsigned int pickName)
{
  for(; pGeomObj; pGeomObj = pGeomObj->m_pNext.get())
  {
    if (pGeomObj->m_pGeometry.get() && (pGeomObj->m_pGeometry->m_pickName == pickName))
    {
      pDoc->SelectedObject = pGeomObj;
      GetDocument()->SelectedObject->m_resetPosition=GetDocument()->SelectedObject->m_localXformToObj;
      return true;
    }

    // Check the children by recursively calling ourself
    if (pGeomObj->m_pChildren.get())
    {
      if (PickLevelOfObjects(pGeomObj->m_pChildren.get(),pDoc,pickName))
        return true;
    }
  }
  return false;
}

void CMCADView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  if (nChar == VK_SHIFT) m_ShiftKeyDepressed = TRUE;
  if (nChar == VK_CONTROL) m_ControlKeyDepressed = TRUE;
  CView::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CMCADView::OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
  if (nChar == VK_SHIFT) m_ShiftKeyDepressed = FALSE;
  if (nChar == VK_CONTROL) m_ControlKeyDepressed = FALSE;
  CView::OnKeyUp(nChar, nRepCnt, nFlags);
}

void CMCADView::OnTimer(UINT_PTR nIDEvent) 
{
  CView::OnTimer(nIDEvent);

#if _TRACE_TIMER
  TRACE(L"CMCADView::OnTimer()\n");
#endif
  if (m_animationTimer == nIDEvent)
  {
    if (!m_bRedrawView)
    {
      if (--m_animationTimeToLive <=0)
      {
        m_animationTimer = 0;
        KillTimer(nIDEvent);
        if (Standard3dmouse()->GetPivotVisibility()==tdx::showMovingPivot 
          && (Standard3dmouse()->GetNavigationMode()==tdx::objectMode || Standard3dmouse()->GetNavigationMode()==tdx::targetCameraMode))
          DrawScene();
#if _TRACE_TIMER
        TRACE(L"CMCADView::OnTimer() KillTimer\n");
#endif
      }
      return;
    }
    m_animationTimeToLive = 2;
    m_bRedrawView = false;
    DrawScene();
  }
}

void CMCADView::AutoFocus(void)
{
  if (m_projection != ePerspective)
    return;

  CRect rectClient;
  GetClientRect(&rectClient);

  int pickDiameter=1;

  Vector3d targetCC;
  bool bFound = AutoFocus(targetCC, rectClient.CenterPoint(), CSize(pickDiameter, pickDiameter));
  if (bFound)
    // Set the focus for camera control in camera coordinates
    m_focalDistance = fabs(targetCC.z);
}

void CMCADView::Move3d(HANDLE hDevice, ARRAY_NS::array<float, 6>& deviceData)
{
  m_3dcontroller.Move(deviceData);
  if (m_3dcontroller.IsMoving())
  {
    m_bRedrawView=true;
    if (!m_animationTimer)
    {
      // Create a brand new unused timer
      m_animationTimer = ::SetTimer(NULL, 0, USER_TIMER_MAXIMUM, NULL);
      // Now set the HWND to the derived window and correct the timeout
      m_animationTimer = SetTimer(m_animationTimer
        , m_uAnimationUpdatePeriod
        , NULL);
      OnTimer(m_animationTimer);
    }
  }
}

void CMCADView::ZoomExtents(void)
{

  Matrix3d cameraToWorldTM=GetDocument()->Camera->m_positionInParent;
  GetZoomExtents(cameraToWorldTM);
  GetDocument()->Camera->m_positionInParent = cameraToWorldTM;

  ResetUserPivot();

  DrawScene();
}

void CMCADView::GetZoomExtents(Matrix3d& cameraToWorldTM)
{
  // Zoom and correct the horizon
  Matrix3d worldToCameraTM=cameraToWorldTM.Inverse();
  if (fabs(worldToCameraTM.m[0][1]) > epsilon)
  {
    Vector3d yAxis (0.f, worldToCameraTM.m[1][1], worldToCameraTM.m[2][1]);
    if (yAxis.Length() > epsilon)
    {
      yAxis.Normalize();
      Vector3d zAxis (worldToCameraTM.m[0][2], worldToCameraTM.m[1][2], worldToCameraTM.m[2][2]);
      Vector3d xAxis = yAxis.CrossProduct(zAxis);
      if (xAxis.Length() < epsilon)
        xAxis = Vector3d(1.,0.,0.);
      else
        xAxis.Normalize();
      zAxis = xAxis.CrossProduct(yAxis);

      worldToCameraTM.m[0][0] = xAxis.x;
      worldToCameraTM.m[1][0] = xAxis.y;
      worldToCameraTM.m[2][0] = xAxis.z;
      worldToCameraTM.m[0][1] = yAxis.x;
      worldToCameraTM.m[1][1] = yAxis.y;
      worldToCameraTM.m[2][1] = yAxis.z;
      worldToCameraTM.m[0][2] = zAxis.x;
      worldToCameraTM.m[1][2] = zAxis.y;
      worldToCameraTM.m[2][2] = zAxis.z;
    }
    else
      worldToCameraTM.Identity();
  }

  // Get the extents of the model in the view coordinates
  CExtents extents = GetDocument()->Model->GetExtents(worldToCameraTM, &m_selection);
  Vector3d centerOfVolumeCC = (extents.m_maxPt+extents.m_minPt)/2.;

  cameraToWorldTM = worldToCameraTM.Inverse();
  Vector3d centerOfVolumeWC = cameraToWorldTM * centerOfVolumeCC;
#if _TRACE_COV
  centerOfVolumeWC.DumpVector(_T("COV WC"));
#endif

  Matrix3d worldToModelTM=(GetDocument()->Model->m_positionInParent).Inverse();
  Vector3d centerOfVolumeMC = worldToModelTM*centerOfVolumeWC;
#if _TRACE_COV
  centerOfVolumeMC.DumpVector(_T("COV MC"));
#endif

  // Calculate the z position relative to the center of the
  // bounding box
  Vector3d boundingbox = extents.m_maxPt-extents.m_minPt;
  if (boundingbox.Length() < epsilon)
  {
    // use the grid
    Vector3d extentsMax, extentsMin;
    for (int i =0; i<2; ++i)
    {
      for (int j =0; j<2; ++j)
      {
        Vector3d corner(i ? m_extentsGrid : -m_extentsGrid, 0., j ? m_extentsGrid : -m_extentsGrid);
        corner = worldToCameraTM * corner;
        if (i==0 && j==0)
          extentsMin = extentsMax = corner;
        for (int k=0; k<3; ++k)
        {
          if (corner.v[k] < extentsMin.v[k]) extentsMin.v[k] = corner.v[k];
          else if (corner.v[k] > extentsMax.v[k]) extentsMax.v[k] = corner.v[k];
        }
      }
    }
    boundingbox =  extentsMax - extentsMin;
  }

  FOV = kDefaultFOV;
  Vector3d zoomCC;
  if (fabs(boundingbox.x/(m_frustumRight-m_frustumLeft)) > fabs(boundingbox.y/(m_frustumTop-m_frustumBottom)))
    zoomCC.z=fabs(boundingbox.x/(m_frustumRight-m_frustumLeft))*m_frustumNearDistance+boundingbox.z/2.;
  else
    zoomCC.z=fabs(boundingbox.y/(m_frustumTop-m_frustumBottom))*m_frustumNearDistance+boundingbox.z/2.;

  Vector3d zoomWC = cameraToWorldTM.GetOrientation()*zoomCC;

  // Move the camera onto the center of volume
  cameraToWorldTM.SetPosition(centerOfVolumeWC);

  // Translate back
  cameraToWorldTM.TranslateBy(zoomWC);
}

tdx::I3dmouseParam* CMCADView::Standard3dmouse()
{
  return m_pMainFrame->Standard3dmouse();
}

void CMCADView::OnProjectionPerspective()
{
  Projection = ePerspective;
  FOV = kDefaultFOV;
  DrawScene();
}

void CMCADView::OnUpdateProjectionPerspective(CCmdUI *pCmdUI)
{
  pCmdUI->Enable();
  pCmdUI->SetRadio(m_projection == ePerspective);
}

void CMCADView::OnProjectionParallel()
{
  if (Projection == ePerspective)
    FOV = PerspectiveFOVToParallel();
  Projection = eParallel;
  DrawScene();
}

double CMCADView::PerspectiveFOVToParallel()
{
  CMCADDoc *pDoc = GetDocument();
  Matrix3d camera2worldTM = pDoc->Camera->m_positionInParent;
  Vector3d cameraPosWC = camera2worldTM.GetPosition();

  Matrix3d world2cameraTM = camera2worldTM.Inverse();

  Matrix3d model2worldTM = pDoc->Model->m_positionInParent;
  Vector3d pivotPosWC = model2worldTM * m_3dcontroller.CenterOfRotation;

  Vector3d camera2PivotWC = pivotPosWC-cameraPosWC;
  Vector3d camera2PivotCC = world2cameraTM.GetOrientation() * camera2PivotWC;

  return 2. * atan(tan(FOV/2.) * fabs(camera2PivotCC.z)/TargetDistance);
}

void CMCADView::OnUpdateProjectionParallel(CCmdUI *pCmdUI)
{
  // A 3D parallel projection where we zoom dependent on the movement and
  // rotations are allowed is only possible in object mode
  BOOL bSelectable = (Standard3dmouse()->GetNavigationMode() == tdx::objectMode
    || Standard3dmouse()->GetNavigationMode() == tdx::targetCameraMode);
  pCmdUI->Enable(bSelectable);
  pCmdUI->SetRadio(m_projection == eParallel);
}

void CMCADView::OnProjection2d()
{
  if (Projection == ePerspective)
    FOV = PerspectiveFOVToParallel();

  Projection = e2D;
  DrawScene();
}

void CMCADView::OnToggleGrid()
{
  m_bShowGrid = !m_bShowGrid;
  DrawScene();
}

void CMCADView::OnUpdateProjection2d(CCmdUI *pCmdUI)
{
  pCmdUI->Enable();
  pCmdUI->SetRadio(m_projection == e2D);
}

void CMCADView::OnUpdateShowGrid(CCmdUI *pCmdUI)
{
  pCmdUI->Enable();
  pCmdUI->SetCheck(m_bShowGrid);
}


void CMCADView::SelectionChanged()
{
  if (Standard3dmouse()->IsSelectionFollower()) 
  {
    bool forceNow = false;
    if (m_selection.size() > 0)
      forceNow = true;
    m_pMainFrame->RecalculateAutoPivot(forceNow);
  }
}
