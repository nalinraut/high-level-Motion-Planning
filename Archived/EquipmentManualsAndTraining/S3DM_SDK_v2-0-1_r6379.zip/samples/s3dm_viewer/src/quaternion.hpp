#ifndef quaternion_HPP_INCLUDED_
#define quaternion_HPP_INCLUDED_
// quaternion.hpp
/*
* Copyright notice:
* (c) 2009 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: quaternion.hpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 10.12.09 MSB
//

#ifndef __cplusplus
#error quaternion requires C++ compilation (use a .cpp suffix)
#endif

namespace tdx {    
   const double kEpsilon = 1.0e-7;
   /////////////////////////////////////////////////////////////////////////////
   // CQuaternionT
   template <typename T> class CQuaternionT
   {
      // Construction
   public:
      CQuaternionT() : x(0.0), y(0.0), z(0.0), w(1.0)
      {
      }

      CQuaternionT(double x, double y, double z, double w)
      {
         this->x = x; this->y = y; this->z = z; this->w = w; 
      }

      CQuaternionT(const CQuaternionT& quat) : x(quat.x), y(quat.y), z(quat.z), w(quat.w)
      {
      }

      virtual ~CQuaternionT()
      {
      }

   public:
      double x, y, z, w;

   public:
      void FromAngleAxis (double angle , const T& axis)
      {
         double fsin = sin(angle/2.0);
         // Calculate the x, y and z of the quaternion
         x = axis.x * fsin;
         y = axis.y * fsin;
         z = axis.z * fsin;

         w = cos(angle/2.0);
      }

      // Access operators
      double& operator[](int i)
      { 
         return (&x)[i]; 
      }

      const double& operator[](int i) const
      { 
         return (&x)[i]; 
      }

      // Conversion function
      operator double*() 
      { 
         return(&x); 
      }

      // Unary operators
      CQuaternionT operator-() const 
      { 
         return(CQuaternionT(-x,-y,-z,-w)); 
      }

      CQuaternionT operator+() const
      { 
         return *this; 
      }


      CQuaternionT operator * (const CQuaternionT& q)
      {
         CQuaternionT r;

         r.w = w*q.w - x*q.x - y*q.y - z*q.z;
         r.x = w*q.x + x*q.w + y*q.z - z*q.y;
         r.y = w*q.y + y*q.w + z*q.x - x*q.z;
         r.z = w*q.z + z*q.w + x*q.y - y*q.x;

         return r;
      }

   };

   template <class T>
   CQuaternionT<T> QuatFromAngleAxis(double angle , const T& axis)
   {
      CQuaternionT<T> q;
      q.FromAngleAxis(angle, axis);
      return q;
   }

   template <class T>
   void AngleAxisFromQuat(const CQuaternionT<T>& quat , double& angle, T& axis)
   {
      angle = acos(quat.w)*2.;
      double fsin = sin(angle/2.0);
      if (fsin > kEpsilon)
      {
         axis.x = quat.x/fsin;
         axis.y = quat.y/fsin;
         axis.z = quat.z/fsin;
         axis.w = 1.;
      }
   }
};
#endif // quaternion_HPP_INCLUDED_

