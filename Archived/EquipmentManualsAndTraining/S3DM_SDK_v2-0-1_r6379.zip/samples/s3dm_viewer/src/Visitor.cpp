// Visitor.cpp: implementation of the Visitor class.
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#include "stdafx.h"
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: Visitor.cpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 17.09.10 MSB Added node filter to visitor class
// 20.10.09 MSB Based on code from Jim Wick's BycycleDI sample
//
#include "s3dm_viewer.h"
#include "GeomObj.h"
#include "Visitor.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CVisitor::CVisitor(VisitorCallback pCallback, void *puserData, const std::vector<int>* pnodeFilter) :
m_puserData(puserData)
, m_pfunc(pCallback)
, m_pnodeFilter(pnodeFilter)
{
}

CVisitor::~CVisitor()
{
}

bool CVisitor::operator ()(CGeomObj *pnode, const Matrix3d &accumMatrix)
{
   return (*m_pfunc) (pnode, accumMatrix, m_puserData, m_pnodeFilter);
}