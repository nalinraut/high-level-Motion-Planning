// 3dmousexml.c
/*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: 3dmousexml.c 6230 2010-11-11 09:43:24Z markus_bonk $
//
// 28.09.10 MSB Initial Design 
//
#include "3dmousexml.h"


// windows
#include <shlobj.h>

// crt
#include <stdio.h>



DWORD write_3dmouse_xml (S3DM_APPLICATION_INFO* pAppInfo
     , S3DM_3DMOUSE_SETTINGS* pMouseSettings, S3DM_BUTTON_SETTINGS* pMouseButtonSettings)
{

  HRESULT hr = S_OK;
  wchar_t filename[MAX_PATH]={0};
  wchar_t buffer[MAX_PATH]={0};
  size_t length_filename=sizeof(filename)/sizeof(filename[0]);
  size_t length_buffer=sizeof(buffer)/sizeof(buffer[0]);
  FILE *stream;
  int i;
  errno_t err;
  

  hr = SHGetFolderPathAndSubDirW(NULL
                        , CSIDL_LOCAL_APPDATA|CSIDL_FLAG_CREATE
                        , NULL
                        , SHGFP_TYPE_CURRENT
                        , L"3dmouse\\settings"
                        , filename);
  if (FAILED(hr))
    return hr;

  wcscat_s(filename, length_filename, L"\\");

  _itow_s(pAppInfo->threadId, buffer, length_buffer, 16);
  wcscat_s(filename, length_filename, buffer);
  wcscat_s(filename, length_filename, L".xml");
  

  err = _wfopen_s(&stream, filename, L"wt");
  if (err != 0)
    return ERROR_OPEN_FAILED;

  // heading
  fwprintf (stream, L"<?xml version=\"1.0\" encoding=\"utf-8\"?>\n");
  // <root>
  fwprintf (stream, L"<settings_3dmouse version=\"1.0\">\n");

  // <application>
  fwprintf (stream, L"  <application>\n");
  fwprintf (stream, L"    <name>");fwprintf (stream, pAppInfo->name);fwprintf (stream, L"</name>\n");
  _itow_s(pAppInfo->threadId, buffer, length_buffer, 10);
  fwprintf (stream, L"    <thread_id>");fwprintf (stream, buffer);fwprintf (stream, L"</thread_id>\n");
  fwprintf (stream, L"    <button_editor>");fwprintf (stream, pAppInfo->button_editor ? L"true" : L"false");fwprintf (stream, L"</button_editor>\n");
  fwprintf (stream, L"  </application>\n");
  // </application>

  // <sensor>
  fwprintf (stream, L"  <sensor>\n");
  // <filters>
  fwprintf (stream, L"    <filters>\n");
  fwprintf (stream, L"      <rotate>");fwprintf (stream, pMouseSettings->rotate ? L"true" : L"false");fwprintf (stream, L"</rotate>\n");
  fwprintf (stream, L"      <pan_zoom>");fwprintf (stream, pMouseSettings->pan_zoom ? L"true" : L"false");fwprintf (stream, L"</pan_zoom>\n");
  fwprintf (stream, L"      <single_axis>");fwprintf (stream, pMouseSettings->single_axis ? L"true" : L"false");fwprintf (stream, L"</single_axis>\n");
  fwprintf (stream, L"    </filters>\n");
  // </filters>
  swprintf(buffer, MAX_PATH, L"%2.2f", pMouseSettings->speed);
  fwprintf (stream, L"    <speed>");fwprintf (stream, buffer);fwprintf (stream, L"</speed>\n");
  fwprintf (stream, L"  </sensor>\n");
  // </sensor>

  // <button_mapping>
  fwprintf (stream, L"  <button_mapping>\n");
  fwprintf (stream, L"    <name>");fwprintf (stream, pMouseButtonSettings->name);fwprintf (stream, L"</name>\n");

  for (i=0; i<pMouseButtonSettings->count; ++i)
  {
    fwprintf (stream, L"    <button>\n");
    fwprintf (stream, L"      <id>");fwprintf (stream, pMouseButtonSettings->assignments[i].button_id);fwprintf (stream, L"</id>");
    fwprintf (stream, L"      <text>");fwprintf (stream, pMouseButtonSettings->assignments[i].text);fwprintf (stream, L"</text>");
    fwprintf (stream, L"    </button>\n");
  }
  // </button_mapping>
  fwprintf (stream, L"  </button_mapping>\n");


  // </root>
  fwprintf (stream, L"</settings_3dmouse>");

  fclose(stream);

  return S_OK;
}

DWORD delete_3dmouse_xml (S3DM_APPLICATION_INFO* pAppInfo)
{
  HRESULT hr = S_OK;
  wchar_t filename[MAX_PATH]={0};
  wchar_t buffer[MAX_PATH]={0};
  size_t length_filename=sizeof(filename)/sizeof(filename[0]);
  size_t length_buffer=sizeof(buffer)/sizeof(buffer[0]);


  hr = SHGetFolderPathAndSubDirW(NULL, 
                         CSIDL_LOCAL_APPDATA|CSIDL_FLAG_CREATE, 
                         NULL, 
                         0,
                         L"3dmouse\\settings",
                         filename);
  if (FAILED(hr))
    return hr;

  wcscat_s(filename, length_filename, L"\\");
  _itow_s(pAppInfo->threadId, buffer, length_buffer, 16);
  wcscat_s(filename, length_filename, buffer);
  wcscat_s(filename, length_filename, L".xml");

  return _wremove(filename);
}
