// Matrix3d.cpp: implementation of the Matrix3d class.
/*
*
* Matrix3d is a column matrix class (the position is in the last column
* of the matrix.  Therefore, concatenation happens right to left.
*
* Copyright notice:
* (c) 2010 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/
#include "Matrix3d.h"
///////////////////////////////////////////////////////////////////////////////////
// History
//
// $Id: Matrix3d.cpp 6181 2010-11-04 13:19:07Z markus_bonk $
//
// 04.05.09 MSB Fix Index in += and +- operator of first vector incorrect when
//               v[3] not identical.               
// 10.11.09 MSB Fix Inverse was doting position with row instead of column
// 03.11.09 MSB Fix Inverse was transposing the complete matrix instead of just the 
//              rotation part
//

//stl
#include <cmath>

//atl
#include <atltrace.h>


#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

double Vector3d::DotProduct(const Vector3d &vec) const
{
   double result = (v[0]*vec.v[0])+(v[1]*vec.v[1])+(v[2]*vec.v[2]);
   if (fabs(v[3]) > epsilon || fabs(vec.v[3]) > epsilon)
      return result/(v[3]*vec.v[3]); // throws an exception if one is zero
   return result;
}

Vector3d 
Vector3d::CrossProduct(const Vector3d &vec) const
{
   Vector3d result;
   result.v[0] = (v[1]*vec.v[2])-(v[2]*vec.v[1]);
   result.v[1] = (v[2]*vec.v[0])-(v[0]*vec.v[2]);
   result.v[2] = (v[0]*vec.v[1])-(v[1]*vec.v[0]);
   result.v[3] = v[3]*vec.v[3];
   return result;
}

void
Vector3d::DumpVector(TCHAR *s) const
{
   ATLTRACE(_T("\n%s\n%f %f %f %f\n"),s,v[0],v[1],v[2],v[3]);
}

Vector3d  
Vector3d::operator+ (const Vector3d &vec) const
{
   Vector3d result = *this;
   result += vec;
   return result;
}

Vector3d& 
Vector3d::operator+=(const Vector3d &vec)
{
   if (v[3] != vec.v[3])
   {
      v[0] = v[0]*vec.v[3]+vec.v[0]*v[3];
      v[1] = v[1]*vec.v[3]+vec.v[1]*v[3];
      v[2] = v[2]*vec.v[3]+vec.v[2]*v[3];
   }
   else
   {
      v[0] += vec.v[0];
      v[1] += vec.v[1];
      v[2] += vec.v[2];
   }
   v[3]*=vec.v[3];
   return *this;
}

Vector3d  
Vector3d::operator- () const
{
   Vector3d result(-v[0], -v[1], -v[2], v[3]);
   return result;
}

Vector3d  
Vector3d::operator- (const Vector3d &vec) const
{
   Vector3d result = *this;
   result -= vec;
   return result;
}

Vector3d& 
Vector3d::operator-=(const Vector3d &vec)
{
   if (v[3] != vec.v[3])
   {
      v[0] = v[0]*vec.v[3]-vec.v[0]*v[3];
      v[1] = v[1]*vec.v[3]-vec.v[1]*v[3];
      v[2] = v[2]*vec.v[3]-vec.v[2]*v[3];
   }
   else
   {
      v[0] -= vec.v[0];
      v[1] -= vec.v[1];
      v[2] -= vec.v[2];
   }
   v[3]*=vec.v[3];
   return *this;
}

Vector3d & Vector3d::SingleAxisFilter()
{
#define ABS(x) ((x < 0) ? -(x) : x)
   double *plargest = &v[0];
   for (int i=1;i<3;i++)
      if (ABS(v[i]) > ABS(*plargest))
         plargest = &v[i];

   for(int i=0;i<3;i++)
      if (plargest != &v[i])
         v[i]=0;

   return *this;
#undef ABS
}

Vector3d & Vector3d::Normalize()
{
   double len = sqrt((v[0]*v[0]) + (v[1]*v[1]) + (v[2]*v[2]));
   if (v[3] > epsilon)
      v[3] = 1.;
   else if (fabs(v[3]) < epsilon)
      v[3]=0.;
   else
   {
      len = -len;
      v[3] = 1.;
   }

   v[0] /= len;
   v[1] /= len;
   v[2] /= len;
   return *this;
}

Vector3d Vector3d::UnitVector() const
{
   Vector3d result(*this);
   return result.Normalize();
}

Vector3d & Vector3d::Negate()
{
   v[0] = -v[0];
   v[1] = -v[1];
   v[2] = -v[2];
   //	v[3] = -v[3];
   return *this;
}

Vector3d Vector3d::Negative() const
{
   Vector3d vec;
   vec.v[0] = -v[0];
   vec.v[1] = -v[1];
   vec.v[2] = -v[2];
   vec.v[3] =  v[3];
   return vec;
}

double Vector3d::Length() const
{
   double result = sqrt(v[0] * v[0] + 
      v[1] * v[1] + 
      v[2] * v[2]);
   if (fabs(v[3]) > epsilon)
      return result/v[3];
   return result;
}


int Vector3d::MaxComponent() const
{
#define ABS(x) ((x < 0) ? -(x) : x)
   int largest=0;
   for (int i=1;i<3;++i)
      if (ABS(v[i]) > ABS(v[largest]))
         largest = i;

   return largest;
#undef ABS
}

Matrix3d::Matrix3d()
{
   Identity();
}

Matrix3d::~Matrix3d()
{
}


Matrix3d&
Matrix3d::Transpose()
{
   double tmp;
#define SWAP(a,b) tmp=a;a=b;b=tmp;
   SWAP(m[1][0],m[0][1]);
   SWAP(m[2][0],m[0][2]);
   SWAP(m[3][0],m[0][3]);
   SWAP(m[2][1],m[1][2]);
   SWAP(m[3][1],m[1][3]);
   SWAP(m[3][2],m[2][3]);
#undef SWAP
   return *this;
}

Matrix3d&
Matrix3d::TransposeRotOnly()
{
   double tmp;
#define SWAP(a,b) tmp=a;a=b;b=tmp;
   SWAP(m[1][0],m[0][1]);
   SWAP(m[2][0],m[0][2]);
   SWAP(m[2][1],m[1][2]);
#undef SWAP
   return *this;
}

Matrix3d  
Matrix3d::Inverse() const
{
   Matrix3d result = *this;

   // Orientation is just a transpose
   result.TransposeRotOnly();

   // Position is negative of original position dotted with corresponding
   // orientation vector.
   result.m[0][3]= (-m[0][3]*m[0][0])+(-m[1][3]*m[1][0])+(-m[2][3]*m[2][0]);
   result.m[1][3]= (-m[0][3]*m[0][1])+(-m[1][3]*m[1][1])+(-m[2][3]*m[2][1]);
   result.m[2][3]= (-m[0][3]*m[0][2])+(-m[1][3]*m[1][2])+(-m[2][3]*m[2][2]);

   // Zero out last row
   result.m[3][0]=
      result.m[3][1]=
      result.m[3][2]=0.;

   return result;
}

Matrix3d& 
Matrix3d::Invert() // inverts inplace
{
   *this = this->Inverse();
   return *this;
}


double
Matrix3d::GetRotationAxisAngle(Vector3d &axis)
{
  double cosAngle =  (m[0][0] + m[1][1] + m[2][2]- 1.)/2.;
  double angle = cosAngle > 1. ? acos(1.) : 
    cosAngle < -1. ? acos(-1.) :  acos(cosAngle);

  const double epsilon2 = 0.1;
  if (fabs (angle) < epsilon ||
    fabs (angle-acos(-1.)) < epsilon)
  {
		if (fabs(m[0][1]+m[1][0]) < epsilon2
		  && fabs(m[0][2]+m[2][0]) < epsilon2
		  && fabs(m[1][2]+m[2][1]) < epsilon2
		  && fabs(m[0][0]+m[1][1]+m[2][2]-3) < epsilon2) 
    {
			// this singularity is identity matrix so angle = 0
      axis = Vector3d(1.,0.,0.);
			return 0.; // zero angle, arbitrary axis
		}
    angle = acos(-1.);
		double xx = (m[0][0]+1)/2;
		double yy = (m[1][1]+1)/2;
		double zz = (m[2][2]+1)/2;
		double xy = (m[0][1]+m[1][0])/4;
		double xz = (m[0][2]+m[2][0])/4;
		double yz = (m[1][2]+m[2][1])/4;
		if ((xx > yy) && (xx > zz)) 
    { // m[0][0] is the largest diagonal term
			if (xx< epsilon)
				axis = Vector3d(0., sqrt(1./2.), sqrt(1./2.));
			else
				axis = Vector3d(sqrt(xx), xy/sqrt(xx), xz/sqrt(xx));
		} 
    else if (yy > zz) 
    { // m[1][1] is the largest diagonal term
			if (yy< epsilon)
				axis = Vector3d(sqrt(1./2.), 0., sqrt(1./2.));
			else
				axis = Vector3d(xy/sqrt(yy), sqrt(yy), yz/sqrt(yy));
		} 
    else 
    { // m[2][2] is the largest diagonal term so base result on this
			if (zz< epsilon)
				axis = Vector3d(sqrt(1./2.), sqrt(1./2.), 0.);
			else
				axis = Vector3d(xz/sqrt(zz), yz/sqrt(zz), sqrt(zz));
		}
    return angle;
	}
	// as we have reached here there are no singularities so we can handle normally
	double s = sqrt((m[2][1] - m[1][2])*(m[2][1] - m[1][2])
		+(m[0][2] - m[2][0])*(m[0][2] - m[2][0])
		+(m[1][0] - m[0][1])*(m[1][0] - m[0][1])); // used to normalise
	if (fabs(s) < epsilon) 
    s=1.; 
  axis = Vector3d ((m[2][1] - m[1][2])/s, (m[0][2] - m[2][0])/s, (m[1][0] - m[0][1])/s);
    return angle;
}


Matrix3d& 
Matrix3d::SetFromAngleAxis(const Vector3d &axis)
{
   return SetFromAngleAxis(axis.Length(), axis.UnitVector());
}

Matrix3d& 
Matrix3d::SetFromAngleAxis(double angle, const Vector3d &axis)
{
   if (fabs(angle) < epsilon)
   {
      Identity();
      return *this;
   }

   double  x = axis.v[0],
      y = axis.v[1],
      z = axis.v[2],
      c = cos(angle),
      s = sin(angle),
      v = 1.-c;

   m[0][0] = x*x*v+c;
   m[0][1] = x*y*v-z*s;
   m[0][2] = x*z*v+y*s;
   m[0][3] = 0.;
   
   m[1][0] = y*x*v+z*s;
   m[1][1] = y*y*v+c;
   m[1][2] = y*z*v-x*s;
   m[1][3] = 0.;
   
   m[2][0] = z*x*v-y*s;
   m[2][1] = z*y*v+x*s;
   m[2][2] = z*z*v+c;
   m[2][3] = 0.;
   
   m[3][0] =
   m[3][1] =
   m[3][2] = 0.;
   m[3][3] = 1.;

   return *this;
}

void
Matrix3d::DumpMatrix(TCHAR *s)
{
   ATLTRACE(_T("\n%s\n%f %f %f %f\n%f %f %f %f\n%f %f %f %f\n%f %f %f %f\n"),
      s,
      m[0][0],m[0][1],m[0][2],m[0][3],
      m[1][0],m[1][1],m[1][2],m[1][3],
      m[2][0],m[2][1],m[2][2],m[2][3],
      m[3][0],m[3][1],m[3][2],m[3][3]);
}


Matrix3d  
Matrix3d::operator* (const Matrix3d &mat) const
{
   Matrix3d result = *this;
   result *= mat;
   return result;
}

Matrix3d& 
Matrix3d::operator*=(const Matrix3d &mat)
{
   Matrix3d tmp;
   for(int i=0;i<4;i++)
      for(int j=0;j<4;j++)
         tmp.m[i][j] = m[i][0] * mat.m[0][j]
      + m[i][1] * mat.m[1][j]
      + m[i][2] * mat.m[2][j]
      + m[i][3] * mat.m[3][j];

      *this = tmp;
      return *this;
}

Matrix3d  
Matrix3d::operator+ (const Matrix3d &mat) const
{
   Matrix3d result = *this;
   result += mat;
   return result;
}

Matrix3d& 
Matrix3d::operator+=(const Matrix3d &mat)
{
   for(int i=0;i<4;i++)
      for(int j=0;j<4;j++)
         m[i][j] += mat.m[i][j];
   return *this;
}

Matrix3d  
Matrix3d::operator- (const Matrix3d &mat) const
{
   Matrix3d result = *this;
   result -= mat;
   return result;
}

Matrix3d& 
Matrix3d::operator-=(const Matrix3d &mat)
{
   for(int i=0;i<4;i++)
      for(int j=0;j<4;j++)
         m[i][j] -= mat.m[i][j];
   return *this;
}

Vector3d  
Matrix3d::operator* (const Vector3d &vec) const
{
   Vector3d result;
   result.v[0] = m[0][0]*vec.v[0] + m[0][1]*vec.v[1] + m[0][2]*vec.v[2] + m[0][3]*vec.v[3];
   result.v[1] = m[1][0]*vec.v[0] + m[1][1]*vec.v[1] + m[1][2]*vec.v[2] + m[1][3]*vec.v[3];
   result.v[2] = m[2][0]*vec.v[0] + m[2][1]*vec.v[1] + m[2][2]*vec.v[2] + m[2][3]*vec.v[3];
   result.v[3] = m[3][0]*vec.v[0] + m[3][1]*vec.v[1] + m[3][2]*vec.v[2] + m[3][3]*vec.v[3];
   return result;
}

bool Matrix3d::operator==(const Matrix3d &mat) const
{
   for(int i=0;i<4;i++)
      for(int j=0;j<4;j++)
         if (fabs(m[i][j] - mat.m[i][j]) > epsilon)
            return false;
   return true;
}

void
Matrix3d::Test()
{
   // Test vector addition
   Vector3d v1(1,0,0,0),v2(0,1,0,0);
   Vector3d v3=v1+v2;
   v3.DumpVector(_T("v3=v1+v2"));
   v3+=v1;
   v3.DumpVector(_T("v3+=v1"));

   // Test vector subtraction
   v3-=v1;
   v3.DumpVector(_T("v3-=v1"));
   v3=v1-v2;
   v3.DumpVector(_T("v3=v1-v2"));

   // Test vector cross product
   Vector3d cross=v1.CrossProduct(v2);
   cross.DumpVector(_T("v1 x v2"));

   // Test vector dot product
   ATLTRACE(_T("v1 dot v2: %f\n"),v1.DotProduct(v2));

   Vector3d v4(.5,.5,.5,1);
   ATLTRACE(_T("v1 dot v4: %f\n"),v1.DotProduct(v4));

   // Test vector zero
   v4.Zero();
   v4.DumpVector(_T("zero"));

   // Test vector set
   v4.Set(1,2,3,0);
   v4.DumpVector(_T("v4.Set(1,2,3,0)"));



   // Test matrix transpose
   Matrix3d t1(1,2,3,4,
      5,6,7,8,
      9,10,11,12,
      13,14,15,16);
   t1.DumpMatrix(_T("original t1"));
   t1.Transpose();
   t1.DumpMatrix(_T("transposed t1"));

   // Test matrix addition
   Matrix3d t2(2,4,6,8,
      10,12,14,16,
      18,20,22,24,
      26,28,30,32);
   Matrix3d t3;
   t3 = t1 + t2;
   t3.DumpMatrix(_T("t3 = t1+t2"));

   // Test matrix subtraction
   t1 = t3 - t2;
   t1.DumpMatrix(_T("t1 = t3-t2"));

   // Test matrix multiplication
   Matrix3d I;
   I.Identity();
   t1*=I;
   t1.DumpMatrix(_T("t1 * I"));
   Matrix3d t4=t1;
   t4 = t4*t1;
   t4.DumpMatrix(_T("t4=t4*t1"));
   t4=t1;
   t4*=t1;
   t4.DumpMatrix(_T("t4*=t1"));

   // Test matrix inversion
   t1.Set(1,2,3,4,
      5,6,7,8,
      9,10,11,12,
      13,14,15,16);
   Matrix3d t1Invert = t1;
   t1Invert.Invert();
   t1Invert.DumpMatrix(_T("t1Invert:"));

   Matrix3d t1Inv=t1.Inverse();
   t1Inv.DumpMatrix(_T("t1Inv"));

   // does a * INV(a) = I?
   Vector3d rot(10,0,0,1);
   t1.SetFromAngleAxis(rot);
   t1Inv=t1.Inverse();
   t1.DumpMatrix(_T("t1 (a rotation)"));
   t1Inv.DumpMatrix(_T("t1Inverse"));
   t1*=t1Inv;
   t1.DumpMatrix(_T("t1 *= t1Inv (should be I)"));
}


double * Matrix3d::openGLformat()
{
   // OpenGL expects matrices in column major order.  They are stored like
   // row matrices (translation in the last row), but they are multiplied
   // as column matrices (translations in the last column).  Matrix3d 
   // matrices are column matrices and are stored that way.
   for(int i=0;i<4;i++)
      for(int j=0;j<4;j++)
         m_openGLformat[i][j] = m[j][i];

   return (double *)m_openGLformat;
}

void Matrix3d::SetFromOpenGLFormat(double mat[4][4])
{
   // OpenGL stores matrices in column major format.  This class stores
   // them in row major format.  This function converts a 4x4 double
   // matrix that would be retrieved from OpenGL (glGetDoublev) to Matrix3d
   // format.
   for(int i=0;i<4;i++)
   {
      for(int j=0;j<4;j++)
      {
         m[i][j] = mat[j][i];
      }
   }
}

void Matrix3d::SetFromOpenGLFormat(double mat[16])
{
   // OpenGL stores matrices in column major format.  This class stores
   // them in row major format.  This function converts a 4x4 double
   // matrix that would be retrieved from OpenGL (glGetDoublev) to Matrix3d
   // format.
   for(int i=0;i<4;i++)
   {
      for(int j=0;j<4;j++)
      {
         m[i][j] = mat[j*4+i];
      }
   }
}

Matrix3d & Matrix3d::TranslateBy(const Vector3d &v)
{
   m[0][3] += v.v[0];
   m[1][3] += v.v[1];
   m[2][3] += v.v[2];
   return *this;
}

Matrix3d & Matrix3d::SetPosition(const Vector3d &v)
{
   m[0][3] = v.v[0];
   m[1][3] = v.v[1];
   m[2][3] = v.v[2];
   return *this;
}

Matrix3d & Matrix3d::SetOrientation(const Matrix3d &mat)
{
   for(int i=0;i<3;i++)
      for(int j=0;j<3;j++)
         m[i][j] = mat.m[i][j];
   return *this;
}

Vector3d Matrix3d::GetColumn(size_t i)
{
   Vector3d column;
   if (i<4)
   {
      column.v[0] = m[0][i];
      column.v[1] = m[1][i];
      column.v[2] = m[2][i];
      column.v[3] = m[3][i];
   }
   return column;
}

Vector3d Matrix3d::GetPosition()
{
   Vector3d pos;
   pos.v[0] = m[0][3];
   pos.v[1] = m[1][3];
   pos.v[2] = m[2][3];
   pos.v[3] = m[3][3];
   return pos;
}

Matrix3d Matrix3d::GetOrientation()
{
   Matrix3d orientation;
   for(int i=0;i<3;i++)
      for(int j=0;j<3;j++)
         orientation.m[i][j] = m[i][j];
   return orientation;
}

Matrix3d & Matrix3d::SetFromScaleFactors(double sx, double sy, double sz)
{
   m[0][0] = sx; m[0][1] =  0; m[0][2] =  0; m[0][3] = 0;
   m[1][0] =  0; m[1][1] = sy; m[1][2] =  0; m[1][3] = 0;
   m[2][0] =  0; m[2][1] =  0; m[2][2] = sz; m[2][3] = 0;
   m[3][0] =  0; m[3][1] =  0; m[3][2] =  0; m[3][3] = 1;
   return *this;
}


