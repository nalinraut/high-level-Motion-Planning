s3dm_viewer: MFC single document sample.

Minimum operating system requirements : Windows XP SP2

/*
* Copyright notice:
* (c) 2010-2011 3Dconnexion. All rights reserved. 
* 
* This file and source code are an integral part of the "3Dconnexion
* Software Developer Kit", including all accompanying documentation,
* and is protected by intellectual property laws. All use of the
* 3Dconnexion Software Developer Kit is subject to the License
* Agreement found in the "LicenseAgreementSDK.txt" file.
* All rights not expressly granted by 3Dconnexion are reserved.
*/

This sample is a supplement to the document "Programming for the 3dmouse" available
at www.3dconnexion.com and intended as a guide to intergrating a 3d mouse into an mcad 
viewer application. The level of support for the 3dmouse is the minimun required functionality 
for an mcad appliation which needs to implement the 'lock horizon' algorithm as outline in 
the certification section of "Programming for the 3dmouse".

The s3dm_viewer sample shows how to register raw input devices to receive WM_INPUT messages 
containing 6dof or key press data from a 3d mouse. The sample demonstrates the standard 
mcad 'Object mode' navigation paradigm with the pivot visible and center of rotation selection 
either using the mouse middle button (MMB) in 'Manual' mode or automatic in 'Auto' mode. 
Two flavours of the 'Auto' algorithm have been implemented. Defining _AUTO_PIVOT_WHILE_MOVING 
as 1 in stdafx.h causes the center of rotation to be continuously recalculated when 
the object is being moved. Defining _AUTO_PIVOT_WHILE_MOVING as 0 causes the center of 
rotation to be only calculated when not moving the object. This is the recommended implementation.
In both cases the calculations occur in the OnIdle() callback.
An object mode navigation with the axes reversed is implemented in the target camera mode.
The sample also demonstrates two camera navigation modes: a free camera and helicopter.
In camera mode the focal distance is calculated using a similar algorithm as that used in the 
'Auto' algorithm  for object mode.
The pan zoom and rotation speeds are calculated using the formulas define in the 'Navigation Velocity' 
chapter in "Programming for the 3dmouse".

The required standard 3d mouse popup menu and the handlers for standard 3d mouse buttons "1" 
and "2" (or popup menu and fit) are also included.


See 'Programming for the 3d mouse' for the definition of 'object mode' etc.

The template CRawInputImplT or CRawInputMFCImplT in rawinput.hpp can be used for a 
rapid 3d mouse integration into an existing program. See rawinput.hpp and mainfrm.hpp

The files that are required for a CRawInputImplT implementation are

3dmouseparams.hpp     - a class to hold the 3d mouse params set in the popup menu
3dmouseconstants.hpp  - standard 3d mouse velocity definition
3dmousepopupmenu.hpp  - standard 3d mouse popup menu for an mcad application with an horizon
array.hpp             - a wrapper for when the std::tr1::array is not available
i3dmouseparam.hpp     - the interface to the 3d mouse params
rawinput.hpp          - template raw input handler class
virtualkeys.hpp       - 3d mouse virtual key definitions
3dmousexml.c          - code to write the xml mouse settings used to communicate with external utilities
3dmousexml.h          - headerfile
3dmousexml.cpp        - a c++ wrapper for 3dmousexml.c