
Standard 3D Mouse Software Developer Kit
----------------------------------------


1. DESCRIPTION
--------------
The Standard 3D Mouse SDK (S3DM SDK) consists of documentation and sample software that explain and demonstrate the implications of adding 3D Mouse support in Windows applications. The SDK refers only to standard operating system interfaces, namely, "Raw Input" which is available in Microsoft Windows XP and newer.

Applications complying with S3DM guidelines can be certified by 3Dconnexion. Certification information can be found in the document "Standard 3D Mouse Certification".


2. CONTENTS
-----------
Documentation for the programming of 3D Mouse on Windows can be found in the "doc" folder.
The "samples" folder contains sample applications. Refer to the "readme.txt" file included in the main folder for each sample.


3. LICENSE AGREEMENT
--------------------
The use of this Software Developer Kit, sample code and documentation is subject to the acceptance of the terms of the "3Dconnexion Software Developer Kit License Agreement".
The license text is found in the "LicenseAgreementSDK.txt" file in the "doc" folder.


4. API SUPPORT
--------------
Developers are invited to contact the 3Dconnexion API Support Service if assistance is required.
Contact details are available from 3Dconnexion.com.


5. SDK VERSIONS
---------------
Version 1.0 - Initial public release: Raw Input, Intelligent 3D Navigation, Popup Menu, generic button assignment;
Version 2.0 - Visual Studio 2010 support, 3D Mouse Settings export, additional localisation (FR, JP, ZH), bug fixes.