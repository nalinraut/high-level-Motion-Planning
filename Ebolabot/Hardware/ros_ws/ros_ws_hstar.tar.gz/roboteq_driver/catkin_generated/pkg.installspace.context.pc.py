# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/motion/ros_ws/install/include".split(';') if "/home/motion/ros_ws/install/include" != "" else []
PROJECT_CATKIN_DEPENDS = "".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "".split(';') if "" != "" else []
PROJECT_NAME = "roboteq_driver"
PROJECT_SPACE_DIR = "/home/motion/ros_ws/install"
PROJECT_VERSION = "0.1.1"
