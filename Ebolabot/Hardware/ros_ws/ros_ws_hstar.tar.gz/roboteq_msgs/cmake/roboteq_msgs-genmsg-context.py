# generated from genmsg/cmake/pkg-genmsg.context.in

messages_str = "/home/motion/ros_ws/src/roboteq_msgs/msg/Configuration.msg;/home/motion/ros_ws/src/roboteq_msgs/msg/Command.msg;/home/motion/ros_ws/src/roboteq_msgs/msg/Feedback.msg;/home/motion/ros_ws/src/roboteq_msgs/msg/Status.msg"
services_str = ""
pkg_name = "roboteq_msgs"
dependencies_str = "std_msgs"
langs = "gencpp;genlisp;genpy"
dep_include_paths_str = "roboteq_msgs;/home/motion/ros_ws/src/roboteq_msgs/msg;std_msgs;/opt/ros/hydro/share/std_msgs/cmake/../msg"
PYTHON_EXECUTABLE = "/usr/bin/python"
package_has_static_sources = '' == 'TRUE'
